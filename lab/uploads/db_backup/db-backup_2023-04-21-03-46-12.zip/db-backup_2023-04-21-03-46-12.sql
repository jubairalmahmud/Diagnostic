#
# TABLE STRUCTURE FOR: accounts
#

DROP TABLE IF EXISTS `accounts`;

CREATE TABLE `accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `balance` double(18,2) NOT NULL DEFAULT 0.00,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: appointment
#

DROP TABLE IF EXISTS `appointment`;

CREATE TABLE `appointment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `appointment_id` varchar(20) NOT NULL,
  `doctor_id` varchar(20) NOT NULL,
  `patient_id` varchar(20) NOT NULL,
  `consultation_fees` varchar(20) NOT NULL,
  `discount` decimal(18,2) NOT NULL,
  `schedule` varchar(50) NOT NULL,
  `remarks` text NOT NULL,
  `appointment_date` date NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: chemical
#

DROP TABLE IF EXISTS `chemical`;

CREATE TABLE `chemical` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `code` varchar(50) NOT NULL,
  `category_id` int(11) NOT NULL,
  `purchase_unit_id` int(11) NOT NULL,
  `sales_unit_id` int(11) NOT NULL,
  `unit_ratio` varchar(20) DEFAULT '1',
  `purchase_price` decimal(18,2) NOT NULL DEFAULT 0.00,
  `sales_price` decimal(18,2) NOT NULL DEFAULT 0.00,
  `available_stock` varchar(11) NOT NULL DEFAULT '0',
  `photo` varchar(100) DEFAULT NULL,
  `remarks` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: chemical_assigned
#

DROP TABLE IF EXISTS `chemical_assigned`;

CREATE TABLE `chemical_assigned` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `test_id` int(11) NOT NULL,
  `chemical_id` varchar(20) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: chemical_category
#

DROP TABLE IF EXISTS `chemical_category`;

CREATE TABLE `chemical_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: chemical_stock
#

DROP TABLE IF EXISTS `chemical_stock`;

CREATE TABLE `chemical_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `inovice_no` varchar(25) NOT NULL,
  `chemical_id` varchar(20) NOT NULL,
  `date` date DEFAULT NULL,
  `stock_quantity` varchar(20) NOT NULL,
  `remarks` varchar(255) NOT NULL,
  `stock_by` varchar(20) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: chemical_unit
#

DROP TABLE IF EXISTS `chemical_unit`;

CREATE TABLE `chemical_unit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: ci_sessions
#

DROP TABLE IF EXISTS `ci_sessions`;

CREATE TABLE `ci_sessions` (
  `id` varchar(40) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT 0,
  `data` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('02oqaigi4jnmiueomck3gq75qedorkpe', '85.159.208.15', 1682024078, '__ci_last_regenerate|i:1682024078;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('037ihmdot3ln1339lkgmp0rq0vr7ldk1', '35.206.153.39', 1680070581, '__ci_last_regenerate|i:1680070581;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('07785knl78q4qlev0ejcrq6drbgbli1a', '31.13.127.112', 1679814314, '__ci_last_regenerate|i:1679814314;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0ahc2jivmm86a7idq4p2fve39fo26jc6', '103.25.250.248', 1678866796, '__ci_last_regenerate|i:1678866796;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"bengali\";loggedin|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0hj70caul1cci89035476g39chvda14n', '85.159.208.15', 1682024073, '__ci_last_regenerate|i:1682024073;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0kp19b063up1sue25vmhg2j97fifa3qo', '85.159.208.15', 1682024061, '__ci_last_regenerate|i:1682024061;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0l9r1nmampkkbvmp5r5k4c8es95opk24', '85.159.208.15', 1682024067, '__ci_last_regenerate|i:1682024067;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0oc6aaqrl95l8bhfvngfqtlc8dloi0q1', '85.159.208.15', 1682024058, '__ci_last_regenerate|i:1682024058;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0ojlat88lmt9jq4hm2ut96qauocemeai', '85.159.208.15', 1682024088, '__ci_last_regenerate|i:1682024088;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0sej5dpera39ae33ka28pupgj87a2ud9', '85.159.208.15', 1682024076, '__ci_last_regenerate|i:1682024076;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0u8dkkmikclm9okbmeu5jpog4kau4olu', '85.159.208.15', 1682024084, '__ci_last_regenerate|i:1682024084;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('138vp1l912ns51859mv9iajnsr7kk5pb', '85.159.208.15', 1682024067, '__ci_last_regenerate|i:1682024067;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('14ee33qt7elbthgn5f0joahev60idb4t', '181.215.184.169', 1682024414, '__ci_last_regenerate|i:1682024414;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1539u0vsiul6rismk3ajij2puhao52mo', '85.159.208.15', 1682024064, '__ci_last_regenerate|i:1682024064;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1bq2smkllosbos5sp0l4gtfgrgjo6ar5', '85.159.208.15', 1682024072, '__ci_last_regenerate|i:1682024072;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1gsmq4ki5j29l1bavqk592engdfnk40n', '85.159.208.15', 1682024100, '__ci_last_regenerate|i:1682024100;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1iref4kagm5hl0kqsagaibler9cggek0', '::1', 1678819154, '__ci_last_regenerate|i:1678819154;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|N;loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%Y/%m/%d\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:79:\"তথ্য সফলভাবে আপডেট করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1j35fnfnu8bjukgd4oknjje9saff0ibs', '103.25.248.247', 1678822703, '__ci_last_regenerate|i:1678822703;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%Y/%m/%d\";set_lang|s:7:\"english\";loggedin|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1kmje6451066fvdlve675mhjdsbu89m6', '85.159.208.15', 1682024060, '__ci_last_regenerate|i:1682024060;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1krqgrqqithg4ncp2rhu4tth0bjso8ul', '173.252.79.2', 1680543870, '__ci_last_regenerate|i:1680543870;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1m9b9kans0r0o5k5fjjmbab2913u7jbt', '85.159.208.15', 1682024069, '__ci_last_regenerate|i:1682024069;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1ng7qjgh6s0dnql26p1hh16cfr7sv9fd', '85.159.208.15', 1682024060, '__ci_last_regenerate|i:1682024060;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1rj54d2rv9asikjd0c0u5do77lk2s3e3', '160.202.147.4', 1681934464, '__ci_last_regenerate|i:1681934464;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1t5vrfc3gmqtu3mu248rjjc7qsh0l5uv', '85.159.208.15', 1682024096, '__ci_last_regenerate|i:1682024096;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('24jser01kk7jhbn14e8ku9s4ncgiul6j', '103.25.250.248', 1678865901, '__ci_last_regenerate|i:1678865901;name|s:14:\"jahanara Begum\";uniqueid|s:7:\"77b79d5\";logger_photo|s:36:\"39bf842e7061e59e8d1283e4c1f9330b.jpg\";loggedin_id|s:1:\"3\";loggedin_role_id|s:1:\"6\";loggedin_userid|s:1:\"2\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:85:\"তথ্য সফলভাবে সংরক্ষণ করা হয়েছে\";__ci_vars|a:2:{s:21:\"alert-message-success\";s:3:\"old\";s:11:\"profile_tab\";s:3:\"old\";}profile_tab|i:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('271c5rrp0o4bvc5hv7id6v7f0gs0lu4m', '58.145.186.245', 1679079226, 'redirect_url|s:44:\"https://lab.elitedesign.com.bd/test/category\";__ci_last_regenerate|i:1679079226;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:85:\"তথ্য সফলভাবে সংরক্ষণ করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('27o2e5puop5iqtv2mpp2k4ed3fk93kbp', '85.159.208.15', 1682024062, '__ci_last_regenerate|i:1682024062;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2ammp2ect0n68ujn472fskrkiidatq8p', '85.159.208.15', 1682024061, '__ci_last_regenerate|i:1682024061;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2g6abl2cdbpcsdt7sb64u9npnm5l6ts7', '103.25.251.239', 1679290926, '__ci_last_regenerate|i:1679290926;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2i9h8rt8kdckmtsgrmkhe4deocq2jvk6', '58.145.186.245', 1679081758, 'redirect_url|s:44:\"https://lab.elitedesign.com.bd/test/category\";__ci_last_regenerate|i:1679081758;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:85:\"তথ্য সফলভাবে সংরক্ষণ করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2j11id8os6qihvfb1vc18s77k1ug6k7n', '85.159.208.15', 1682024068, '__ci_last_regenerate|i:1682024068;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2kgri1suvpjoj1mvdfeoldregve4n3ff', '85.159.208.15', 1682024066, '__ci_last_regenerate|i:1682024066;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2l7b3ihegs2ttvprfa5bgfjhjigl9jrk', '85.159.208.15', 1682024093, '__ci_last_regenerate|i:1682024093;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2lrrv1uttqv8ohsksmfiphth6kqm3ibo', '172.111.57.93', 1682024414, '__ci_last_regenerate|i:1682024414;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2m1fhkvqpg7di0b1o18s47dsqkh9fcuc', '85.159.208.15', 1682024073, '__ci_last_regenerate|i:1682024073;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2m718e7dkg505c3sjr076pbe4jatvof3', '103.25.250.248', 1678871490, '__ci_last_regenerate|i:1678871490;name|s:14:\"jahanara Begum\";uniqueid|s:7:\"77b79d5\";logger_photo|s:36:\"39bf842e7061e59e8d1283e4c1f9330b.jpg\";loggedin_id|s:1:\"3\";loggedin_role_id|s:1:\"6\";loggedin_userid|s:1:\"2\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;active_tab|i:3;__ci_vars|a:1:{s:10:\"active_tab\";s:3:\"new\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2mc8uk2abbe3qub7m3tm714c2nf9lr45', '103.229.82.146', 1679815727, '__ci_last_regenerate|i:1679815446;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:85:\"তথ্য সফলভাবে সংরক্ষণ করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2n4i46vevi02qqsahpf48fpm2o4djjon', '85.159.208.15', 1682024076, '__ci_last_regenerate|i:1682024076;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2q5evkc3u5dfin143kpm7sfeado351sm', '103.25.248.236', 1679321060, '__ci_last_regenerate|i:1679321060;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2qb5j34cvhh57qlm07ab2ncqnvosc3ik', '103.179.181.197', 1679560339, '__ci_last_regenerate|i:1679560339;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2stg76gfcme18n6ir57mfqolb25fdhai', '103.25.248.247', 1678824745, '__ci_last_regenerate|i:1678824745;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:85:\"তথ্য সফলভাবে সংরক্ষণ করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2u0nknfu2d35bbpkusagqjnfda5gl42g', '94.124.161.156', 1682024414, '__ci_last_regenerate|i:1682024414;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2unj53dcro4tbugodg0ljpf663ee6vcv', '85.159.208.15', 1682024096, '__ci_last_regenerate|i:1682024096;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2uuuf8629kphj6taija32b7nqj34ivju', '85.159.208.15', 1682024059, '__ci_last_regenerate|i:1682024059;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2vq1uubtotpo8mt7fkc75qmqcav1cjcm', '103.25.250.248', 1678865042, '__ci_last_regenerate|i:1678865042;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"bengali\";loggedin|b:1;alert-message-success|s:40:\"Information Has Been Saved Successfully \";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('33s3drqqftr6t8hmqgr9dsa17l866r7u', '103.229.82.146', 1679815446, '__ci_last_regenerate|i:1679815446;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:85:\"তথ্য সফলভাবে সংরক্ষণ করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('350gju9kq5i6jaqnhjokf5bm6073kqpq', '103.181.69.64', 1678970764, '__ci_last_regenerate|i:1678970657;name|s:14:\"jahanara Begum\";uniqueid|s:7:\"77b79d5\";logger_photo|s:36:\"39bf842e7061e59e8d1283e4c1f9330b.jpg\";loggedin_id|s:1:\"3\";loggedin_role_id|s:1:\"6\";loggedin_userid|s:1:\"2\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:31:\"পেমেন্ট সফল\";__ci_vars|a:2:{s:21:\"alert-message-success\";s:3:\"old\";s:10:\"active_tab\";s:3:\"old\";}active_tab|i:2;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('358d8h62jffdk913grqq9rrv714erm2d', '85.159.208.15', 1682024095, '__ci_last_regenerate|i:1682024095;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3a916biecfj85rpsa8u03aq588lujsss', '85.159.208.15', 1682024063, '__ci_last_regenerate|i:1682024063;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3cs0mt38e0a1569bfcdre7q0t19tsiu6', '85.159.208.15', 1682024089, '__ci_last_regenerate|i:1682024089;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3ls8ife2c63rm2k8sqdeoa2s6g59vjbj', '37.111.205.139', 1681934379, '__ci_last_regenerate|i:1681934379;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3ppb9v1r8omr24dm6g7upo3atjt7pgrp', '103.25.250.248', 1678864434, '__ci_last_regenerate|i:1678864434;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"bengali\";loggedin|b:1;alert-message-success|s:40:\"Information Has Been Saved Successfully \";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3uf8udij3auqtulcs86q8l23ohapp5cs', '85.159.208.15', 1682024101, '__ci_last_regenerate|i:1682024101;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('40s39tuic5ruvpi728a6ieni8l8f9crn', '138.36.94.219', 1682024415, '__ci_last_regenerate|i:1682024415;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('412uvt1u61sfhp1cn1ters2fecrclpjp', '85.159.208.15', 1682024083, '__ci_last_regenerate|i:1682024083;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('446vvspeqhtksug0ial0kn9r15mr88kc', '37.111.194.193', 1678901492, '__ci_last_regenerate|i:1678901492;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4bpnpm5936b8djr5r0718v0ssbonhcuf', '85.159.208.15', 1682024090, '__ci_last_regenerate|i:1682024090;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4j2du7ppudjkc3mn9duirmd2tq6b0mj9', '85.159.208.15', 1682024091, '__ci_last_regenerate|i:1682024091;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4khnl5efb6ad9b8l7d965t55c6gd66fl', '103.25.250.248', 1678865525, '__ci_last_regenerate|i:1678865525;name|s:14:\"jahanara Begum\";uniqueid|s:7:\"77b79d5\";logger_photo|s:36:\"39bf842e7061e59e8d1283e4c1f9330b.jpg\";loggedin_id|s:1:\"3\";loggedin_role_id|s:1:\"6\";loggedin_userid|s:1:\"2\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:85:\"তথ্য সফলভাবে সংরক্ষণ করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4ll3d2ckl31cgm312lfps5seiq88rm8u', '85.159.208.15', 1682024062, '__ci_last_regenerate|i:1682024062;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4m64d1msinlrq6678vb0pjgookk4v8fb', '85.159.208.15', 1682024057, '__ci_last_regenerate|i:1682024057;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4mdlqvuhejlb6h3rvk50pum7ccvefbg1', '85.159.208.15', 1682024100, '__ci_last_regenerate|i:1682024100;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4o9v53bj0ca3dooktgcnhdqfill9fjro', '85.159.208.15', 1682024055, '__ci_last_regenerate|i:1682024055;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4tkbrnvci3b303lqh86sif1l2m6lbufb', '114.31.31.68', 1681934757, '__ci_last_regenerate|i:1681934754;redirect_url|s:39:\"https://lab.elitedesign.com.bd/settings\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4tufv8886notegkqsprl3kjvpm5pekli', '103.25.248.247', 1678825087, '__ci_last_regenerate|i:1678825087;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:85:\"তথ্য সফলভাবে সংরক্ষণ করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4u47qbed2qcpojdsha6r09k036p46cl0', '85.159.208.15', 1682024082, '__ci_last_regenerate|i:1682024082;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4u5c1oapk476jr68605r168oies3ldpk', '103.25.250.248', 1678861874, '__ci_last_regenerate|i:1678861874;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"bengali\";loggedin|b:1;alert-message-success|s:40:\"Information Has Been Saved Successfully \";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4vovotliuqm0gp44deb8pvm3ds3elq1f', '85.159.208.15', 1682024078, '__ci_last_regenerate|i:1682024078;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5904r982jf5f9thaonv3rpqntmfa4fui', '85.159.208.15', 1682024054, '__ci_last_regenerate|i:1682024054;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5dl521q1327oq7j73tekl5k9dao2pamf', '85.159.208.15', 1682024071, '__ci_last_regenerate|i:1682024071;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5ep0d0u6v4cu8mrem49phi5392dpn1sn', '180.92.233.138', 1678970657, '__ci_last_regenerate|i:1678970657;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5f7rgq1oujs8sffb68j9eff38b36km1g', '103.60.175.86', 1680975755, '__ci_last_regenerate|i:1680975755;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5jm2om1eeg5sp1l7jaon1t5av88sinqb', '85.159.208.15', 1682024092, '__ci_last_regenerate|i:1682024092;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5nddjv9msg0hhmnko6tphrkh2vc89ka3', '103.25.248.247', 1678826242, '__ci_last_regenerate|i:1678826242;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:79:\"তথ্য সফলভাবে আপডেট করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5pr9kbh4584enkv98fbq66s6akoogi5f', '85.159.208.15', 1682024067, '__ci_last_regenerate|i:1682024067;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5r35rcl66ste5me38odj7hu1rd1npbv0', '85.159.208.15', 1682024083, '__ci_last_regenerate|i:1682024083;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5s58r9u3da5b61gbec00huouc24dep1e', '51.255.62.3', 1680898735, '__ci_last_regenerate|i:1680898735;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5toja0p7omfkovoualnck3150pptn1t7', '85.159.208.15', 1682024075, '__ci_last_regenerate|i:1682024075;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5vigh1h7vopa821fo5b2l3tsguvn2n0t', '85.159.208.15', 1682024079, '__ci_last_regenerate|i:1682024079;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6353nu8uuqtd5cjbsehlfm2hqq9tceg6', '85.159.208.15', 1682024062, '__ci_last_regenerate|i:1682024062;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('63tr7ki13r1213sfp7njvvc2nhlk0ncf', '85.159.208.15', 1682024078, '__ci_last_regenerate|i:1682024078;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('655k7vc3gd6rios4s4an518t86qd3gqc', '103.25.251.246', 1679228305, '__ci_last_regenerate|i:1679228305;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('65mvanvt8hvnqnfgd3gqobqg3bnes8e5', '103.161.70.4', 1682027149, '__ci_last_regenerate|i:1682027149;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('66a25l8u8ajq7bb8v6k0n3v9tbictv1p', '85.159.208.15', 1682024085, '__ci_last_regenerate|i:1682024085;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('66ctboi1rvkvrp0b5cnfbg7jnsqb5ghb', '85.159.208.15', 1682024076, '__ci_last_regenerate|i:1682024076;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('68jr2m3rjb3i5qcik0agkcdqb1g6kjv5', '85.159.208.15', 1682024099, '__ci_last_regenerate|i:1682024099;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6as79h3qau0mnjbek0doqiaa24fm6eqe', '85.159.208.15', 1682024088, '__ci_last_regenerate|i:1682024088;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6asqurh938iq0u6r1pvgepl8ceppi7tk', '85.159.208.15', 1682024085, '__ci_last_regenerate|i:1682024085;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6bju5nrf7j5vbqvk5k5mf9mj9n9g9997', '85.159.208.15', 1682024085, '__ci_last_regenerate|i:1682024085;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6c9k3jd8r211qrc1jpn9emutc8052qmg', '85.159.208.15', 1682024067, '__ci_last_regenerate|i:1682024067;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6cskuba8q6i0e2o7oea2cdmbv85ut4d0', '85.159.208.15', 1682024074, '__ci_last_regenerate|i:1682024074;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6dje33vm2183nccti8771j9prrdd4dcm', '85.159.208.15', 1682024093, '__ci_last_regenerate|i:1682024093;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6dogpniuuq3kotsg6b9q52oeemeup1hh', '85.159.208.15', 1682024072, '__ci_last_regenerate|i:1682024072;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6eqc848lnn04mknheoujv6bef5hpq0e7', '85.159.208.15', 1682024063, '__ci_last_regenerate|i:1682024063;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6hpektrnipb0sksakolv1nafparac8dc', '85.159.208.15', 1682024074, '__ci_last_regenerate|i:1682024074;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6iti8lok2hj1rfm9kaktjbp5m1s54pra', '103.25.250.248', 1678866299, '__ci_last_regenerate|i:1678866299;name|s:12:\"Md Abu Sayed\";uniqueid|s:7:\"31b912e\";logger_photo|s:36:\"24b4e97a397240f4842e39aaf2820269.png\";loggedin_id|s:1:\"4\";loggedin_role_id|s:1:\"5\";loggedin_userid|s:1:\"3\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:85:\"তথ্য সফলভাবে সংরক্ষণ করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6mpd47vt23r1jqe0cekpjjnksocoigm3', '103.25.248.247', 1678822169, '__ci_last_regenerate|i:1678822169;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%Y/%m/%d\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:75:\"কনফিগারেশন আপডেট করা হয়েছে\";__ci_vars|a:2:{s:21:\"alert-message-success\";s:3:\"old\";s:6:\"active\";s:3:\"old\";}active|i:2;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6obvnim7d8gp0fjrl2r2p476ftaqad69', '65.154.226.166', 1680545747, '__ci_last_regenerate|i:1680545747;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6omrp45fsqp2qi7v7kuhc4mhch3hgje7', '85.159.208.15', 1682024086, '__ci_last_regenerate|i:1682024086;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6s940nbphlgg8rbg3nfaar3bgbntv8un', '85.159.208.15', 1682024093, '__ci_last_regenerate|i:1682024093;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6tf5p1mre9om4d4bnrlmd2vomd2b3bi3', '202.86.218.75', 1680545658, '__ci_last_regenerate|i:1680545480;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:85:\"তথ্য সফলভাবে সংরক্ষণ করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('72b45f0us8q6ghg31qgvegmtpuqv2o5f', '173.252.83.116', 1679846952, '__ci_last_regenerate|i:1679846952;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('79eogrdfkvoumf1d3ri4h6sip0u37pkc', '85.159.208.15', 1682024092, '__ci_last_regenerate|i:1682024092;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('79q9oh0dn325rhs9ui7selan74csoapg', '103.179.181.196', 1679863484, '__ci_last_regenerate|i:1679863484;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7af4icdcke6clk886fiova7dq23pe5t0', '85.159.208.15', 1682024076, '__ci_last_regenerate|i:1682024076;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7app50bagaf637usil9i90smf4k6dt28', '85.159.208.15', 1682024073, '__ci_last_regenerate|i:1682024073;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7c0r0069vk6drs722ahrmgmup792o941', '58.145.186.245', 1679084498, 'redirect_url|s:44:\"https://lab.elitedesign.com.bd/test/category\";__ci_last_regenerate|i:1679084498;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:85:\"তথ্য সফলভাবে সংরক্ষণ করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7dobf9qnu00vu2gmvk5b6831tsrg07d4', '85.159.208.15', 1682024066, '__ci_last_regenerate|i:1682024066;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7eodpfg7n84hvcegvn47hgu6oo1vuje6', '85.159.208.15', 1682024077, '__ci_last_regenerate|i:1682024077;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7fr040ik9r49nns9v71ld158546htm0h', '103.25.248.228', 1678975401, '__ci_last_regenerate|i:1678975401;name|s:14:\"jahanara Begum\";uniqueid|s:7:\"77b79d5\";logger_photo|s:36:\"39bf842e7061e59e8d1283e4c1f9330b.jpg\";loggedin_id|s:1:\"3\";loggedin_role_id|s:1:\"6\";loggedin_userid|s:1:\"2\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7ic303045ploc56iaig2e53pj0t770pv', '51.255.62.10', 1680013102, '__ci_last_regenerate|i:1680013101;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7jmgid3um5iunp9iecc09ptcn8tbk56o', '58.145.186.245', 1679083071, 'redirect_url|s:44:\"https://lab.elitedesign.com.bd/test/category\";__ci_last_regenerate|i:1679083071;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:85:\"তথ্য সফলভাবে সংরক্ষণ করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7ns6klsauhqmu91v0d3uobg92fqilot9', '103.118.77.26', 1680616180, '__ci_last_regenerate|i:1680616116;name|s:12:\"Md Abu Sayed\";uniqueid|s:7:\"31b912e\";logger_photo|s:36:\"24b4e97a397240f4842e39aaf2820269.png\";loggedin_id|s:1:\"4\";loggedin_role_id|s:1:\"5\";loggedin_userid|s:1:\"3\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:85:\"তথ্য সফলভাবে সংরক্ষণ করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7ruimmv7p09lm9fjfl0ss7k4o3kro25s', '85.159.208.15', 1682024087, '__ci_last_regenerate|i:1682024087;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7vues630u2upaicugt1sn7ob7v0e80in', '85.159.208.15', 1682024099, '__ci_last_regenerate|i:1682024099;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8180maep33q9skspq2gjl1fhc6g5pv4l', '85.159.208.15', 1682024090, '__ci_last_regenerate|i:1682024090;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('827jq17c3t1uqkokd3dctq338ppo65ms', '103.25.248.250', 1679209477, '__ci_last_regenerate|i:1679209176;name|s:12:\"Md Abu Sayed\";uniqueid|s:7:\"31b912e\";logger_photo|s:36:\"24b4e97a397240f4842e39aaf2820269.png\";loggedin_id|s:1:\"4\";loggedin_role_id|s:1:\"5\";loggedin_userid|s:1:\"3\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('834jms1o1a419fh2l8aaakksbq513jag', '85.159.208.15', 1682024064, '__ci_last_regenerate|i:1682024064;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('86mgeplrv6lmg3egmrag134o4s3q3q32', '51.255.62.5', 1680898735, '__ci_last_regenerate|i:1680898735;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('876549aocta9uqol4m2j05b23a01q4ck', '103.25.249.246', 1679295695, '__ci_last_regenerate|i:1679295695;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('87b2eh9uhajdnttkmmoepqmbqr2cmcf2', '103.25.249.248', 1679548414, '__ci_last_regenerate|i:1679548414;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('87h23vtn1e059ko1i0tie18g1trf9ujq', '58.145.186.245', 1679081445, 'redirect_url|s:44:\"https://lab.elitedesign.com.bd/test/category\";__ci_last_regenerate|i:1679081445;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:85:\"তথ্য সফলভাবে সংরক্ষণ করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8adjcls7a9lsp1fs9v05n8e4nq00pbat', '66.220.149.15', 1679548027, '__ci_last_regenerate|i:1679548027;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8bsr4354u6h1iukpjap68k5smoeucaqj', '103.108.229.61', 1680740843, '__ci_last_regenerate|i:1680740843;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8nve53tjr79blgjlmi58t9hc0opq6nuj', '85.159.208.15', 1682024061, '__ci_last_regenerate|i:1682024061;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8p6m28enp61b6o1mvdgo6d1dpoq9nrm0', '37.111.194.193', 1678901510, '__ci_last_regenerate|i:1678901492;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8r3uumult346hta11bhvjmdssu4lno2m', '103.25.248.228', 1678970277, '__ci_last_regenerate|i:1678970277;alert-message-error|s:27:\"Username Password Incorrect\";__ci_vars|a:1:{s:19:\"alert-message-error\";s:3:\"old\";}name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8ruo7dp6cb7ukaq6qp832q06jprf5i4r', '85.159.208.15', 1682024070, '__ci_last_regenerate|i:1682024070;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8vpggul2av9act4nhk9ib2h3ahgvemve', '85.159.208.15', 1682024086, '__ci_last_regenerate|i:1682024086;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('91g95euf7nfrvs3f8mejmkoscj5riq89', '85.159.208.15', 1682024089, '__ci_last_regenerate|i:1682024089;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('91mik8ata3nd0s3o9fg09qb721vpi63o', '103.25.249.246', 1679308993, '__ci_last_regenerate|i:1679308993;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('93ij6adikdnj6dop3bg9cofs855jslss', '85.159.208.15', 1682024062, '__ci_last_regenerate|i:1682024062;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('968j9dv3o0mqua8e0k84q888l4g7ua9c', '85.159.208.15', 1682024074, '__ci_last_regenerate|i:1682024074;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('97e0egq3ta0ap9muvd93904mhmp0iocp', '85.159.208.15', 1682024074, '__ci_last_regenerate|i:1682024074;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9a3k14pbrrfkk9o8ob55vkrqbm94r4ri', '85.159.208.15', 1682024101, '__ci_last_regenerate|i:1682024101;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9c4t5vo18ngjgi5sh9d1a62ahml4bdbg', '85.159.208.15', 1682024067, '__ci_last_regenerate|i:1682024067;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9dc912o53gmh0qgqvnlgaapc8jln327f', '103.112.59.253', 1681935574, '__ci_last_regenerate|i:1681935574;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"bengali\";loggedin|b:1;alert-message-success|s:40:\"Information Has Been Saved Successfully \";__ci_vars|a:2:{s:21:\"alert-message-success\";s:3:\"old\";s:6:\"active\";s:3:\"old\";}active|i:2;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9ff7bo7tk9vtsqfvevasgdll2fi478d8', '35.206.153.39', 1680070578, '__ci_last_regenerate|i:1680070578;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9g40dm68c96202dtaca4j23bbrhsff18', '::1', 1678821274, '__ci_last_regenerate|i:1678821274;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|N;loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%Y/%m/%d\";set_lang|s:7:\"bengali\";loggedin|b:1;alert-message-success|s:42:\"Information Has Been Updated Successfully \";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9g8a506v0ubhm1jasb8r36kjfndd78ga', '31.13.127.18', 1679335100, '__ci_last_regenerate|i:1679335100;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9iba69svor8jf19o4vqsrl71q6rgvu42', '85.159.208.15', 1682024090, '__ci_last_regenerate|i:1682024090;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9kct1uugcrdpmu4i02rv2i4bqjg6hoj8', '85.159.208.15', 1682024090, '__ci_last_regenerate|i:1682024090;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9l91g0co04bq3dople2mn8tigk8dvn5e', '103.25.249.248', 1679548043, '__ci_last_regenerate|i:1679547987;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9lp9ks0f4e5c9j1o7vtftp9iva4vuenp', '58.145.186.245', 1679082145, 'redirect_url|s:44:\"https://lab.elitedesign.com.bd/test/category\";__ci_last_regenerate|i:1679082145;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:85:\"তথ্য সফলভাবে সংরক্ষণ করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9n6dqt5mdv0ek1b3kfthb77n3k98re3s', '58.145.186.245', 1679078889, 'redirect_url|s:44:\"https://lab.elitedesign.com.bd/test/category\";__ci_last_regenerate|i:1679078889;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:85:\"তথ্য সফলভাবে সংরক্ষণ করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9t1a8v8s5btv2usb4cjtlmbu272cl01d', '85.159.208.15', 1682024075, '__ci_last_regenerate|i:1682024075;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9v4lulm7h2jq78ss7aiprmdromplkka8', '103.183.141.3', 1679133608, '__ci_last_regenerate|i:1679133608;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a0cda3080c7b638lo6ihuhkte575o0ur', '85.159.208.15', 1682024080, '__ci_last_regenerate|i:1682024080;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a1od84oo7voggk8akd3f13da1l7g4lp7', '85.159.208.15', 1682024058, '__ci_last_regenerate|i:1682024058;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a28tgj47baumftj8quoggiv194l2cj0s', '103.25.250.248', 1678856772, '__ci_last_regenerate|i:1678856772;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a3331v6j06l6l8rig0jpr8v21guatguu', '85.159.208.15', 1682024095, '__ci_last_regenerate|i:1682024095;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a3ggordro9m6vbdtqckf6i8ushgdm4ui', '66.220.149.17', 1680909347, '__ci_last_regenerate|i:1680909347;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a4562ua45l695l4onl192sd73u42so0i', '85.159.208.15', 1682024081, '__ci_last_regenerate|i:1682024081;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a57pr6tla7iqngqpa866al19ru911dgb', '85.159.208.15', 1682024076, '__ci_last_regenerate|i:1682024076;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a5k50jkgme320ufnjokeeotf0c7g3g91', '85.159.208.15', 1682024065, '__ci_last_regenerate|i:1682024065;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a6qk5032smh3ajsr6g9gqtgaqka2o123', '103.25.248.247', 1678828550, '__ci_last_regenerate|i:1678828550;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:79:\"তথ্য সফলভাবে আপডেট করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a9f4si3aqe2lahpra1osjfjb81stk232', '103.25.250.248', 1678867108, '__ci_last_regenerate|i:1678867108;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"bengali\";loggedin|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('acbnbv8taclk0saeppuk72hhdqfukcci', '103.25.248.250', 1679209176, '__ci_last_regenerate|i:1679209176;name|s:12:\"Md Abu Sayed\";uniqueid|s:7:\"31b912e\";logger_photo|s:36:\"24b4e97a397240f4842e39aaf2820269.png\";loggedin_id|s:1:\"4\";loggedin_role_id|s:1:\"5\";loggedin_userid|s:1:\"3\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('af21mv2kcp938t03r2lo852jmccq32s1', '85.159.208.15', 1682024055, '__ci_last_regenerate|i:1682024055;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('aj6p0r7g9ted71jsol1oc4ppadg84o4j', '85.159.208.15', 1682024071, '__ci_last_regenerate|i:1682024071;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ajrsebdmj7pp73ga3tr1hsqs5f3dkcee', '85.159.208.15', 1682024086, '__ci_last_regenerate|i:1682024086;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('aklaip65o6ccunitg77mcplch1ci6nvh', '85.159.208.15', 1682024083, '__ci_last_regenerate|i:1682024083;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('aoel25ouls48hu5jqp8vjg78d5kgkph9', '::1', 1678821274, '__ci_last_regenerate|i:1678821274;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|N;loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%Y/%m/%d\";set_lang|s:7:\"bengali\";loggedin|b:1;alert-message-success|s:42:\"Information Has Been Updated Successfully \";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('aqe5iubfm14bhqcl7als4jgujdula2jt', '103.25.248.247', 1678823258, '__ci_last_regenerate|i:1678823255;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('asup6a43h01eqvvsjn0set1457kvufqr', '51.255.62.9', 1680898731, '__ci_last_regenerate|i:1680898731;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b0jv4c6noqpm0b0vjb3bo0m5if55t57h', '85.159.208.15', 1682024063, '__ci_last_regenerate|i:1682024063;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b1jmbh94p40seh9a47lmfvvk0lrcsek2', '103.183.141.3', 1679137950, '__ci_last_regenerate|i:1679137938;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"bengali\";loggedin|b:1;alert-message-success|s:31:\"পেমেন্ট সফল\";__ci_vars|a:2:{s:21:\"alert-message-success\";s:3:\"old\";s:10:\"active_tab\";s:3:\"old\";}active_tab|i:2;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b201kvbc8obgqf3i9vhofj0qfa3qcpf0', '103.25.248.247', 1678822212, '__ci_last_regenerate|i:1678822169;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%Y/%m/%d\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:79:\"তথ্য সফলভাবে আপডেট করা হয়েছে\";__ci_vars|a:2:{s:21:\"alert-message-success\";s:3:\"old\";s:6:\"active\";s:3:\"old\";}active|i:2;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b3vfen4q8hlomj57kirgktfphpe7imet', '85.159.208.15', 1682024075, '__ci_last_regenerate|i:1682024075;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b9evgh7f9748aqlef61p2tg7lq82opdc', '103.118.77.26', 1680613862, '__ci_last_regenerate|i:1680613724;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b9ijvpj1b4norgo1tkn9fan3a11qf2d9', '85.159.208.15', 1682024065, '__ci_last_regenerate|i:1682024065;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bb0vhc8m1d40va5i24mebba2vc8qtbf9', '85.159.208.15', 1682024077, '__ci_last_regenerate|i:1682024077;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bbg84cghe32qd7a717kua0ikp296ni86', '103.108.229.61', 1680789293, '__ci_last_regenerate|i:1680789292;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bcnav7iqf4lhinjl12luukno72dulloq', '103.25.248.247', 1678830967, '__ci_last_regenerate|i:1678830966;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bdvt4hjggoa1p2cltacvrkgialn3lopm', '146.70.166.232', 1680906264, '__ci_last_regenerate|i:1680906264;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('be1fe5tr5cc78h2d18b9g7hff4vq3jgj', '103.25.251.228', 1679031484, '__ci_last_regenerate|i:1679031483;redirect_url|s:53:\"https://lab.elitedesign.com.bd/billing/test_bill_list\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bi9lgetkp5b8mreiln2nhmachegaj8be', '85.159.208.15', 1682024098, '__ci_last_regenerate|i:1682024098;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bja2slbn19q4ih2b9fv84no4c3vt98n1', '181.215.184.169', 1682024413, '__ci_last_regenerate|i:1682024413;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bl2lif6dhatqemugc41jvgjb9bptgmml', '58.145.186.245', 1679078577, 'redirect_url|s:44:\"https://lab.elitedesign.com.bd/test/category\";__ci_last_regenerate|i:1679078577;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:85:\"তথ্য সফলভাবে সংরক্ষণ করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bn9t2qmuopoj7gisl4bc0gq91lkfi1eo', '103.25.250.248', 1678862188, '__ci_last_regenerate|i:1678862188;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"bengali\";loggedin|b:1;alert-message-success|s:40:\"Information Has Been Saved Successfully \";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bns65ph834ofhgc3g5k9479j3n2j7a21', '51.254.49.96', 1680917792, '__ci_last_regenerate|i:1680917792;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bolpkhd6qgn9e3p3b91jicnn5s86d728', '85.159.208.15', 1682024082, '__ci_last_regenerate|i:1682024082;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bqfotukhidg2m26o60g2td20eu9agv04', '85.159.208.15', 1682024082, '__ci_last_regenerate|i:1682024082;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bsdma0jirc1jqe85clujssnnno9ktkp5', '85.159.208.15', 1682024093, '__ci_last_regenerate|i:1682024093;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c08sr2t4a5prdbt5oko4n14teu193ud9', '85.159.208.15', 1682024085, '__ci_last_regenerate|i:1682024085;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c753t2fp326i54egi0un3er1uf2bb6vn', '37.111.205.139', 1681934681, '__ci_last_regenerate|i:1681934681;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"bengali\";loggedin|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cagrqtofan7lpp09sv2nbnjq7e0b7ni2', '51.254.49.101', 1680018160, '__ci_last_regenerate|i:1680018159;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cedpvg98d6p6v0b9ma3leulfudcbjqth', '103.25.251.239', 1679290948, '__ci_last_regenerate|i:1679290948;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cel2c6lvlhsp0t16ib5v30481copem74', '45.152.177.226', 1682024415, '__ci_last_regenerate|i:1682024415;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ceq9885ib9uj3n7pdcdkglasulrav7lj', '34.247.82.239', 1680919091, '__ci_last_regenerate|i:1680919091;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cg9f232pj932fipb0vlfvtb91b26kd8e', '85.159.208.15', 1682024089, '__ci_last_regenerate|i:1682024089;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cgurra08e2r4h4flt11civ9ekla49aeb', '181.215.184.169', 1682024422, '__ci_last_regenerate|i:1682024422;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ch4np47f8a938cb3duniv2i828khnuue', '45.152.177.226', 1682024415, '__ci_last_regenerate|i:1682024414;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ciorieouldjrkbqacl6e7jr87bgquf24', '51.255.62.6', 1680013102, '__ci_last_regenerate|i:1680013101;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cjk3s2i331nvm5og3mqgu73b8lrlqg9t', '85.159.208.15', 1682024085, '__ci_last_regenerate|i:1682024085;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cju4arftcebsmch3a35fml58njt70hu9', '35.206.153.39', 1679589706, '__ci_last_regenerate|i:1679589706;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cjvt2hnndiaavgl1u5j05mtnmcsqs2fv', '45.152.177.226', 1682024408, '__ci_last_regenerate|i:1682024408;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cn306874q35hbaiddb6719csr4k91qio', '103.60.175.86', 1680976058, '__ci_last_regenerate|i:1680976058;alert-message-error|s:27:\"Username Password Incorrect\";__ci_vars|a:2:{s:19:\"alert-message-error\";s:3:\"old\";s:21:\"alert-message-success\";s:3:\"old\";}name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:85:\"তথ্য সফলভাবে সংরক্ষণ করা হয়েছে\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cnrkl2s0s079kqim130uq7k9e6g4nte9', '35.206.153.39', 1679589707, '__ci_last_regenerate|i:1679589707;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cpdbofi7kaa587f8i4fbq63n9e1p8ud0', '85.159.208.15', 1682024090, '__ci_last_regenerate|i:1682024090;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cugq1u5kl21lko70nejeplegd3con7c0', '103.183.141.3', 1679133258, '__ci_last_regenerate|i:1679133258;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d7sjtudjc095i2n7p82eos7e78dn87e8', '85.159.208.15', 1682024064, '__ci_last_regenerate|i:1682024064;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d9q4nomce69qh0o4g1j96hvf68e2ec7o', '85.159.208.15', 1682024092, '__ci_last_regenerate|i:1682024092;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('daihtrejvlq636q7ni7gba3t6an93rma', '85.159.208.15', 1682024094, '__ci_last_regenerate|i:1682024094;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dar6snn4sp6t63tme6ajpgvp3gb9d6js', '85.159.208.15', 1682024062, '__ci_last_regenerate|i:1682024062;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('db017fars022aqdpggkp9nct18atvne3', '85.159.208.15', 1682024073, '__ci_last_regenerate|i:1682024073;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dc8h5h7m587ngbf4q9iotvmgdoutchu1', '85.159.208.15', 1682024053, '__ci_last_regenerate|i:1682024052;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dcgpj9ghk1g32nrk4p85rne8q8a7hp0o', '::1', 1678818847, '__ci_last_regenerate|i:1678818847;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|N;loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%Y/%m/%d\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:79:\"তথ্য সফলভাবে আপডেট করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ddilntmv4ubff03t8nfasf8esl0vi3ab', '103.25.250.248', 1678864741, '__ci_last_regenerate|i:1678864741;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"bengali\";loggedin|b:1;alert-message-success|s:40:\"Information Has Been Saved Successfully \";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ddt6gjmkcjllqk7jsh3ivliiv5e569bi', '85.159.208.15', 1682024063, '__ci_last_regenerate|i:1682024063;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dggj34sasoc50ltghn85qalnnj0r5nfr', '85.159.208.15', 1682024095, '__ci_last_regenerate|i:1682024095;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('difjqa6rgoll9a3b5b8kajqebi13vjo6', '103.25.248.247', 1678826994, '__ci_last_regenerate|i:1678826994;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:79:\"তথ্য সফলভাবে আপডেট করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dkgnuhimeuoabbt00b0t0c1l63v58sca', '85.159.208.15', 1682024094, '__ci_last_regenerate|i:1682024094;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('do9ftpd0vqiqcntd5icc1ks0gjj1svv0', '85.159.208.15', 1682024071, '__ci_last_regenerate|i:1682024071;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('done0brcc97u6uj5s6tnb4b4uc8p4vjl', '180.92.233.138', 1678969585, '__ci_last_regenerate|i:1678969585;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('doojsf7sktlr47sejbticesfea588hji', '58.145.186.245', 1679082769, 'redirect_url|s:44:\"https://lab.elitedesign.com.bd/test/category\";__ci_last_regenerate|i:1679082769;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:85:\"তথ্য সফলভাবে সংরক্ষণ করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dte91r71pbougvavmbevgla74n9h6r0f', '103.25.248.247', 1678828224, '__ci_last_regenerate|i:1678828224;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e22i9nafvqmes5e0alebntt0moobempq', '85.159.208.15', 1682024056, '__ci_last_regenerate|i:1682024056;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e23193r7q17h811ur6vg23dm08pq981c', '85.159.208.15', 1682024075, '__ci_last_regenerate|i:1682024075;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e244etcq3qioce094nmf4f845vn20g6s', '85.159.208.15', 1682024089, '__ci_last_regenerate|i:1682024089;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e2jupfjp8eeccq3821ql63lk28u18h1s', '181.215.184.169', 1682024414, '__ci_last_regenerate|i:1682024414;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e6dr62nvgneod1f74pbiu0sm99mrm0jk', '85.159.208.15', 1682024065, '__ci_last_regenerate|i:1682024065;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e6kpj3r3q495e61a4u10b50tfuh856nl', '85.159.208.15', 1682024079, '__ci_last_regenerate|i:1682024079;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e840i28uevkpb110gifs29b81cprpclg', '85.159.208.15', 1682024065, '__ci_last_regenerate|i:1682024065;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eecder3bnfg15vuuu1sg4avp4dq43dle', '103.25.248.247', 1678829366, '__ci_last_regenerate|i:1678829366;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eig16a46qivaqsmef7a2jomu68ft9ber', '85.159.208.15', 1682024094, '__ci_last_regenerate|i:1682024094;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('emag7fuk1omtt7o8uhjroefou7f255jh', '51.255.62.11', 1680898731, '__ci_last_regenerate|i:1680898731;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eofunjvorfpl6c9vm1doj20tguu22a3o', '58.145.186.245', 1679068124, '__ci_last_regenerate|i:1679068124;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eul139ogddl8feotjceiph79qv6rbmfn', '31.13.127.4', 1679814316, '__ci_last_regenerate|i:1679814315;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f395pqd37vduu2ajo484dadshcbqcn8i', '85.159.208.15', 1682024098, '__ci_last_regenerate|i:1682024098;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f4gnehh78pl6uunn1eourpqba3hi70pg', '85.159.208.15', 1682024097, '__ci_last_regenerate|i:1682024097;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f769g3gbpstvormn68noeft79gjk6b6u', '173.252.83.19', 1679506051, '__ci_last_regenerate|i:1679506050;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fb44p0uj7phpn3u9plaumunnjrho1gnj', '58.145.186.245', 1679083866, 'redirect_url|s:44:\"https://lab.elitedesign.com.bd/test/category\";__ci_last_regenerate|i:1679083866;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:85:\"তথ্য সফলভাবে সংরক্ষণ করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fe59h1nuaji3aqqc655rg936blbnofg4', '85.159.208.15', 1682024080, '__ci_last_regenerate|i:1682024080;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('feaapgte0v2vr2cuk95m5166grqa69jn', '103.25.248.247', 1678829083, '__ci_last_regenerate|i:1678829083;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:79:\"তথ্য সফলভাবে আপডেট করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fi3qhretnpbeepj4k67sgm0ak5pjb39u', '85.159.208.15', 1682024100, '__ci_last_regenerate|i:1682024100;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fklduo4gfc6pq438ggbheacu9hqp4gv8', '85.159.208.15', 1682024078, '__ci_last_regenerate|i:1682024078;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('flim65fof69ik2c38sf42mgb4ubpidkb', '103.25.248.247', 1678824439, '__ci_last_regenerate|i:1678824439;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:75:\"কনফিগারেশন আপডেট করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fn8mi4k4d86l76p16mdaon4842cmdrsh', '85.159.208.15', 1682024072, '__ci_last_regenerate|i:1682024072;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fps420u6c1110cdag854befil67kb610', '85.159.208.15', 1682024075, '__ci_last_regenerate|i:1682024075;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fro21hhijdpbe30ghkue3s6809p1v02n', '85.159.208.15', 1682024080, '__ci_last_regenerate|i:1682024080;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fuiatnp2l5a1bb5gpt6k40cfnri7vj6m', '85.159.208.15', 1682024066, '__ci_last_regenerate|i:1682024066;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fuirj836rp3l0pnontcg2k99liv8pvfg', '::1', 1678814695, '__ci_last_regenerate|i:1678814695;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|N;loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%Y/%m/%d\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:41:\"Information Has Been Updated Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fvc97ejleh69tlp2216175170di57nel', '103.25.248.250', 1679207406, '__ci_last_regenerate|i:1679207406;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fvhd2qlj7tmm8f41ho3ioadr6f8a3i8v', '::1', 1678815929, '__ci_last_regenerate|i:1678815929;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|N;loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%Y/%m/%d\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:41:\"Information Has Been Updated Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('g3nd4gp5704k6ec03lh48mc8pc6d6q3v', '103.15.42.196', 1681934478, '__ci_last_regenerate|i:1681934475;redirect_url|s:40:\"https://lab.elitedesign.com.bd/dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('g4te2q6j8j336sdira6i04oio1b36l8a', '85.159.208.15', 1682024059, '__ci_last_regenerate|i:1682024059;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('g78r1tn4988fha7nmllo95mkvef120mg', '85.159.208.15', 1682024070, '__ci_last_regenerate|i:1682024070;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('g79rjg6fe7glijr4l4qgu8uc11krvond', '85.159.208.15', 1682024096, '__ci_last_regenerate|i:1682024096;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('g8os2p9h17c8jb97idbgpiebsp7t289t', '103.25.248.247', 1678829446, '__ci_last_regenerate|i:1678829446;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gadcniu1jus41ubqrmn2j6sm97vfcpq7', '103.25.250.248', 1678867770, '__ci_last_regenerate|i:1678867630;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gcqq47m5hofarbh4pmb990qtn4eoe0eo', '103.229.82.146', 1679815106, '__ci_last_regenerate|i:1679815106;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:85:\"তথ্য সফলভাবে সংরক্ষণ করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gelj7kiumoc57o9n800a526o9ek8bkfo', '85.159.208.15', 1682024086, '__ci_last_regenerate|i:1682024086;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('giet0irmeouqr7p61t246c26j1cn4q2s', '138.36.94.219', 1682024415, '__ci_last_regenerate|i:1682024415;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gj7mteuj01ou1fs8su42pphu3m58okuo', '85.159.208.15', 1682024091, '__ci_last_regenerate|i:1682024091;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gjcog9hm8spq78kvk249k6eul95ad1b4', '173.252.83.4', 1679846951, '__ci_last_regenerate|i:1679846951;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gjkclmqif7hq92hkvn2c2akv4j7jteka', '31.13.127.25', 1680613672, '__ci_last_regenerate|i:1680613672;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gkc8s9ggrlhpem3vm060g9njjdqj0ha0', '51.255.62.8', 1680013105, '__ci_last_regenerate|i:1680013105;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gmgaiaip8alulk4qrjq3sqsgur2rvkj9', '85.159.208.15', 1682024073, '__ci_last_regenerate|i:1682024073;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gomo8rboh4grt8ann7k76i8m2n4ehvaj', '85.159.208.15', 1682024082, '__ci_last_regenerate|i:1682024082;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gq5f0gnoijkis2k26ftilhgp8al42fo3', '58.145.186.245', 1679078238, 'redirect_url|s:44:\"https://lab.elitedesign.com.bd/test/category\";__ci_last_regenerate|i:1679078238;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:85:\"তথ্য সফলভাবে সংরক্ষণ করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gq9nsse83e7lkv7pd45pn09qlkq1eqc8', '85.159.208.15', 1682024084, '__ci_last_regenerate|i:1682024084;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gtkt5ql1fr7ftvf3tcpoe0dv4u9qmv32', '85.159.208.15', 1682024087, '__ci_last_regenerate|i:1682024087;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('h0s75ad3j7vptu0tdtnsdrdvfnavpn8j', '85.159.208.15', 1682024088, '__ci_last_regenerate|i:1682024088;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('h315k91iapelkbv5sf5c85k7um7uijv7', '85.159.208.15', 1682024055, '__ci_last_regenerate|i:1682024055;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hc37h7kr5c70rbetg0cp76ia3bfk9sq7', '103.25.248.250', 1679208349, '__ci_last_regenerate|i:1679208349;name|s:14:\"jahanara Begum\";uniqueid|s:7:\"77b79d5\";logger_photo|s:36:\"39bf842e7061e59e8d1283e4c1f9330b.jpg\";loggedin_id|s:1:\"3\";loggedin_role_id|s:1:\"6\";loggedin_userid|s:1:\"2\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hcbos5pn9hfrndgfvbncnoc6fsq01hvg', '103.25.248.250', 1679207789, '__ci_last_regenerate|i:1679207789;name|s:14:\"jahanara Begum\";uniqueid|s:7:\"77b79d5\";logger_photo|s:36:\"39bf842e7061e59e8d1283e4c1f9330b.jpg\";loggedin_id|s:1:\"3\";loggedin_role_id|s:1:\"6\";loggedin_userid|s:1:\"2\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:85:\"তথ্য সফলভাবে সংরক্ষণ করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hd5e8tbvd5pknd37kbjpqbufdk4p8b9u', '85.159.208.15', 1682024084, '__ci_last_regenerate|i:1682024084;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('he5d7m1vq18mvs10f4m2uiliutorge0p', '85.159.208.15', 1682024068, '__ci_last_regenerate|i:1682024068;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hfmt1fih1le7nmcgkcgtc30m5q1qaa7r', '103.25.250.248', 1678861271, '__ci_last_regenerate|i:1678861271;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"bengali\";loggedin|b:1;alert-message-success|s:40:\"Information Has Been Saved Successfully \";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hlb7phodhdr6ocgoh270vebpktf0fejd', '::1', 1678820427, '__ci_last_regenerate|i:1678820427;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|N;loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%Y/%m/%d\";set_lang|s:7:\"bengali\";loggedin|b:1;alert-message-success|s:79:\"তথ্য সফলভাবে আপডেট করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hlbtfc5ojlaq0akcp95on9dcvr1bnake', '103.25.250.248', 1678864077, '__ci_last_regenerate|i:1678864077;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"bengali\";loggedin|b:1;alert-message-success|s:40:\"Information Has Been Saved Successfully \";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hm379llasd7dav3iuntbqck67klfpvl5', '85.159.208.15', 1682024059, '__ci_last_regenerate|i:1682024059;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hm4o1nvn2grkkngdr2nq57m98mvbrl3i', '45.152.177.226', 1682024414, '__ci_last_regenerate|i:1682024414;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hm783hctke3phm0btce0rv0uimmd39rn', '85.159.208.15', 1682024063, '__ci_last_regenerate|i:1682024063;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hogkplbtdfh9sk29hvlrhjcog9h6qoua', '103.25.250.248', 1678863770, '__ci_last_regenerate|i:1678863770;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"bengali\";loggedin|b:1;alert-message-success|s:40:\"Information Has Been Saved Successfully \";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hqld0523n9j3ceddlj2m8nmdqrhlkrie', '85.159.208.15', 1682024092, '__ci_last_regenerate|i:1682024092;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hrl88qnma1l583el5d84dj3m34b97ts4', '::1', 1678818030, '__ci_last_regenerate|i:1678818030;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|N;loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%Y/%m/%d\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:41:\"Information Has Been Updated Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hsqbanmlkb6c5e9uf69ssqtmv9dflbvn', '85.159.208.15', 1682024068, '__ci_last_regenerate|i:1682024068;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('huoocem0uq41kmf1hii1vbk3ngl2mi3k', '85.159.208.15', 1682024080, '__ci_last_regenerate|i:1682024080;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('huve0oica8b9phpbguu73i676ab4hum0', '85.159.208.15', 1682024077, '__ci_last_regenerate|i:1682024077;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('i01d0r1ilp29dtcm2ggrg0bjgn4g20v9', '69.171.231.116', 1679133231, '__ci_last_regenerate|i:1679133231;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('i0v55s7og7ob945vvk70dqnksb5m520u', '85.159.208.15', 1682024092, '__ci_last_regenerate|i:1682024092;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('i1tk9pmkls30lvpb6m0lvapr90k0kotf', '103.25.251.239', 1679290412, '__ci_last_regenerate|i:1679290412;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('i74jot9pupdcab3fphm6fttshkvqkohq', '103.25.248.247', 1678824098, '__ci_last_regenerate|i:1678824098;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:75:\"কনফিগারেশন আপডেট করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('i7lah19tafh4e9aq5hr7uak6iu122jb4', '85.159.208.15', 1682024094, '__ci_last_regenerate|i:1682024094;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ieveouc4b5u3abjfqudsaf84ec1grduf', '85.159.208.15', 1682024084, '__ci_last_regenerate|i:1682024084;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ig3m677vufmvovsmsj4ik81om09q31li', '85.159.208.15', 1682024092, '__ci_last_regenerate|i:1682024092;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('iio8keqscofsnl2fatm0r9ssnqh4chhs', '103.25.250.248', 1678866427, '__ci_last_regenerate|i:1678866427;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ij0sk62b1qatbr0sa79ofh5mm6c2u8kp', '85.159.208.15', 1682024088, '__ci_last_regenerate|i:1682024088;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ik1a3flm2aj7qusodksgr44if2cqf94c', '103.25.248.247', 1678827303, '__ci_last_regenerate|i:1678827303;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:79:\"তথ্য সফলভাবে আপডেট করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('inv9olvvecr31f0obllv1t6qfqugku4a', '103.25.248.247', 1678827957, '__ci_last_regenerate|i:1678827957;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:79:\"তথ্য সফলভাবে আপডেট করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('io5ju157umuq8b5d2f5qervvb9t2p2i7', '::1', 1678816421, '__ci_last_regenerate|i:1678816421;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|N;loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%Y/%m/%d\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:41:\"Information Has Been Updated Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ipo8op9lluv2mqkb3jt1sp6eklfo3a2n', '208.115.218.90', 1682024415, '__ci_last_regenerate|i:1682024415;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('isd6s5qdbacidfdc68dqfmvro54lf70n', '103.25.250.248', 1678862521, '__ci_last_regenerate|i:1678862521;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"bengali\";loggedin|b:1;alert-message-success|s:40:\"Information Has Been Saved Successfully \";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('iur2fcuog08qaj4u9bfbanc5np5mjcq5', '85.159.208.15', 1682024071, '__ci_last_regenerate|i:1682024071;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('iv7st3rkre058jfrm3uhcodsecff7s77', '58.145.186.245', 1679081135, 'redirect_url|s:44:\"https://lab.elitedesign.com.bd/test/category\";__ci_last_regenerate|i:1679081135;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:85:\"তথ্য সফলভাবে সংরক্ষণ করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('j06eq80hhaj3a5hs0f1plkfrl6hk6k17', '85.159.208.15', 1682024065, '__ci_last_regenerate|i:1682024065;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('j52hfbohvqcaeslsbnagg185gr8khurt', '85.159.208.15', 1682024077, '__ci_last_regenerate|i:1682024077;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('j8vb3kog2uv2q9omfos8mluas0b8g1nc', '85.159.208.15', 1682024087, '__ci_last_regenerate|i:1682024087;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jdprq9bcchftf5unb924c63v6e8oqrcv', '103.25.250.248', 1678861572, '__ci_last_regenerate|i:1678861572;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"bengali\";loggedin|b:1;alert-message-success|s:40:\"Information Has Been Saved Successfully \";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jeh5oska30i5vfgi9ojsgqq7ls2idiro', '31.13.115.9', 1679533893, '__ci_last_regenerate|i:1679533893;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jg4augds20qin6kru960kas257ngfisq', '85.159.208.15', 1682024070, '__ci_last_regenerate|i:1682024070;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jivf3gh31ro5k0hfl2507sppgi5e2m5j', '103.25.250.248', 1678862845, '__ci_last_regenerate|i:1678862845;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"bengali\";loggedin|b:1;alert-message-success|s:40:\"Information Has Been Saved Successfully \";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jnvdg79hll8pibgd08pmo3heq6hlq4nh', '85.159.208.15', 1682024069, '__ci_last_regenerate|i:1682024069;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jouj3fg4pr6ug8uacb2r518cnlmu35bv', '58.145.186.245', 1679080488, 'redirect_url|s:44:\"https://lab.elitedesign.com.bd/test/category\";__ci_last_regenerate|i:1679080488;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:85:\"তথ্য সফলভাবে সংরক্ষণ করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jr58sm86q5ig543ja84st8hv78jgkqah', '173.252.83.6', 1679506051, '__ci_last_regenerate|i:1679506051;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jsbocv7mdi2bnqmnm4efjstht58sslc9', '103.183.141.3', 1679133935, '__ci_last_regenerate|i:1679133935;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jsiud7u6ck2t8vc4sn8qirjcqirji85k', '85.159.208.15', 1682024079, '__ci_last_regenerate|i:1682024079;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jva1ps8tp318m9qfi3hu3uhli6dggha0', '85.159.208.15', 1682024071, '__ci_last_regenerate|i:1682024071;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('k4hil0fflcfar3uifep7iupu5u0bt4pg', '85.159.208.15', 1682024093, '__ci_last_regenerate|i:1682024093;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('k5c3ass11du03c7strlm2stsj7st2c3f', '85.159.208.15', 1682024072, '__ci_last_regenerate|i:1682024072;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('k69r4crkcfik34vrfbnnrnpt2b0g1rhv', '103.60.175.86', 1680970946, '__ci_last_regenerate|i:1680970946;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kb52di0e6ee5bsb4h6m8essp40o00ufd', '91.193.6.10', 1678829594, '__ci_last_regenerate|i:1678829594;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kdkettjgucmc1245c2tnug7qastm13g0', '103.25.248.253', 1679133063, '__ci_last_regenerate|i:1679133063;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kfd56uin95ksqn3gcmn8jpm0a6a92s3k', '35.206.153.39', 1680070598, '__ci_last_regenerate|i:1680070598;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kqb2rd5bnu2trlvleotti0ip65jicbq6', '85.159.208.15', 1682024089, '__ci_last_regenerate|i:1682024089;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kt52vadhktej52l17085s3g87gghpso0', '85.159.208.15', 1682024074, '__ci_last_regenerate|i:1682024074;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l03irhfpiq4ln2odumqa9ucfid2psuhp', '103.25.248.247', 1678827609, '__ci_last_regenerate|i:1678827609;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:79:\"তথ্য সফলভাবে আপডেট করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l0qgg0l0ead05ac9tcijsisubifbs4as', '85.159.208.15', 1682024084, '__ci_last_regenerate|i:1682024084;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l27eigldm9imi6ta8e1t6uobdnsojfbe', '58.145.186.245', 1679084984, '__ci_last_regenerate|i:1679084984;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l6hkm4rv9kmu6miia8tq1gfg5t231dn3', '85.159.208.15', 1682024069, '__ci_last_regenerate|i:1682024069;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l85bgloc5q1ib3g93p8mkkmphupd5cpu', '103.25.248.250', 1679207047, '__ci_last_regenerate|i:1679207047;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lbo5baali37vdh6kfieaplsf2v9vk08j', '103.112.59.253', 1681935010, '__ci_last_regenerate|i:1681935010;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"bengali\";loggedin|b:1;alert-message-success|s:40:\"Information Has Been Saved Successfully \";__ci_vars|a:2:{s:21:\"alert-message-success\";s:3:\"new\";s:6:\"active\";s:3:\"old\";}active|i:2;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('le0lid00ehq57q86he8k52p4spqeisec', '58.145.186.245', 1679079861, 'redirect_url|s:44:\"https://lab.elitedesign.com.bd/test/category\";__ci_last_regenerate|i:1679079861;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:85:\"তথ্য সফলভাবে সংরক্ষণ করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lg0f3k9m9uuv6vgscshctvp3hfrlj3fs', '85.159.208.15', 1682024072, '__ci_last_regenerate|i:1682024072;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('li984tvord3vl3ru7ddata2n7cn1mep3', '85.159.208.15', 1682024091, '__ci_last_regenerate|i:1682024091;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ljgtbpu9ok2ms8e20f0hvfsp42uou1d4', '58.145.186.245', 1679071539, '__ci_last_regenerate|i:1679071538;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lmasml0pdarn08396udt747ql6atk834', '85.159.208.15', 1682024094, '__ci_last_regenerate|i:1682024094;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ln8qckr5ih6fr98i44m5tb3utnqfome1', '85.159.208.15', 1682024075, '__ci_last_regenerate|i:1682024075;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lookkh3ops6m5ougdfotrgmdjk22bi6u', '58.145.186.245', 1679082454, 'redirect_url|s:44:\"https://lab.elitedesign.com.bd/test/category\";__ci_last_regenerate|i:1679082454;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:85:\"তথ্য সফলভাবে সংরক্ষণ করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lt7ukbfk0opq77eld8tuuovqs7397bch', '103.25.248.247', 1678826638, '__ci_last_regenerate|i:1678826638;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:79:\"তথ্য সফলভাবে আপডেট করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lubdp6h2t3dmf5c9j0v8ducg11eqb1e1', '85.159.208.15', 1682024089, '__ci_last_regenerate|i:1682024089;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('m018n5pdosusml79tuus3svqptb0a4km', '85.159.208.15', 1682024079, '__ci_last_regenerate|i:1682024079;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('m77tg512sscemse7d03gptnlbbn6lptb', '103.25.248.247', 1678847168, '__ci_last_regenerate|i:1678847168;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('m8a820rjiad25oacr0al9sh97g591okr', '85.159.208.15', 1682024087, '__ci_last_regenerate|i:1682024087;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mbtg0rknmip1ld8vsnrb3f8qihq4mber', '103.25.249.250', 1678897878, '__ci_last_regenerate|i:1678897878;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mf2l3klamjopc2v0vlvsf36vg3pqaia3', '58.145.186.245', 1679071539, '__ci_last_regenerate|i:1679071538;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mg54lrm7l36jvchdqf11g9sktsf0d5kh', '85.159.208.15', 1682024066, '__ci_last_regenerate|i:1682024066;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mhb92te4uadfceuj5fck5a67mgovdsme', '103.25.248.228', 1678975401, '__ci_last_regenerate|i:1678975401;name|s:14:\"jahanara Begum\";uniqueid|s:7:\"77b79d5\";logger_photo|s:36:\"39bf842e7061e59e8d1283e4c1f9330b.jpg\";loggedin_id|s:1:\"3\";loggedin_role_id|s:1:\"6\";loggedin_userid|s:1:\"2\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mihi9d7el5l2e1svvavgbp0dfanftrgu', '66.220.149.15', 1679548032, '__ci_last_regenerate|i:1679548032;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mip9491an5pqeonddcu2lj40bj0ui8hf', '103.25.249.248', 1679548765, '__ci_last_regenerate|i:1679548716;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"bengali\";loggedin|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mj4seh9ulavfmjje4mjcs4vupsjmpru3', '66.220.149.3', 1680909347, '__ci_last_regenerate|i:1680909347;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ml9cur581f6ihkm6l6bm610r802vkrk0', '85.159.208.15', 1682024088, '__ci_last_regenerate|i:1682024088;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mn0ggc109fl2krhuqd0ntomo07f2t97m', '85.159.208.15', 1682024083, '__ci_last_regenerate|i:1682024083;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mru0vtckv76m2ju96k2ocqj6bhql8dh9', '103.183.141.3', 1679134238, '__ci_last_regenerate|i:1679134238;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:31:\"পেমেন্ট সফল\";__ci_vars|a:2:{s:21:\"alert-message-success\";s:3:\"old\";s:10:\"active_tab\";s:3:\"old\";}active_tab|i:2;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mu3qku012a2trmgeb25pq0k8e2o6da6t', '85.159.208.15', 1682024067, '__ci_last_regenerate|i:1682024067;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('n31u3q4k763arkhl62i9apvifr4bpbej', '58.145.186.245', 1679069462, '__ci_last_regenerate|i:1679069462;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('n4b3dildkfqtkt8sv71irfvppucbkspd', '85.159.208.15', 1682024071, '__ci_last_regenerate|i:1682024071;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('n4vq5s0mo53lq6m8590srefufsebn80e', '85.159.208.15', 1682024086, '__ci_last_regenerate|i:1682024086;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('n78ubpjpaqoqj35gdgtjsotutaj15lnc', '103.25.250.248', 1678860617, '__ci_last_regenerate|i:1678860617;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"bengali\";loggedin|b:1;alert-message-success|s:40:\"Information Has Been Saved Successfully \";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('n7n7pediltusakkl2i0nk5ibv5mq9tqt', '103.60.175.86', 1680976292, '__ci_last_regenerate|i:1680976058;alert-message-error|s:27:\"Username Password Incorrect\";__ci_vars|a:2:{s:19:\"alert-message-error\";s:3:\"old\";s:21:\"alert-message-success\";s:3:\"old\";}name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:79:\"তথ্য সফলভাবে আপডেট করা হয়েছে\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('n92ruq1krt52g1p1661m9mnippt32fo5', '37.111.194.193', 1678898288, '__ci_last_regenerate|i:1678898288;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('n993dt2gq608ta56m4hjhlao7953hu1u', '85.159.208.15', 1682024066, '__ci_last_regenerate|i:1682024066;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('na8365dll32si1rufsungsqti824vjtj', '85.159.208.15', 1682024099, '__ci_last_regenerate|i:1682024099;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nbebu2qiphjhk3nr78avbokuiu5dhlmt', '85.159.208.15', 1682024081, '__ci_last_regenerate|i:1682024081;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ngif6vo30a21hp3req1a6b2rscedub3k', '85.159.208.15', 1682024093, '__ci_last_regenerate|i:1682024093;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('njap8v290eqd4h2fiekh3fonk1lbb5kg', '35.206.153.39', 1680070577, '__ci_last_regenerate|i:1680070577;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nkbp4ts5jbaofc1fq5f5fe6df4db4pns', '146.70.166.232', 1680799723, '__ci_last_regenerate|i:1680799723;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('npdt9vfg3kkqqelha5fp8662cfh287re', '85.159.208.15', 1682024076, '__ci_last_regenerate|i:1682024076;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nq7kmb7mf0cnh161ad9hd6fucrtb1is7', '103.25.248.236', 1679321084, '__ci_last_regenerate|i:1679321084;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nuum6ln09r3ea993g3ao4jrojqhif5ug', '85.159.208.15', 1682024082, '__ci_last_regenerate|i:1682024082;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nuvopm6m5ha6eu83ip3bdsa2j76o953b', '85.159.208.15', 1682024091, '__ci_last_regenerate|i:1682024091;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o09he37k1a22t5vokphgv66j0lodfggl', '85.159.208.15', 1682024065, '__ci_last_regenerate|i:1682024065;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o14ho76iqnnbgak5dt7vcvc3n92efn3f', '103.25.250.248', 1678863463, '__ci_last_regenerate|i:1678863463;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"bengali\";loggedin|b:1;alert-message-success|s:40:\"Information Has Been Saved Successfully \";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o2jjcbqun99k9qt22ak8jop04jbmm78c', '103.102.43.6', 1679552311, '__ci_last_regenerate|i:1679552310;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o4peus5uq9k8lvjs62emk2upc2c7nfld', '85.159.208.15', 1682024070, '__ci_last_regenerate|i:1682024070;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o9bs8v5ugt8p1s2e0eouck2v0d52do39', '85.159.208.15', 1682024057, '__ci_last_regenerate|i:1682024057;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o9c25b0eu48bohl5aonadstblb32bdsn', '172.111.57.93', 1682024415, '__ci_last_regenerate|i:1682024414;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('oaovvsppjuq6qo1ut9m2ra0n62v4rqpc', '103.112.59.253', 1681935595, '__ci_last_regenerate|i:1681935574;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"bengali\";loggedin|b:1;alert-message-success|s:40:\"Information Has Been Saved Successfully \";__ci_vars|a:2:{s:21:\"alert-message-success\";s:3:\"old\";s:6:\"active\";s:3:\"old\";}active|i:2;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('oauannq5jvl9p8p4210oqb918upgf8s3', '103.25.248.228', 1678970603, '__ci_last_regenerate|i:1678970603;name|s:14:\"jahanara Begum\";uniqueid|s:7:\"77b79d5\";logger_photo|s:36:\"39bf842e7061e59e8d1283e4c1f9330b.jpg\";loggedin_id|s:1:\"3\";loggedin_role_id|s:1:\"6\";loggedin_userid|s:1:\"2\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('obgbqu27jnjkuejtlh1g8cetll2c4p79', '3.123.2.210', 1681680359, '__ci_last_regenerate|i:1681680359;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('oc6eg0k3e2g9deu71cbl3tb8747pccgp', '138.36.94.219', 1682024408, '__ci_last_regenerate|i:1682024408;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('oegvs4gem31qe3bj4dflj1ffc0p347v2', '58.145.186.245', 1679080829, 'redirect_url|s:44:\"https://lab.elitedesign.com.bd/test/category\";__ci_last_regenerate|i:1679080829;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:85:\"তথ্য সফলভাবে সংরক্ষণ করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ogaecu8brfhir016cjt672ai2ni0g2cp', '85.159.208.15', 1682024079, '__ci_last_regenerate|i:1682024079;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ogam4t1932pqmgmhcp5shftnu9g2qbqb', '103.25.250.241', 1679506432, '__ci_last_regenerate|i:1679506431;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('oin9konh13m00rtsr76760dds4eqmlmc', '103.183.141.3', 1679137938, '__ci_last_regenerate|i:1679137938;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"bengali\";loggedin|b:1;alert-message-success|s:31:\"পেমেন্ট সফল\";__ci_vars|a:2:{s:21:\"alert-message-success\";s:3:\"old\";s:10:\"active_tab\";s:3:\"old\";}active_tab|i:2;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ojpbmm36d2q51inihf3tlpdn6j9fcqnl', '103.25.248.247', 1678825572, '__ci_last_regenerate|i:1678825572;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:85:\"তথ্য সফলভাবে সংরক্ষণ করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ok8emo12lvls8ril300gu71r0o48030p', '103.25.248.247', 1678823565, '__ci_last_regenerate|i:1678823565;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('okv8kj7upn03m9eqv20is5hifo7gkm8i', '85.159.208.15', 1682024061, '__ci_last_regenerate|i:1682024061;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('omhnvlbsito8kdhjmn46hlr35hlg5a80', '85.159.208.15', 1682024081, '__ci_last_regenerate|i:1682024081;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('oo1fk2gjsufpu4pcqes02d0nlsddesth', '103.15.42.203', 1679814722, '__ci_last_regenerate|i:1679814719;redirect_url|s:40:\"https://lab.elitedesign.com.bd/dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('oo92273glbmprm4ns3vrv816pm1588n2', '51.254.49.101', 1680018156, '__ci_last_regenerate|i:1680018156;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('op8kphoog207a1n9m9rctpu7jt4hvm90', '85.159.208.15', 1682024097, '__ci_last_regenerate|i:1682024097;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('otj0ueljnlo0ikke74jcd2802b3u874b', '103.25.251.239', 1679293379, '__ci_last_regenerate|i:1679293379;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:79:\"তথ্য সফলভাবে আপডেট করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('otnnniur22p8jvf697bnli01t83gu520', '114.31.1.70', 1681934499, '__ci_last_regenerate|i:1681934497;redirect_url|s:35:\"https://lab.elitedesign.com.bd/test\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('p1eomjuetre6jf4ku03apntocotkphic', '85.159.208.15', 1682024068, '__ci_last_regenerate|i:1682024068;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('p77q2c3dtisj82snm5d0fduuqqbcj4sh', '103.20.141.4', 1681934841, '__ci_last_regenerate|i:1681934838;redirect_url|s:35:\"https://lab.elitedesign.com.bd/role\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('p83q1u9d9kqcstkq28lfnqq0aq44esf3', '103.25.250.241', 1679506431, '__ci_last_regenerate|i:1679506431;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pcit95jjn95qr5i07fph9er39m8138uu', '35.206.153.39', 1680070581, '__ci_last_regenerate|i:1680070581;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pdkkppkhdbfls07te439aniosfkc295m', '85.159.208.15', 1682024063, '__ci_last_regenerate|i:1682024063;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pgkk9jpp4hrh48lbhjdlsu060ksp3kpt', '51.75.172.216', 1679830411, '__ci_last_regenerate|i:1679830410;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('phhg8fai8h0e90cg7cmoe3o75c4gpjdn', '103.25.250.248', 1678860960, '__ci_last_regenerate|i:1678860960;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"bengali\";loggedin|b:1;alert-message-success|s:40:\"Information Has Been Saved Successfully \";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('piognsi74l29c4k0o6qofaf098k31cjg', '85.159.208.15', 1682024080, '__ci_last_regenerate|i:1682024080;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pjcr6lrni5fqpm3u1190aeue67v9eqt6', '103.25.251.239', 1679290944, '__ci_last_regenerate|i:1679290944;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pmkabavcublarqei1h6blbkbgqclqlkt', '31.13.127.31', 1680613672, '__ci_last_regenerate|i:1680613672;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('podnkm2m2md77jn4nljtnb0rbla503ga', '31.13.127.23', 1679547478, '__ci_last_regenerate|i:1679547478;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ppkjr3osaot0irui5f4d9s6hlg4u9rrl', '85.159.208.15', 1682024064, '__ci_last_regenerate|i:1682024064;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ppprfpeu1sgoua291nmgcdq9erpg1q38', '85.159.208.15', 1682024064, '__ci_last_regenerate|i:1682024064;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('prjvbilvr7bagabkgacs30phu1qcio0a', '85.159.208.15', 1682024062, '__ci_last_regenerate|i:1682024062;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('psh3nt22je0mvq8ek6m9ille37ta2hf3', '58.145.186.245', 1679080163, 'redirect_url|s:44:\"https://lab.elitedesign.com.bd/test/category\";__ci_last_regenerate|i:1679080163;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:85:\"তথ্য সফলভাবে সংরক্ষণ করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pskse3ihn1o6dfg9kq1hhlbkccvm1efn', '51.254.49.103', 1680917791, '__ci_last_regenerate|i:1680917791;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pumd4m7ultslg1hr3hvck293ej9tgpnb', '103.183.141.3', 1679136481, '__ci_last_regenerate|i:1679136481;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:31:\"পেমেন্ট সফল\";__ci_vars|a:2:{s:21:\"alert-message-success\";s:3:\"old\";s:10:\"active_tab\";s:3:\"old\";}active_tab|i:2;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('puti9o5nuqvqd1ifqvdfa0j539083d3i', '103.161.70.4', 1682027163, '__ci_last_regenerate|i:1682027149;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q0uenk6h8og95ncvs0j0nalqsm9nt40t', '103.25.248.247', 1678823080, '__ci_last_regenerate|i:1678823075;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%Y/%m/%d\";set_lang|s:7:\"english\";loggedin|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q4t8vnhvgd642lnsj3s74v62048ifd31', '103.25.250.248', 1678867493, '__ci_last_regenerate|i:1678867493;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q7tjg7487la2i8pp3hli4h3ckvcma2qe', '103.25.248.247', 1678824761, '__ci_last_regenerate|i:1678824761;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q81hjkiee1ed0ma959giabau1fggdp1k', '85.159.208.15', 1682024087, '__ci_last_regenerate|i:1682024087;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q950kliqf16n8a6f624krttm5ct79834', '85.159.208.15', 1682024061, '__ci_last_regenerate|i:1682024061;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qa9bpa6tnoaltp9js6j1oqj4btvjogq6', '173.252.79.8', 1680543871, '__ci_last_regenerate|i:1680543871;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qafjdv2h79lk28nr3ebaa4f0asnu3o7a', '58.145.186.245', 1679085868, '__ci_last_regenerate|i:1679085781;name|s:14:\"jahanara Begum\";uniqueid|s:7:\"77b79d5\";logger_photo|s:36:\"39bf842e7061e59e8d1283e4c1f9330b.jpg\";loggedin_id|s:1:\"3\";loggedin_role_id|s:1:\"6\";loggedin_userid|s:1:\"2\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:31:\"পেমেন্ট সফল\";__ci_vars|a:2:{s:21:\"alert-message-success\";s:3:\"old\";s:10:\"active_tab\";s:3:\"old\";}active_tab|i:2;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qg58io2bpovpdulfnad4tsp4l9lmvjkl', '103.31.154.252', 1679675346, '__ci_last_regenerate|i:1679675196;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qhqaccf6am61uoak1mggj64mifubsbuf', '85.159.208.15', 1682024057, '__ci_last_regenerate|i:1682024057;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qj6lj18fpt7cn3bhd11fibjpg0r6iuvu', '85.159.208.15', 1682024069, '__ci_last_regenerate|i:1682024069;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qmf1nugvmne0gnffg7arq41mgqfghl60', '85.159.208.15', 1682024087, '__ci_last_regenerate|i:1682024087;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qnvl7eau08ju624n6duqst304u2mioa1', '85.159.208.15', 1682024079, '__ci_last_regenerate|i:1682024079;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qojal4utlcbfninrjkno46l6r53lple6', '85.159.208.15', 1682024097, '__ci_last_regenerate|i:1682024097;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qr7k2sj3qq8u26rr8i36ktk4d4r5tqqe', '173.252.79.8', 1680452242, '__ci_last_regenerate|i:1680452242;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qv55hmis5d82t8o3977g9njdj00n413f', '66.220.149.119', 1679548027, '__ci_last_regenerate|i:1679548027;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('r076glp0t4tv8o4td19dp78n0afo7i2p', '85.159.208.15', 1682024069, '__ci_last_regenerate|i:1682024069;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('r11dv3r8n9eudok629jei38i493g3est', '58.145.186.245', 1679077816, 'redirect_url|s:44:\"https://lab.elitedesign.com.bd/test/category\";__ci_last_regenerate|i:1679077816;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:85:\"তথ্য সফলভাবে সংরক্ষণ করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('r1oubofj72nfpjt5lb1tnd8tvg6ckr57', '65.154.226.167', 1680545592, '__ci_last_regenerate|i:1680545591;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('r62fjncakflhn95i23idvqd7l4no2orb', '85.159.208.15', 1682024072, '__ci_last_regenerate|i:1682024072;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ramr2jhved0i93sg1mod6qa1vb4a61da', '85.159.208.15', 1682024075, '__ci_last_regenerate|i:1682024075;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rben47mh01hantb3a4lv1jdvdc203u5p', '103.25.248.253', 1679133290, '__ci_last_regenerate|i:1679133063;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rehchlmc2ibebjoo98pcafupmi4b7h5i', '103.25.251.231', 1679218040, '__ci_last_regenerate|i:1679218040;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ri214l4kr82c43odr7qp012vlo3r695q', '85.159.208.15', 1682024086, '__ci_last_regenerate|i:1682024086;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ribuh4jhqun82gh7c55uemop81sf6uki', '103.25.249.248', 1679548716, '__ci_last_regenerate|i:1679548716;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rjleifqc689icfo2ks2av30gguqfjaqs', '85.159.208.15', 1682024058, '__ci_last_regenerate|i:1682024058;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rldutpfh8lubp065bp1o1l0iah41u1f2', '85.159.208.15', 1682024080, '__ci_last_regenerate|i:1682024080;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rq6m02lnh3ld76vhatllduls923puba9', '85.159.208.15', 1682024078, '__ci_last_regenerate|i:1682024078;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rqnocrifkscb9i8asja63cb50i67b6rf', '172.111.57.93', 1682024416, '__ci_last_regenerate|i:1682024416;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rrjgj2aja0q6isntd6jkg8m697fprei4', '85.159.208.15', 1682024081, '__ci_last_regenerate|i:1682024081;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s04lhe0u2qfhvs98hpo3vpjk9eu7dbkl', '85.159.208.15', 1682024074, '__ci_last_regenerate|i:1682024074;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s0e6cjm9o32l59hce508h6h9qlm3ma1m', '85.159.208.15', 1682024098, '__ci_last_regenerate|i:1682024098;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s14fpv3i49735im5sqqioaoo1hu7kc6h', '85.159.208.15', 1682024085, '__ci_last_regenerate|i:1682024085;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s24i58rpdc58knn6r16ojo3svu6n8jt2', '85.159.208.15', 1682024090, '__ci_last_regenerate|i:1682024090;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s3k9bcmivtinf480ie2v4fi8u3m0kd4v', '103.25.248.247', 1678823075, '__ci_last_regenerate|i:1678823075;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s5sm2vflid0dtrhrsq4fgmefs4udjaep', '85.159.208.15', 1682024082, '__ci_last_regenerate|i:1682024082;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s79eqpf0ktqh82u0tek6uk90e0nsvidf', '85.159.208.15', 1682024073, '__ci_last_regenerate|i:1682024073;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('sehk3q0mpqmvnbg8pc9shlkbjdfp8vu6', '103.25.248.247', 1678821745, '__ci_last_regenerate|i:1678821745;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%Y/%m/%d\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:79:\"তথ্য সফলভাবে আপডেট করা হয়েছে\";__ci_vars|a:2:{s:21:\"alert-message-success\";s:3:\"old\";s:6:\"active\";s:3:\"old\";}active|i:2;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('seq8sqogkbp8kuum22sq0t59p2dsdmv3', '85.159.208.15', 1682024069, '__ci_last_regenerate|i:1682024069;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('sk9iu2f1mrgj1o68ntrvt78p1mgc3pv4', '85.159.208.15', 1682024078, '__ci_last_regenerate|i:1682024078;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('sm25ebqn668o3ts0m603nemblssp7bh1', '85.159.208.15', 1682024081, '__ci_last_regenerate|i:1682024081;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('sne2mufh0nq27pu0ss6i7bl94aggt2om', '85.159.208.15', 1682024068, '__ci_last_regenerate|i:1682024068;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('sqps8alltu5hb53dmm7thmq02u600hss', '85.159.208.15', 1682024056, '__ci_last_regenerate|i:1682024056;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('sr2l1afvi0jlllpfuh6339ah8pa46it0', '103.25.250.248', 1678860305, '__ci_last_regenerate|i:1678860305;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"bengali\";loggedin|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('sv0ss54ugaqg87es4lfm4uc6iqo99khc', '103.25.248.247', 1678823566, '__ci_last_regenerate|i:1678823565;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('t39u0r18jfganj2kuhm87lsef44rbkmk', '85.159.208.15', 1682024084, '__ci_last_regenerate|i:1682024084;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('t6pnv1c3naqs7topf8gtpf9661n40shm', '103.118.77.26', 1680616116, '__ci_last_regenerate|i:1680616116;name|s:12:\"Md Abu Sayed\";uniqueid|s:7:\"31b912e\";logger_photo|s:36:\"24b4e97a397240f4842e39aaf2820269.png\";loggedin_id|s:1:\"4\";loggedin_role_id|s:1:\"5\";loggedin_userid|s:1:\"3\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('t6vibkbk57pm84ekreggnj20bg59ige9', '85.159.208.15', 1682024054, '__ci_last_regenerate|i:1682024054;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('t8rh0u7vhst80p9ln8b6p277qc7u61ig', '103.25.249.250', 1678897900, '__ci_last_regenerate|i:1678897900;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('t9dtehg7oi8a0t9pjsf8l1ett2bv0oev', '85.159.208.15', 1682024070, '__ci_last_regenerate|i:1682024070;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('t9l706ua2vh9e8no41ij5dahcfaujtdm', '103.25.248.247', 1678825830, '__ci_last_regenerate|i:1678825572;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:85:\"তথ্য সফলভাবে সংরক্ষণ করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ta3158cis7lv8jkncgfc36l16kgsa8hr', '103.25.249.248', 1679547987, '__ci_last_regenerate|i:1679547987;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('taopmd47qo22dsarhherje12uktu5ghg', '85.159.208.15', 1682024091, '__ci_last_regenerate|i:1682024091;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tcdmrnsqncnet306n385vh7f9s2frabg', '94.124.161.156', 1682024414, '__ci_last_regenerate|i:1682024414;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('th4ejfa5l7ouam6ct8fgj57brjba0okp', '103.25.251.231', 1679217862, '__ci_last_regenerate|i:1679217813;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('titag07dp0gh8r26jjmndd4olvau2fu6', '103.25.248.226', 1679308993, '__ci_last_regenerate|i:1679308993;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tngrab459pami4n86vfig27id80cduv2', '91.193.6.10', 1678829594, '__ci_last_regenerate|i:1678829594;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tpvcp1529b3kifk3g4lmo0c0h1qabfcp', '85.159.208.15', 1682024064, '__ci_last_regenerate|i:1682024064;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tq15jfc72taldn63tbu5hvnb5fdjnel6', '103.25.251.237', 1679558773, '__ci_last_regenerate|i:1679558773;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ttmfruibn0ek1a47u3trl6r003dep88e', '85.159.208.15', 1682024081, '__ci_last_regenerate|i:1682024081;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tu92t7hcr3toe3opsk4jj1gmc5ll2u64', '35.206.153.39', 1680070598, '__ci_last_regenerate|i:1680070598;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('u022c2vcni08qatod37mc8f68gp60570', '85.159.208.15', 1682024087, '__ci_last_regenerate|i:1682024087;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('u13qsj12qd59bsp3ljnf0i61um2h4ebf', '85.159.208.15', 1682024068, '__ci_last_regenerate|i:1682024068;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('u2kvg5av580ho8pdj38h3n3ah94ks477', '85.159.208.15', 1682024091, '__ci_last_regenerate|i:1682024091;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('uakn7cqc4bp3lbrci71mshl93itpqt9q', '103.25.248.253', 1678905592, '__ci_last_regenerate|i:1678905592;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ub3mhl9c5metkit0hum1l9i883jvlbqt', '103.25.250.248', 1678859930, '__ci_last_regenerate|i:1678859929;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('udu6rn2msulta175f9ah0epuo49rfgbp', '51.255.62.14', 1680013105, '__ci_last_regenerate|i:1680013105;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('uebcmp6e4525vrk5o65i79q311bu78d6', '103.102.43.6', 1679552311, '__ci_last_regenerate|i:1679552310;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ui5t5pe3k9ffbigkkqop1ue10gi4fs8f', '85.159.208.15', 1682024077, '__ci_last_regenerate|i:1682024077;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('uk0gqqe8h0e0vdc8hn6i9dmgs4mo6fmu', '202.86.218.75', 1680545480, '__ci_last_regenerate|i:1680545480;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('umdr9roms7sv8qtmcv7ff6no8428nd2k', '138.36.94.219', 1682024415, '__ci_last_regenerate|i:1682024415;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('umh7lcb8qfiqe6mdt2eoj6stgcbhjhbv', '58.145.186.245', 1679068741, '__ci_last_regenerate|i:1679068741;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('upnu2tkmbdfdjtdc7gov81ruh46mb6kj', '138.36.94.219', 1682024416, '__ci_last_regenerate|i:1682024416;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('uppa6b51lkujbapt8r9801f581utct97', '85.159.208.15', 1682024088, '__ci_last_regenerate|i:1682024088;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('uprpd577240mh5nl6c15nklafo5r8khe', '58.145.186.245', 1679079557, 'redirect_url|s:44:\"https://lab.elitedesign.com.bd/test/category\";__ci_last_regenerate|i:1679079557;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:85:\"তথ্য সফলভাবে সংরক্ষণ করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('uqi16ofuul3bs7fqsdjsrfciabrejcfe', '85.159.208.15', 1682024077, '__ci_last_regenerate|i:1682024077;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ura5tlim645muvu5f9mfivmddtvp0g37', '85.159.208.15', 1682024061, '__ci_last_regenerate|i:1682024061;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('us0l0uq71a2a350p9gh38nm01i0n600n', '103.25.248.253', 1679126240, '__ci_last_regenerate|i:1679126240;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('uvhha2uh3svjaulu7ojgjbmnsfvhhve9', '103.25.248.247', 1678823784, '__ci_last_regenerate|i:1678823784;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v0ps5inijo21p6h8nf4kitpmn8bgcksq', '85.159.208.15', 1682024054, '__ci_last_regenerate|i:1682024054;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v58at0ktqa21l7d4clog6blhc1egm6bf', '85.159.208.15', 1682024083, '__ci_last_regenerate|i:1682024083;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v8a87fpqhesr2g87ukf19n9ss3nbcn76', '85.159.208.15', 1682024060, '__ci_last_regenerate|i:1682024060;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vbh9m73f2mcsod2kknm8apk2mlnomcla', '58.145.186.245', 1679085320, '__ci_last_regenerate|i:1679085320;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vg19u872el51v90q6pd54a2bj30npf5c', '103.183.141.3', 1679137435, '__ci_last_regenerate|i:1679137435;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"bengali\";loggedin|b:1;alert-message-success|s:31:\"পেমেন্ট সফল\";__ci_vars|a:2:{s:21:\"alert-message-success\";s:3:\"old\";s:10:\"active_tab\";s:3:\"old\";}active_tab|i:2;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vh0ilfdnu7cpkauc07e1lt4prisn7a1k', '103.25.250.248', 1678867476, '__ci_last_regenerate|i:1678867476;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"bengali\";loggedin|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vi8nmeu7cq755egep29mlnhong701h7l', '85.159.208.15', 1682024066, '__ci_last_regenerate|i:1682024066;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('viqv1e0mrqi0j9qrgogvq0jkp3rmiqak', '85.159.208.15', 1682024083, '__ci_last_regenerate|i:1682024083;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vj8vuun7fh9qk36thkdq0t32l6aurhp6', '103.25.250.248', 1678871500, '__ci_last_regenerate|i:1678871490;name|s:14:\"jahanara Begum\";uniqueid|s:7:\"77b79d5\";logger_photo|s:36:\"39bf842e7061e59e8d1283e4c1f9330b.jpg\";loggedin_id|s:1:\"3\";loggedin_role_id|s:1:\"6\";loggedin_userid|s:1:\"2\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;active_tab|i:3;__ci_vars|a:1:{s:10:\"active_tab\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vjcmjhmjvge6g7p3e7dcl97tv4vtouvt', '58.145.186.245', 1679084183, 'redirect_url|s:44:\"https://lab.elitedesign.com.bd/test/category\";__ci_last_regenerate|i:1679084183;name|s:25:\"Popular Diagnostic Center\";uniqueid|s:7:\"eb449b4\";logger_photo|s:36:\"c1ce54b0df1adf025ce3f9091ae77df1.png\";loggedin_id|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_userid|s:1:\"1\";date_format|s:8:\"%d-%b-%Y\";set_lang|s:7:\"english\";loggedin|b:1;alert-message-success|s:85:\"তথ্য সফলভাবে সংরক্ষণ করা হয়েছে\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vofsrhevq4n76i3ulvorjc5ks7m7t1or', '85.159.208.15', 1682024070, '__ci_last_regenerate|i:1682024070;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vpiqilr8e5stnagul9b6drgffbfs741m', '31.13.127.120', 1679335098, '__ci_last_regenerate|i:1679335097;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vrb1biveim7bl6j8sba73qdenmhdo0nm', '103.25.251.239', 1679295695, '__ci_last_regenerate|i:1679295695;');


#
# TABLE STRUCTURE FOR: email_config
#

DROP TABLE IF EXISTS `email_config`;

CREATE TABLE `email_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(200) DEFAULT NULL,
  `email_protocol` varchar(10) NOT NULL,
  `smtp_host` varchar(25) NOT NULL,
  `smtp_user` varchar(25) DEFAULT NULL,
  `smtp_pass` text NOT NULL,
  `smtp_port` varchar(100) NOT NULL,
  `smtp_encryption` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `email_config` (`id`, `email`, `email_protocol`, `smtp_host`, `smtp_user`, `smtp_pass`, `smtp_port`, `smtp_encryption`) VALUES (1, 'example@gmail.com', 'sendmail', 'smtp.gmail.com', 'example@gmail.com', '1234', '25', 'ssl');


#
# TABLE STRUCTURE FOR: email_templates
#

DROP TABLE IF EXISTS `email_templates`;

CREATE TABLE `email_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email_type` varchar(200) NOT NULL,
  `subject` varchar(250) NOT NULL,
  `template_body` longtext NOT NULL,
  `tags` longtext NOT NULL,
  `notified` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `email_templates` (`id`, `email_type`, `subject`, `template_body`, `tags`, `notified`) VALUES (1, 'account_registered', 'Account Registered', '', '{institute_name}, {name}, {username}, {password}, {user_role}, {login_url}', 0);
INSERT INTO `email_templates` (`id`, `email_type`, `subject`, `template_body`, `tags`, `notified`) VALUES (2, 'forgot_password', 'Forgot Password', '', '{institute_name}, {name}, {username}, {reset_url}', 0);
INSERT INTO `email_templates` (`id`, `email_type`, `subject`, `template_body`, `tags`, `notified`) VALUES (5, 'payslip_generated', 'Payslip generated', '', '{institute_name}, {name}, {month_year}, {payslip_no}, {payslip_url}', 0);
INSERT INTO `email_templates` (`id`, `email_type`, `subject`, `template_body`, `tags`, `notified`) VALUES (6, 'absent', 'Absent Notice', '', '{institute_name}, {name}, {date}', 0);
INSERT INTO `email_templates` (`id`, `email_type`, `subject`, `template_body`, `tags`, `notified`) VALUES (7, 'leave_approve', 'Your leave request has been approved', '', '{institute_name}, {name}, {admin_comments}, {start_date}, {end_date}', 0);
INSERT INTO `email_templates` (`id`, `email_type`, `subject`, `template_body`, `tags`, `notified`) VALUES (8, 'leave_reject', 'Your leave request has been reject', '', '{institute_name}, {name}, {admin_comments}, {start_date}, {end_date}', 0);
INSERT INTO `email_templates` (`id`, `email_type`, `subject`, `template_body`, `tags`, `notified`) VALUES (9, 'appointment_confirmation', 'Appointment Confirmation', '', '{institute_name}, {patient_name}, {doctor_name}, {consultation_fees}, {schedule_time}, {appointment_date}', 0);
INSERT INTO `email_templates` (`id`, `email_type`, `subject`, `template_body`, `tags`, `notified`) VALUES (10, 'appointment_canceled', 'Appointment Canceled', '', '{institute_name}, {patient_name}, {doctor_name}, {consultation_fees}, {schedule_time}, {appointment_date}', 0);


#
# TABLE STRUCTURE FOR: front_cms_about
#

DROP TABLE IF EXISTS `front_cms_about`;

CREATE TABLE `front_cms_about` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `page_title` varchar(255) NOT NULL,
  `content` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `about_image` varchar(255) NOT NULL,
  `elements` mediumtext NOT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_about` (`id`, `title`, `subtitle`, `page_title`, `content`, `banner_image`, `about_image`, `elements`, `meta_description`, `meta_keyword`) VALUES (1, 'Welcome to Hospitals', 'Best Medical &amp; Healthcare Needs to Our Patients', 'About Us', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut volutpat rutrum eros amet sollicitudin interdum. Suspendisse pulvinar, velit nec pharetra interdum, ante tellus ornare mi, et mollis tellus neque vitae elit. Mauris adipiscing mauris fringilla turpis interdum sed pulvinar nisi malesuada. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>\r\n\r\n<p>Donec sed odio dui. Nulla vitae elit libero, a pharetra augue. Nullam id dolor id nibh ultricies vehicula ut id elit. Integer posuere erat a ante venenatis dapibus posuere velit aliquet. Duis mollis, est non commodo luctus, nisi erat porttitor ligula. Mauris sit amet neque nec nunc gravida.</p>\r\n\r\n<div class=\"row\">\r\n<div class=\"col-sm-6 col-12\">\r\n<ul class=\"list-unstyled list-style-3\">\r\n	<li><a href=\"#\">Cardiothoracic Surgery</a></li>\r\n	<li><a href=\"#\">Cardiovascular Diseases</a></li>\r\n	<li><a href=\"#\">Ophthalmology</a></li>\r\n	<li><a href=\"#\">Dermitology</a></li>\r\n</ul>\r\n</div>\r\n\r\n<div class=\"col-sm-6 col-12\">\r\n<ul class=\"list-unstyled list-style-3\">\r\n	<li><a href=\"#\">Cardiothoracic Surgery</a></li>\r\n	<li><a href=\"#\">Cardiovascular Diseases</a></li>\r\n	<li><a href=\"#\">Ophthalmology</a></li>\r\n</ul>\r\n</div>\r\n</div>', 'about.jpg', 'about.jpg', '{\"cta_title\":\"Get in touch to join our community\",\"button_text\":\"Contact Our Office\",\"button_url\":\"contact\"}', '', '');


#
# TABLE STRUCTURE FOR: front_cms_appointment
#

DROP TABLE IF EXISTS `front_cms_appointment`;

CREATE TABLE `front_cms_appointment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `page_title` varchar(255) DEFAULT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_appointment` (`id`, `title`, `description`, `page_title`, `banner_image`, `meta_description`, `meta_keyword`) VALUES (1, 'একটি অ্যাপয়েন্টমেন্ট করুন', '<pre data-placeholder=\"অনুবাদ\" dir=\"ltr\" id=\"tw-target-text\">\r\nঅ্যাপয়েন্টমেন্ট করার জন্য একটি রিকুয়েস্ট করতে পারেন।</pre>\r\n', 'Appointment', 'appointment.jpg', '', '');


#
# TABLE STRUCTURE FOR: front_cms_contact
#

DROP TABLE IF EXISTS `front_cms_contact`;

CREATE TABLE `front_cms_contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `box_title` varchar(255) DEFAULT NULL,
  `box_description` varchar(500) DEFAULT NULL,
  `box_image` varchar(255) DEFAULT NULL,
  `form_title` varchar(355) DEFAULT NULL,
  `address` varchar(355) DEFAULT NULL,
  `phone` varchar(355) DEFAULT NULL,
  `email` varchar(355) DEFAULT NULL,
  `submit_text` varchar(355) NOT NULL,
  `map_iframe` text DEFAULT NULL,
  `page_title` varchar(255) NOT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_contact` (`id`, `box_title`, `box_description`, `box_image`, `form_title`, `address`, `phone`, `email`, `submit_text`, `map_iframe`, `page_title`, `banner_image`, `meta_description`, `meta_keyword`) VALUES (1, 'WE\'D LOVE TO HEAR FROM YOU', 'Fusce convallis diam vitae velit tempus rutrum. Donec nisl nisl, vulputate eu sapien sed, adipiscing vehicula massa. Mauris eget commodo neque, id molestie enim.', 'contact-info-box.png', 'Get in touch by filling the form below', '4896  Romrog Way, LOS ANGELES,\r\nCalifornia', '954-648-1802, \r\n963-612-1782', 'info@example.com\r\nsupport@example.com', 'Send', '<iframe width=\"100%\" height=\"350\" id=\"gmap_canvas\" src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3313.3833161665298!2d-118.03745848530627!3d33.85401093559897!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80dd2c6c97f8f3ed%3A0x47b1bde165dcc056!2sOak+Dr%2C+La+Palma%2C+CA+90623%2C+USA!5e0!3m2!1sen!2sbd!4v1544238752504\" frameborder=\"0\" scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\"></iframe>', 'Contact Us', 'contact.jpg', '', '');


#
# TABLE STRUCTURE FOR: front_cms_doctor_bio
#

DROP TABLE IF EXISTS `front_cms_doctor_bio`;

CREATE TABLE `front_cms_doctor_bio` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `doctor_id` varchar(20) NOT NULL,
  `biography` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: front_cms_doctors
#

DROP TABLE IF EXISTS `front_cms_doctors`;

CREATE TABLE `front_cms_doctors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` varchar(255) DEFAULT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_doctors` (`id`, `page_title`, `banner_image`, `meta_description`, `meta_keyword`) VALUES (1, 'Doctors', 'doctors.png', '', '');
INSERT INTO `front_cms_doctors` (`id`, `page_title`, `banner_image`, `meta_description`, `meta_keyword`) VALUES (2, 'Doctor Profile', 'doctor_profile.png', '', '');


#
# TABLE STRUCTURE FOR: front_cms_faq
#

DROP TABLE IF EXISTS `front_cms_faq`;

CREATE TABLE `front_cms_faq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `page_title` varchar(255) DEFAULT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_faq` (`id`, `title`, `description`, `page_title`, `banner_image`, `meta_description`, `meta_keyword`) VALUES (1, 'Frequently Asked Questions', '<p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident.</p>\r\n\r\n<p>Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven&#39;t heard of them accusamus labore sustainable VHS.</p>', 'Faq', 'faq.jpg', '', '');


#
# TABLE STRUCTURE FOR: front_cms_faq_list
#

DROP TABLE IF EXISTS `front_cms_faq_list`;

CREATE TABLE `front_cms_faq_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_faq_list` (`id`, `title`, `description`) VALUES (1, 'Any Information you provide on applications for disability, life or accidental insurance ?', '<p>\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco quat. It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.\r\n</p>\r\n<ul>\r\n<li>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</li>\r\n<li>Sed do eiusmod tempor incididunt ut labore et dolore magna aliq.</li>\r\n<li>Ut enim ad minim veniam, quis nostrud exercitation ullamco quat. It is a long established fact.</li>\r\n<li>That a reader will be distracted by the readable content of a page when looking at its layout.</li>\r\n<li>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</li>\r\n<li>Eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</li>\r\n<li>Quis nostrud exercitation ullamco quat. It is a long established fact that a reader will be distracted.</li>\r\n<li>Readable content of a page when looking at its layout.</li>\r\n<li>The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters.</li>\r\n<li>Opposed to using \'Content here, content here\', making it look like readable English.</li>\r\n</ul>');
INSERT INTO `front_cms_faq_list` (`id`, `title`, `description`) VALUES (2, 'Readable content of a page when looking at its layout ?', '<p>\r\n                                Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven\'t heard of them accusamus labore sustainable VHS.\r\n                            </p>\r\n                            <ol>\r\n                                <li>Quis nostrud exercitation ullamco quat. It is a long established fact that a reader will be distracted.</li>\r\n                                <li>Readable content of a page when looking at its layout.</li>\r\n                                <li>The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters.</li>\r\n                                <li>Opposed to using \'Content here, content here\', making it look like readable English.</li>\r\n                            </ol>\r\n                            <p>\r\n                                Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et.\r\n                            </p>');
INSERT INTO `front_cms_faq_list` (`id`, `title`, `description`) VALUES (3, 'Opposed to using \'Content here, content here\', making it look like readable English ?', '<p>\r\n                                Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven\'t heard of them accusamus labore sustainable VHS.\r\n                            </p>\r\n                            <ol>\r\n                                <li>Quis nostrud exercitation ullamco quat. It is a long established fact that a reader will be distracted.</li>\r\n                                <li>Readable content of a page when looking at its layout.</li>\r\n                                <li>The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters.</li>\r\n                                <li>Opposed to using \'Content here, content here\', making it look like readable English.</li>\r\n                            </ol>\r\n                            <p>\r\n                                Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et.\r\n                            </p>');
INSERT INTO `front_cms_faq_list` (`id`, `title`, `description`) VALUES (4, 'Readable content of a page when looking at its layout ?', '<p>\r\n                                Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven\'t heard of them accusamus labore sustainable VHS.\r\n                            </p>\r\n                            <ol>\r\n                                <li>Quis nostrud exercitation ullamco quat. It is a long established fact that a reader will be distracted.</li>\r\n                                <li>Readable content of a page when looking at its layout.</li>\r\n                                <li>The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters.</li>\r\n                                <li>Opposed to using \'Content here, content here\', making it look like readable English.</li>\r\n                            </ol>\r\n                            <p>\r\n                                Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et.\r\n                            </p>');
INSERT INTO `front_cms_faq_list` (`id`, `title`, `description`) VALUES (5, 'What types of documents are required to travel?', '<p><strong>Lorem ipsum</strong> dolor sit amet, an labores explicari qui, eu nostrum copiosae argumentum has. Latine propriae quo no, unum ridens expetenda id sit, at usu eius eligendi singulis. Sea ocurreret principes ne. At nonumy aperiri pri, nam quodsi copiosae intellegebat et, ex deserunt euripidis usu. Per ad ullum lobortis. Duo volutpat imperdiet ut, postea salutatus imperdiet ut per, ad utinam debitis invenire has.</p>\r\n\r\n<ol>\r\n	<li>labores explicari qui</li>\r\n	<li>labores explicari qui</li>\r\n	<li>labores explicari quilabores explicari qui</li>\r\n	<li>labores explicari qui</li>\r\n</ol>');


#
# TABLE STRUCTURE FOR: front_cms_home
#

DROP TABLE IF EXISTS `front_cms_home`;

CREATE TABLE `front_cms_home` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `item_type` varchar(20) NOT NULL,
  `description` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `elements` mediumtext NOT NULL,
  `active` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `active`) VALUES (1, 'আমরা দ্রুত এবং নির্ভরযোগ্য', 'চিকিৎসা এবং স্বাস্থ্যসেবা প্রয়োজন', 'wellcome', 'আমারা সময়ের সাথে যুগউপযোগী সেবা প্রদান করে থাকি।বাংলাদেশের নাম্বার ওয়ান ডায়াগনস্টিক সেন্টার হল পপুলার ডায়াগনস্টিক সেন্টার।আমরা সর্বদা আপনাদের সেবা প্রদান করার লক্ষ্যে ব্রত থাকি।যেকোন সময় আমাদের সেবা গ্রহণ করার ক্ষেত্রে আমাদেরকে ফোন করুন।', '{\"image\":\"wellcome.png\"}', 0);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `active`) VALUES (2, 'আমাদের অভিজ্ঞ ডাক্তার দল', NULL, 'doctors', 'আমাদের সকল অভিজ্ঞ ডাক্তার  গন্দের তালিকা নিচে দেওয়া হল', '{\"doctor_start\":\"1\",\"image\":\"featured-parallax.jpg\"}', 0);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `active`) VALUES (3, 'আমাদের সেরা মেডিক্যাল সেবা', NULL, 'services', 'আমাদের কিছু সেরা মেডিক্যাল সেবা নিচে দেওয়া হল।', '', 0);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `active`) VALUES (4, 'অনলাইন ঝামেলা মুক্ত অ্যাপয়েন্টমেন্ট বুকিং', 'Medical Services', 'cta', '', '{\"mobile_no\":\"+\\u09ee\\u09ee\\u09e6\\u09e7\\u09ed\\u09ed\\u09eb\\u09ea\\u09eb\\u09ed\\u09e6\\u09e6\\u09ee\",\"button_text\":\"\\u0986\\u09aa\\u09a8\\u09be\\u09b0 \\u0985\\u09cd\\u09af\\u09be\\u09aa\\u09af\\u09bc\\u09c7\\u09a8\\u09cd\\u099f\\u09ae\\u09c7\\u09a8\\u09cd\\u099f \\u09ac\\u09c1\\u0995 \\u0995\\u09b0\\u09c1\\u09a8\",\"button_url\":\"appointment\",\"image\":\"appointment-booking-img.png\"}', 0);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `active`) VALUES (5, 'সেরা <span>ডিজিটাল</span> ল্যাব টেস্ট', NULL, 'slider', 'বাংলাদেশে এই প্রথম আমারাই ডিজিতাল পদ্ধতিতে বিভিন্ন ধরনের প্যাথলজি ল্যাব টেস্ট করে থাকি।এবং উহার রিপোর্ট অনলাইন অথবা অফলাইনে ডেলিভারি প্রদান করে থাকি।', '{\"position\":\"c-left\",\"button_text1\":\"\\u0986\\u09ae\\u09be\\u09a6\\u09c7\\u09b0 \\u09b8\\u09c7\\u09ac\\u09be \\u09b8\\u09ae\\u09c2\\u09b9\",\"button_url1\":\"#\",\"button_text2\":\"\\u09ac\\u09bf\\u09b8\\u09cd\\u09a4\\u09be\\u09b0\\u09bf\\u09a4 \\u099c\\u09be\\u09a8\\u09c1\\u09a8\",\"button_url2\":\"#\",\"image\":\"home-slider-1678826053.jpg\"}', 0);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `active`) VALUES (6, 'সেরা <span> মেডিক্যাল </span> প্রদানকারী', NULL, 'slider', 'বাংলাদেশে আমরাই প্রথম মেডিক্যাল সেবা প্রদান করার লক্ষে আধুনিক ডায়াগনস্টিক সেন্টার গড়ে তুলি।আমাদের এই প্রতিষ্ঠানে সকল ধরনের মেডিক্যাল সেবা প্রদান করি।', '{\"position\":\"c-center\",\"button_text1\":\"\\u09ac\\u09bf\\u09b8\\u09cd\\u09a4\\u09be\\u09b0\\u09bf\\u09a4 \\u099c\\u09be\\u09a8\\u09c1\\u09a8\",\"button_url1\":\"#\",\"button_text2\":\"\\u098f\\u0996\\u09a8\\u09bf \\u09b6\\u09c1\\u09b0\\u09c1 \\u0995\\u09b0\\u09c1\\u09a8\",\"button_url2\":\"#\",\"image\":\"home-slider-1678825928.jpg\"}', 0);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `active`) VALUES (7, 'আমাদের রয়েছে <span>দক্ষ</span> ডাক্তারদের দল', NULL, 'slider', 'আমাদের রয়েছে দক্ষ ডাক্তারদের দল।আমাদের সকল ডাক্তারগন উচ্চ শিক্ষিত, এবং তাদের রয়েছে বিভিন্ন স্বনামধন্য প্রতিষ্ঠানে প্র্যাকটিস করার অভিজ্ঞতা।', '{\"position\":\"c-right\",\"button_text1\":\"\\u09ac\\u09bf\\u09b8\\u09cd\\u09a4\\u09be\\u09b0\\u09bf\\u09a4 \\u099c\\u09be\\u09a8\\u09c1\\u09a8\",\"button_url1\":\"#\",\"button_text2\":\"\\u0986\\u09ae\\u09be\\u09a6\\u09c7\\u09b0 \\u09b8\\u09be\\u09a5\\u09c7 \\u09af\\u09cb\\u0997\\u09be\\u09af\\u09cb\\u0997 \\u0995\\u09b0\\u09c1\\u09a8\",\"button_url2\":\"contact\",\"image\":\"home-slider-1678826257.jpg\"}', 0);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `active`) VALUES (8, 'যোগ্য ডাক্তার', NULL, 'features', 'আমাদের রয়েছে দক্ষ ডাক্তারদের টিম। যারা সবসময় আপনাদের সেবা প্রদান করার লক্ষ্যে নিয়োজিত রয়েছেন।', '{\"button_text\":\"\\u09ac\\u09bf\\u09b8\\u09cd\\u09a4\\u09be\\u09b0\\u09bf\\u09a4 \\u099c\\u09be\\u09a8\\u09c1\\u09a8\",\"button_url\":\"#\",\"icon\":\"fas fa-user-md\"}', 0);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `active`) VALUES (9, 'নিয়মিত চেকআপ', NULL, 'features', 'আপনারা চাইলে যেকোন সময় আমাদের ডায়াগনস্টিক সেন্টার থেকে নিয়মিত চেক-আপ এর সুবিধা।', '{\"button_text\":\"\\u09ac\\u09bf\\u09b8\\u09cd\\u09a4\\u09be\\u09b0\\u09bf\\u09a4 \\u099c\\u09be\\u09a8\\u09c1\\u09a8\",\"button_url\":\"#\",\"icon\":\"fas fa-stethoscope\"}', 0);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `active`) VALUES (10, 'ল্যাব টেস্ট', NULL, 'features', 'আমাদের রয়েছে আধুনিক টেস্ট ল্যাব। এতে রয়েছে আধুনিক ডিজিটাল ল্যাব টেস্ট মেশিন সমূহ।', '{\"button_text\":\"\\u09ac\\u09bf\\u09b8\\u09cd\\u09a4\\u09be\\u09b0\\u09bf\\u09a4 \\u099c\\u09be\\u09a8\\u09c1\\u09a8\",\"button_url\":\"#\",\"icon\":\"fas fa-vial\"}', 0);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `active`) VALUES (11, '২৪ ঘণ্টা কাস্টমার সার্ভিস', NULL, 'features', 'আমাদের রয়েছে ২৪ ঘণ্টা কাস্টমার সার্ভিস।আমাদের বছরের ৩৬৫ টি খোলা।', '{\"button_text\":\"\\u09ac\\u09bf\\u09b8\\u09cd\\u09a4\\u09be\\u09b0\\u09bf\\u09a4 \\u099c\\u09be\\u09a8\\u09c1\\u09a8\",\"button_url\":\"#\",\"icon\":\"far fa-clock\"}', 0);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `active`) VALUES (12, 'আমাদের সুখী রোগীদের মতামত', NULL, 'testimonial', 'আমাদের কিছু রোগীদের মতামত নিচে দেওয়া হল।', '', 0);


#
# TABLE STRUCTURE FOR: front_cms_home_seo
#

DROP TABLE IF EXISTS `front_cms_home_seo`;

CREATE TABLE `front_cms_home_seo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` varchar(255) NOT NULL,
  `meta_keyword` text NOT NULL,
  `meta_description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_home_seo` (`id`, `page_title`, `meta_keyword`, `meta_description`) VALUES (1, 'হোমপেইজ', '', '');


#
# TABLE STRUCTURE FOR: front_cms_menu
#

DROP TABLE IF EXISTS `front_cms_menu`;

CREATE TABLE `front_cms_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `alias` varchar(100) NOT NULL,
  `ordering` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT 0,
  `open_new_tab` int(11) NOT NULL DEFAULT 0,
  `ext_url` int(11) NOT NULL DEFAULT 0,
  `ext_url_address` text DEFAULT NULL,
  `publish` int(11) NOT NULL,
  `system` varchar(10) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `created_at`) VALUES (1, 'হোম পেইজ', 'index', 1, 0, 0, 0, '', 1, '1', '2019-08-09 18:18:54');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `created_at`) VALUES (2, 'এপয়েন্টমেন্ট', 'appointment', 3, 0, 0, 0, '', 1, '1', '2019-08-09 18:18:54');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `created_at`) VALUES (3, 'ডাক্তারগন', 'doctors', 2, 0, 0, 0, '', 1, '1', '2019-08-09 18:18:54');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `created_at`) VALUES (4, 'আমাদের সম্পর্কে', 'about', 4, 0, 0, 0, '', 1, '1', '2019-08-09 18:18:54');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `created_at`) VALUES (5, 'এফএকিউ', 'faq', 5, 0, 0, 0, '', 1, '1', '2019-08-09 18:18:54');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `created_at`) VALUES (6, 'আমাদের সাথে যোগাযোগ করুন', 'contact', 6, 0, 0, 0, '', 1, '1', '2019-08-09 18:18:54');


#
# TABLE STRUCTURE FOR: front_cms_pages
#

DROP TABLE IF EXISTS `front_cms_pages`;

CREATE TABLE `front_cms_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` varchar(255) NOT NULL,
  `content` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `menu_id` int(11) NOT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: front_cms_services
#

DROP TABLE IF EXISTS `front_cms_services`;

CREATE TABLE `front_cms_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `parallax_image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_services` (`id`, `title`, `subtitle`, `parallax_image`) VALUES (1, 'Get Well Soon', 'Our Hosptial <span>Services</span>', 'service_parallax.jpg');


#
# TABLE STRUCTURE FOR: front_cms_services_list
#

DROP TABLE IF EXISTS `front_cms_services_list`;

CREATE TABLE `front_cms_services_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_services_list` (`id`, `title`, `description`, `icon`) VALUES (1, 'ফার্স্ট এইড', 'আমাদের রয়েছে ফার্স্ট এইড সেবা , যেকোন রুগি সেই সেবা খুব সহজে গ্রহণ করতে পারেন।', 'fas fa-medal');
INSERT INTO `front_cms_services_list` (`id`, `title`, `description`, `icon`) VALUES (2, 'ডেন্টাল কেয়ার', 'আমাদের রয়েছে ডেন্টাল কেয়ার ইউনিট।', 'fas fa-heartbeat');
INSERT INTO `front_cms_services_list` (`id`, `title`, `description`, `icon`) VALUES (3, '24x7 এ্যাম্বুলেন্স', 'আমাদের রয়েছে  24x7 এ্যাম্বুলেন্স সার্ভিস।', 'fas fa-ambulance');
INSERT INTO `front_cms_services_list` (`id`, `title`, `description`, `icon`) VALUES (4, 'প্যাথলজি ল্যাব', 'আমাদের রয়েছে আধুনিক প্যাথলজি ল্যাব।', 'fas fa-capsules');
INSERT INTO `front_cms_services_list` (`id`, `title`, `description`, `icon`) VALUES (5, 'অভিজ্ঞ ডাক্তার', 'আমাদের রয়েছে অভিজ্ঞ ডাক্তার এর দল।', 'fas fa-stethoscope');
INSERT INTO `front_cms_services_list` (`id`, `title`, `description`, `icon`) VALUES (6, 'ফার্মেসী', 'আমাদের রয়েছে সেরা ফার্মেসী।', 'fas fa-medkit');


#
# TABLE STRUCTURE FOR: front_cms_setting
#

DROP TABLE IF EXISTS `front_cms_setting`;

CREATE TABLE `front_cms_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `application_title` varchar(255) NOT NULL,
  `captcha_status` varchar(20) NOT NULL,
  `recaptcha_site_key` varchar(255) NOT NULL,
  `recaptcha_secret_key` varchar(255) NOT NULL,
  `address` varchar(350) NOT NULL,
  `mobile_no` varchar(60) NOT NULL,
  `fax` varchar(60) NOT NULL,
  `receive_contact_email` varchar(255) NOT NULL,
  `email` varchar(60) NOT NULL,
  `footer_text` varchar(255) NOT NULL,
  `fav_icon` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `working_hours` varchar(300) NOT NULL,
  `facebook_url` varchar(100) NOT NULL,
  `twitter_url` varchar(100) NOT NULL,
  `youtube_url` varchar(100) NOT NULL,
  `google_plus` varchar(100) NOT NULL,
  `linkedin_url` varchar(100) NOT NULL,
  `pinterest_url` varchar(100) NOT NULL,
  `instagram_url` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_setting` (`id`, `application_title`, `captcha_status`, `recaptcha_site_key`, `recaptcha_secret_key`, `address`, `mobile_no`, `fax`, `receive_contact_email`, `email`, `footer_text`, `fav_icon`, `logo`, `working_hours`, `facebook_url`, `twitter_url`, `youtube_url`, `google_plus`, `linkedin_url`, `pinterest_url`, `instagram_url`) VALUES (1, 'পপুলার ডায়াগনস্টিক সেন্টার', 'disable', '', '', 'হাউজঃ মুন্সি বাড়ি, নয়ার হাট হাই স্কুল সংলগ্ন, বড়বাড়ি, লালমনির হাট।', '+৮৮০১৭৭৫৪৫৭০০৮', '+৮৮০১৭৭৫৪৫৭০০৮', 'info@elitedesign.com.bd', 'info@elitedesign.com.bd', '© ২০২০ <span>পপুলার ডায়াগনস্টিক সেন্টার</span>, সকল কিছুর স্বত্বাধিকার', 'fav_icon.png', 'logo.png', '<span>সময়: </span>  শনি থেকে শুক্রবার - সকাল ৯:০০ থেকে ০৮:০০,  (২৪ ঘন্টা খোলা)', 'https://facebook.com/elitedesignbd', 'https://twitter.com/elitedesignbd', 'https://youtube.com/@/elitedesignbd', 'https://google.com', 'https://linkedin.com', 'https://pinterest.com', 'https://instagram.com');


#
# TABLE STRUCTURE FOR: front_cms_testimonial
#

DROP TABLE IF EXISTS `front_cms_testimonial`;

CREATE TABLE `front_cms_testimonial` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_name` varchar(255) NOT NULL,
  `surname` varchar(355) NOT NULL,
  `image` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `rank` int(5) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_testimonial` (`id`, `patient_name`, `surname`, `image`, `description`, `rank`, `created_by`, `created_at`) VALUES (1, 'মোঃ শামিম খান', 'বিজনেসম্যান', 'user-1678828763.png', 'আমি পপুলার ডায়াগনস্টিক সেন্টার এর প্যাথলজি টেস্ট নিয়ে খুব সন্তুষ্ট। তারা সবসময় সঠিক ও নিরভুল টেস্ট করে থাকে।', 1, 1, '2019-08-23 18:26:42');
INSERT INTO `front_cms_testimonial` (`id`, `patient_name`, `surname`, `image`, `description`, `rank`, `created_by`, `created_at`) VALUES (2, 'জাহানারা খানম', 'গৃহিণী', 'user-1678827957.jpg', 'পপুলার ডায়াগনস্টিক এর সেবা পেয়ে খুব আনন্দিত।পপুলার ডায়াগনস্টিক সেন্টার খুব কম টাকায় ল্যাব টেস্ট করে থাকে।', 4, 1, '2019-08-23 18:26:42');
INSERT INTO `front_cms_testimonial` (`id`, `patient_name`, `surname`, `image`, `description`, `rank`, `created_by`, `created_at`) VALUES (3, 'মোঃ নাইম হোসেন', 'স্টুডেন্ট', 'user-1678828077.png', 'পপুলার ডায়াগনস্টিক সেন্টার সবসময় কাস্টমারদের সঠিক সেবা প্রদান করার জন্য প্রস্তুত থাকে, ধন্যবাদ পপুলার ডায়াগনস্টিক সেন্টারকে।', 5, 1, '2019-08-23 18:26:42');
INSERT INTO `front_cms_testimonial` (`id`, `patient_name`, `surname`, `image`, `description`, `rank`, `created_by`, `created_at`) VALUES (4, 'শাহিদা আক্তার', 'গৃহিণী', 'user-1678828211.png', 'আমার দেখা খুব ভালো একটি ডায়াগনস্টিক প্রতিষ্ঠান। এখানে আমি আমার MRI করেছি, তারা খুব নির্ভুল টেস্ট প্রদান করেছে।', 3, 1, '2019-08-23 18:26:42');


#
# TABLE STRUCTURE FOR: global_settings
#

DROP TABLE IF EXISTS `global_settings`;

CREATE TABLE `global_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `institute_name` varchar(255) NOT NULL,
  `institute_email` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `mobileno` varchar(50) NOT NULL,
  `currency` varchar(50) NOT NULL,
  `currency_symbol` varchar(50) NOT NULL,
  `translation` varchar(20) NOT NULL,
  `footer_text` text NOT NULL,
  `animations` varchar(50) NOT NULL,
  `timezone` varchar(30) NOT NULL,
  `date_format` varchar(20) CHARACTER SET utf32 COLLATE utf32_unicode_ci NOT NULL,
  `facebook_url` varchar(255) NOT NULL,
  `twitter_url` varchar(255) NOT NULL,
  `linkedin_url` varchar(255) NOT NULL,
  `youtube_url` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `global_settings` (`id`, `institute_name`, `institute_email`, `address`, `mobileno`, `currency`, `currency_symbol`, `translation`, `footer_text`, `animations`, `timezone`, `date_format`, `facebook_url`, `twitter_url`, `linkedin_url`, `youtube_url`, `created_at`, `updated_at`) VALUES (1, 'Popular Diagnostic Center', 'Ramom@example.com', 'হাউজঃ মুন্সি বাড়ি, নয়ার হাট হাই স্কুল সংলগ্ন,বড়বাড়ী, লালমনির হাট', '+8801775457008', 'BDT', '৳', 'english', '© ২০২২ পপুলার ডায়াগনস্টিক - সফটওয়্যার এর কারিগরি সহযোগিতায় এলিট ডিজাইন', 'fadeInUp', 'Asia/Dhaka', '%d-%b-%Y', 'https://facebook.com/elitedesignbd', 'https://twitter.com/elitedesignbd', 'https://linkedin.com/elitedesignbd', 'https://youtube.com/@/elitedesignbd', '2018-10-22 15:07:49', '2023-03-14 16:01:10');


#
# TABLE STRUCTURE FOR: lab_report_template
#

DROP TABLE IF EXISTS `lab_report_template`;

CREATE TABLE `lab_report_template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `template` longtext NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `lab_report_template` (`id`, `name`, `template`, `created_at`, `updated_at`) VALUES (13, '2D ECHOCARDIOGRAM', '<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:500px;\">\r\n	<tbody>\r\n		<tr>\r\n			<td>Test name</td>\r\n			<td>Result</td>\r\n			<td>Normal Value</td>\r\n		</tr>\r\n		<tr>\r\n			<td>HB</td>\r\n			<td>12g</td>\r\n			<td>12g -16g</td>\r\n		</tr>\r\n		<tr>\r\n			<td>RBC</td>\r\n			<td>4.2lac</td>\r\n			<td>4 lac to 6lac</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n', '2023-03-17 16:11:06', '2023-03-17 16:11:06');
INSERT INTO `lab_report_template` (`id`, `name`, `template`, `created_at`, `updated_at`) VALUES (15, 'Consultation', '<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:500px;\">\r\n	<tbody>\r\n		<tr>\r\n			<td>Test name</td>\r\n			<td>Result</td>\r\n			<td>Normal Value</td>\r\n		</tr>\r\n		<tr>\r\n			<td>HB</td>\r\n			<td>12g</td>\r\n			<td>12g -16g</td>\r\n		</tr>\r\n		<tr>\r\n			<td>RBC</td>\r\n			<td>4.2lac</td>\r\n			<td>4 lac to 6lac</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n', '2023-03-17 16:12:26', '2023-03-17 16:12:26');
INSERT INTO `lab_report_template` (`id`, `name`, `template`, `created_at`, `updated_at`) VALUES (16, 'ECG', '<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:500px;\">\r\n	<tbody>\r\n		<tr>\r\n			<td>Test name</td>\r\n			<td>Result</td>\r\n			<td>Normal Value</td>\r\n		</tr>\r\n		<tr>\r\n			<td>HB</td>\r\n			<td>12g</td>\r\n			<td>12g -16g</td>\r\n		</tr>\r\n		<tr>\r\n			<td>RBC</td>\r\n			<td>4.2lac</td>\r\n			<td>4 lac to 6lac</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n', '2023-03-17 16:12:53', '2023-03-17 16:12:53');
INSERT INTO `lab_report_template` (`id`, `name`, `template`, `created_at`, `updated_at`) VALUES (17, 'Colonoscopy Report', '<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:500px;\">\r\n	<tbody>\r\n		<tr>\r\n			<td>Test name</td>\r\n			<td>Result</td>\r\n			<td>Normal Value</td>\r\n		</tr>\r\n		<tr>\r\n			<td>HB</td>\r\n			<td>12g</td>\r\n			<td>12g -16g</td>\r\n		</tr>\r\n		<tr>\r\n			<td>RBC</td>\r\n			<td>4.2lac</td>\r\n			<td>4 lac to 6lac</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n', '2023-03-17 16:13:16', '2023-03-17 16:13:16');
INSERT INTO `lab_report_template` (`id`, `name`, `template`, `created_at`, `updated_at`) VALUES (18, 'Endoscopy Report', '<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:500px;\">\r\n	<tbody>\r\n		<tr>\r\n			<td>Test name</td>\r\n			<td>Result</td>\r\n			<td>Normal Value</td>\r\n		</tr>\r\n		<tr>\r\n			<td>HB</td>\r\n			<td>12g</td>\r\n			<td>12g -16g</td>\r\n		</tr>\r\n		<tr>\r\n			<td>RBC</td>\r\n			<td>4.2lac</td>\r\n			<td>4 lac to 6lac</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n', '2023-03-17 16:13:37', '2023-03-17 16:13:37');
INSERT INTO `lab_report_template` (`id`, `name`, `template`, `created_at`, `updated_at`) VALUES (19, 'TMT (TREADMIL Test)', '<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:500px;\">\r\n	<tbody>\r\n		<tr>\r\n			<td>Test name</td>\r\n			<td>Result</td>\r\n			<td>Normal Value</td>\r\n		</tr>\r\n		<tr>\r\n			<td>HB</td>\r\n			<td>12g</td>\r\n			<td>12g -16g</td>\r\n		</tr>\r\n		<tr>\r\n			<td>RBC</td>\r\n			<td>4.2lac</td>\r\n			<td>4 lac to 6lac</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n', '2023-03-17 16:14:09', '2023-03-17 16:14:09');
INSERT INTO `lab_report_template` (`id`, `name`, `template`, `created_at`, `updated_at`) VALUES (20, 'Doppler Abdomen', '<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:500px;\">\r\n	<tbody>\r\n		<tr>\r\n			<td>Test name</td>\r\n			<td>Result</td>\r\n			<td>Normal Value</td>\r\n		</tr>\r\n		<tr>\r\n			<td>HB</td>\r\n			<td>12g</td>\r\n			<td>12g -16g</td>\r\n		</tr>\r\n		<tr>\r\n			<td>RBC</td>\r\n			<td>4.2lac</td>\r\n			<td>4 lac to 6lac</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n', '2023-03-17 16:14:49', '2023-03-17 16:14:49');
INSERT INTO `lab_report_template` (`id`, `name`, `template`, `created_at`, `updated_at`) VALUES (21, 'Doppler Carotid', '<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:500px;\">\r\n	<tbody>\r\n		<tr>\r\n			<td>Test name</td>\r\n			<td>Result</td>\r\n			<td>Normal Value</td>\r\n		</tr>\r\n		<tr>\r\n			<td>HB</td>\r\n			<td>12g</td>\r\n			<td>12g -16g</td>\r\n		</tr>\r\n		<tr>\r\n			<td>RBC</td>\r\n			<td>4.2lac</td>\r\n			<td>4 lac to 6lac</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n', '2023-03-17 16:15:06', '2023-03-17 16:15:06');
INSERT INTO `lab_report_template` (`id`, `name`, `template`, `created_at`, `updated_at`) VALUES (22, 'Doppler Lower Limb (Both) Arterial', '<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:500px;\">\r\n	<tbody>\r\n		<tr>\r\n			<td>Test name</td>\r\n			<td>Result</td>\r\n			<td>Normal Value</td>\r\n		</tr>\r\n		<tr>\r\n			<td>HB</td>\r\n			<td>12g</td>\r\n			<td>12g -16g</td>\r\n		</tr>\r\n		<tr>\r\n			<td>RBC</td>\r\n			<td>4.2lac</td>\r\n			<td>4 lac to 6lac</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n', '2023-03-17 16:15:25', '2023-03-17 16:15:25');
INSERT INTO `lab_report_template` (`id`, `name`, `template`, `created_at`, `updated_at`) VALUES (23, 'Doppler Lower Limb (Both) Arterial &Venous', '<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:500px;\">\r\n	<tbody>\r\n		<tr>\r\n			<td>Test name</td>\r\n			<td>Result</td>\r\n			<td>Normal Value</td>\r\n		</tr>\r\n		<tr>\r\n			<td>HB</td>\r\n			<td>12g</td>\r\n			<td>12g -16g</td>\r\n		</tr>\r\n		<tr>\r\n			<td>RBC</td>\r\n			<td>4.2lac</td>\r\n			<td>4 lac to 6lac</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n', '2023-03-17 16:15:43', '2023-03-17 16:15:43');
INSERT INTO `lab_report_template` (`id`, `name`, `template`, `created_at`, `updated_at`) VALUES (24, 'Doppler Lower Limb (Both) Venous', '<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:500px;\">\r\n	<tbody>\r\n		<tr>\r\n			<td>Test name</td>\r\n			<td>Result</td>\r\n			<td>Normal Value</td>\r\n		</tr>\r\n		<tr>\r\n			<td>HB</td>\r\n			<td>12g</td>\r\n			<td>12g -16g</td>\r\n		</tr>\r\n		<tr>\r\n			<td>RBC</td>\r\n			<td>4.2lac</td>\r\n			<td>4 lac to 6lac</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n', '2023-03-17 16:16:04', '2023-03-17 16:16:04');
INSERT INTO `lab_report_template` (`id`, `name`, `template`, `created_at`, `updated_at`) VALUES (25, 'Doppler Lower Limb (Single ) Venous', '<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:500px;\">\r\n	<tbody>\r\n		<tr>\r\n			<td>Test name</td>\r\n			<td>Result</td>\r\n			<td>Normal Value</td>\r\n		</tr>\r\n		<tr>\r\n			<td>HB</td>\r\n			<td>12g</td>\r\n			<td>12g -16g</td>\r\n		</tr>\r\n		<tr>\r\n			<td>RBC</td>\r\n			<td>4.2lac</td>\r\n			<td>4 lac to 6lac</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n', '2023-03-17 16:16:23', '2023-03-17 16:16:23');
INSERT INTO `lab_report_template` (`id`, `name`, `template`, `created_at`, `updated_at`) VALUES (26, 'Doppler Lower Limb (Single) Arterial', '<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:500px;\">\r\n	<tbody>\r\n		<tr>\r\n			<td>Test name</td>\r\n			<td>Result</td>\r\n			<td>Normal Value</td>\r\n		</tr>\r\n		<tr>\r\n			<td>HB</td>\r\n			<td>12g</td>\r\n			<td>12g -16g</td>\r\n		</tr>\r\n		<tr>\r\n			<td>RBC</td>\r\n			<td>4.2lac</td>\r\n			<td>4 lac to 6lac</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n', '2023-03-17 16:16:52', '2023-03-17 16:16:52');
INSERT INTO `lab_report_template` (`id`, `name`, `template`, `created_at`, `updated_at`) VALUES (27, 'Doppler Lower Limb (Single) Arterial & Venous', '<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:500px;\">\r\n	<tbody>\r\n		<tr>\r\n			<td>Test name</td>\r\n			<td>Result</td>\r\n			<td>Normal Value</td>\r\n		</tr>\r\n		<tr>\r\n			<td>HB</td>\r\n			<td>12g</td>\r\n			<td>12g -16g</td>\r\n		</tr>\r\n		<tr>\r\n			<td>RBC</td>\r\n			<td>4.2lac</td>\r\n			<td>4 lac to 6lac</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n', '2023-03-17 16:17:21', '2023-03-17 16:17:21');
INSERT INTO `lab_report_template` (`id`, `name`, `template`, `created_at`, `updated_at`) VALUES (28, 'Doppler Placental ( Fetal )', '<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:500px;\">\r\n	<tbody>\r\n		<tr>\r\n			<td>Test name</td>\r\n			<td>Result</td>\r\n			<td>Normal Value</td>\r\n		</tr>\r\n		<tr>\r\n			<td>HB</td>\r\n			<td>12g</td>\r\n			<td>12g -16g</td>\r\n		</tr>\r\n		<tr>\r\n			<td>RBC</td>\r\n			<td>4.2lac</td>\r\n			<td>4 lac to 6lac</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n', '2023-03-17 16:17:36', '2023-03-17 16:17:36');
INSERT INTO `lab_report_template` (`id`, `name`, `template`, `created_at`, `updated_at`) VALUES (29, 'Doppler Portal', '<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:500px;\">\r\n	<tbody>\r\n		<tr>\r\n			<td>Test name</td>\r\n			<td>Result</td>\r\n			<td>Normal Value</td>\r\n		</tr>\r\n		<tr>\r\n			<td>HB</td>\r\n			<td>12g</td>\r\n			<td>12g -16g</td>\r\n		</tr>\r\n		<tr>\r\n			<td>RBC</td>\r\n			<td>4.2lac</td>\r\n			<td>4 lac to 6lac</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n', '2023-03-17 16:18:00', '2023-03-17 16:18:00');
INSERT INTO `lab_report_template` (`id`, `name`, `template`, `created_at`, `updated_at`) VALUES (30, 'Doppler Pregnancy', '<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:500px;\">\r\n	<tbody>\r\n		<tr>\r\n			<td>Test name</td>\r\n			<td>Result</td>\r\n			<td>Normal Value</td>\r\n		</tr>\r\n		<tr>\r\n			<td>HB</td>\r\n			<td>12g</td>\r\n			<td>12g -16g</td>\r\n		</tr>\r\n		<tr>\r\n			<td>RBC</td>\r\n			<td>4.2lac</td>\r\n			<td>4 lac to 6lac</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n', '2023-03-17 16:18:21', '2023-03-17 16:18:21');
INSERT INTO `lab_report_template` (`id`, `name`, `template`, `created_at`, `updated_at`) VALUES (31, 'Doppler Renal', '<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:500px;\">\r\n	<tbody>\r\n		<tr>\r\n			<td>Test name</td>\r\n			<td>Result</td>\r\n			<td>Normal Value</td>\r\n		</tr>\r\n		<tr>\r\n			<td>HB</td>\r\n			<td>12g</td>\r\n			<td>12g -16g</td>\r\n		</tr>\r\n		<tr>\r\n			<td>RBC</td>\r\n			<td>4.2lac</td>\r\n			<td>4 lac to 6lac</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n', '2023-03-17 16:18:39', '2023-03-17 16:18:39');
INSERT INTO `lab_report_template` (`id`, `name`, `template`, `created_at`, `updated_at`) VALUES (32, 'Doppler Scrotal', '<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:500px;\">\r\n	<tbody>\r\n		<tr>\r\n			<td>Test name</td>\r\n			<td>Result</td>\r\n			<td>Normal Value</td>\r\n		</tr>\r\n		<tr>\r\n			<td>HB</td>\r\n			<td>12g</td>\r\n			<td>12g -16g</td>\r\n		</tr>\r\n		<tr>\r\n			<td>RBC</td>\r\n			<td>4.2lac</td>\r\n			<td>4 lac to 6lac</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n', '2023-03-17 16:18:56', '2023-03-17 16:18:56');
INSERT INTO `lab_report_template` (`id`, `name`, `template`, `created_at`, `updated_at`) VALUES (33, 'Doppler Upper Limb (Both) Arterial', '<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:500px;\">\r\n	<tbody>\r\n		<tr>\r\n			<td>Test name</td>\r\n			<td>Result</td>\r\n			<td>Normal Value</td>\r\n		</tr>\r\n		<tr>\r\n			<td>HB</td>\r\n			<td>12g</td>\r\n			<td>12g -16g</td>\r\n		</tr>\r\n		<tr>\r\n			<td>RBC</td>\r\n			<td>4.2lac</td>\r\n			<td>4 lac to 6lac</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n', '2023-03-17 16:19:12', '2023-03-17 16:19:12');
INSERT INTO `lab_report_template` (`id`, `name`, `template`, `created_at`, `updated_at`) VALUES (34, 'Doppler Upper Limb (Both) Arterial & Venous', '<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:500px;\">\r\n	<tbody>\r\n		<tr>\r\n			<td>Test name</td>\r\n			<td>Result</td>\r\n			<td>Normal Value</td>\r\n		</tr>\r\n		<tr>\r\n			<td>HB</td>\r\n			<td>12g</td>\r\n			<td>12g -16g</td>\r\n		</tr>\r\n		<tr>\r\n			<td>RBC</td>\r\n			<td>4.2lac</td>\r\n			<td>4 lac to 6lac</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n', '2023-03-17 16:19:28', '2023-03-17 16:19:28');
INSERT INTO `lab_report_template` (`id`, `name`, `template`, `created_at`, `updated_at`) VALUES (35, 'Doppler Upper Limb (Both) Venous', '<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:500px;\">\r\n	<tbody>\r\n		<tr>\r\n			<td>Test name</td>\r\n			<td>Result</td>\r\n			<td>Normal Value</td>\r\n		</tr>\r\n		<tr>\r\n			<td>HB</td>\r\n			<td>12g</td>\r\n			<td>12g -16g</td>\r\n		</tr>\r\n		<tr>\r\n			<td>RBC</td>\r\n			<td>4.2lac</td>\r\n			<td>4 lac to 6lac</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n', '2023-03-17 16:19:52', '2023-03-17 16:19:52');
INSERT INTO `lab_report_template` (`id`, `name`, `template`, `created_at`, `updated_at`) VALUES (36, 'Doppler Upper Limb (Single) Arterial', '<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:500px;\">\r\n	<tbody>\r\n		<tr>\r\n			<td>Test name</td>\r\n			<td>Result</td>\r\n			<td>Normal Value</td>\r\n		</tr>\r\n		<tr>\r\n			<td>HB</td>\r\n			<td>12g</td>\r\n			<td>12g -16g</td>\r\n		</tr>\r\n		<tr>\r\n			<td>RBC</td>\r\n			<td>4.2lac</td>\r\n			<td>4 lac to 6lac</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n', '2023-03-17 16:20:07', '2023-03-17 16:20:07');
INSERT INTO `lab_report_template` (`id`, `name`, `template`, `created_at`, `updated_at`) VALUES (37, 'Doppler Upper Limb (Single) Venous', '<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:500px;\">\r\n	<tbody>\r\n		<tr>\r\n			<td>Test name</td>\r\n			<td>Result</td>\r\n			<td>Normal Value</td>\r\n		</tr>\r\n		<tr>\r\n			<td>HB</td>\r\n			<td>12g</td>\r\n			<td>12g -16g</td>\r\n		</tr>\r\n		<tr>\r\n			<td>RBC</td>\r\n			<td>4.2lac</td>\r\n			<td>4 lac to 6lac</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n', '2023-03-17 16:20:24', '2023-03-17 16:20:24');
INSERT INTO `lab_report_template` (`id`, `name`, `template`, `created_at`, `updated_at`) VALUES (38, 'Doppler Upper Limb (Single)Arterial & Venous', '<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:500px;\">\r\n	<tbody>\r\n		<tr>\r\n			<td>Test name</td>\r\n			<td>Result</td>\r\n			<td>Normal Value</td>\r\n		</tr>\r\n		<tr>\r\n			<td>HB</td>\r\n			<td>12g</td>\r\n			<td>12g -16g</td>\r\n		</tr>\r\n		<tr>\r\n			<td>RBC</td>\r\n			<td>4.2lac</td>\r\n			<td>4 lac to 6lac</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n', '2023-03-17 16:20:47', '2023-03-17 16:20:47');
INSERT INTO `lab_report_template` (`id`, `name`, `template`, `created_at`, `updated_at`) VALUES (39, '2D ECHOCARDIOGRAM', '<table align=\"center\" border=\"1\" bordercolor=\"#ccc\" cellpadding=\"5\" cellspacing=\"0\" style=\"border-collapse:collapse;width:500px;\">\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n			<div><span style=\"font-size:16px;\"><strong><code>Patient Name</code></strong></span></div>\r\n			</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td><span style=\"font-size:16px;\"><strong><code>Patient ID</code></strong></span></td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td><span style=\"font-size:14px;\"><strong>Category</strong></span></td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<table border=\"1\" bordercolor=\"#ccc\" cellpadding=\"5\" cellspacing=\"0\" style=\"border-collapse:collapse;width:100%;\">\r\n	<thead>\r\n		<tr>\r\n			<th scope=\"col\">Name</th>\r\n			<th scope=\"col\">Details</th>\r\n		</tr>\r\n	</thead>\r\n	<tbody>\r\n		<tr>\r\n			<td>H1</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>H2</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>H3</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>H4</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p dir=\"rtl\">-----------------------<br />\r\nSignature</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n', '2023-03-19 02:12:14', '2023-03-19 02:12:14');
INSERT INTO `lab_report_template` (`id`, `name`, `template`, `created_at`, `updated_at`) VALUES (40, '2D ECHOCARDIOGRAM', '<p align=\"CENTER\"><font face=\"Times New Roman, serif\"><font size=\"4\"><u><b>2D ECHO CARDIOGRAM</b></u></font></font></p>\r\n\r\n<p align=\"CENTER\">&nbsp;</p>\r\n\r\n<table border=\"1\" bordercolor=\"#000000\" cellpadding=\"4\" cellspacing=\"0\" width=\"100%\">\r\n	<tbody>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"CENTER\"><font face=\"Times New Roman, serif\"><font size=\"3\"><b>Mitral valve:</b></font></font></p>\r\n			</td>\r\n			<td colspan=\"3\" width=\"57%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Tricuspid Valve:</font></font></p>\r\n			</td>\r\n			<td colspan=\"3\" width=\"57%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Aortic Valve</font></font></p>\r\n			</td>\r\n			<td colspan=\"3\" width=\"57%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Pulmonary Valve </font></font></p>\r\n			</td>\r\n			<td colspan=\"3\" width=\"57%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Left Ventricle</font></font></p>\r\n			</td>\r\n			<td colspan=\"3\" width=\"57%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">LV E D D</font></font></p>\r\n			</td>\r\n			<td width=\"25%\">\r\n			<p align=\"CENTER\"><font face=\"Times New Roman, serif\"><font size=\"3\">cms</font></font></p>\r\n			</td>\r\n			<td width=\"10%\">\r\n			<p><font face=\"Times New Roman, serif\"><font size=\"3\">E F : </font></font></p>\r\n			</td>\r\n			<td width=\"22%\">\r\n			<p align=\"CENTER\"><font face=\"Times New Roman, serif\"><font size=\"3\">%</font></font></p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">LV E S D</font></font></p>\r\n			</td>\r\n			<td width=\"25%\">\r\n			<p align=\"CENTER\"><font face=\"Times New Roman, serif\"><font size=\"3\">cms</font></font></p>\r\n			</td>\r\n			<td width=\"10%\">\r\n			<p><font face=\"Times New Roman, serif\"><font size=\"3\">F S :</font></font></p>\r\n			</td>\r\n			<td width=\"22%\">\r\n			<p align=\"CENTER\"><font face=\"Times New Roman, serif\"><font size=\"3\">%</font></font></p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">LVPW</font></font></p>\r\n			</td>\r\n			<td width=\"25%\">\r\n			<p align=\"CENTER\"><font face=\"Times New Roman, serif\"><font size=\"3\">cms</font></font></p>\r\n			</td>\r\n			<td colspan=\"2\" rowspan=\"4\" width=\"32%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Aorta</font></font></p>\r\n			</td>\r\n			<td width=\"25%\">\r\n			<p align=\"CENTER\"><font face=\"Times New Roman, serif\"><font size=\"3\">cms</font></font></p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Left Atrium</font></font></p>\r\n			</td>\r\n			<td width=\"25%\">\r\n			<p align=\"CENTER\"><font face=\"Times New Roman, serif\"><font size=\"3\">cms</font></font></p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Right Atrium</font></font></p>\r\n			</td>\r\n			<td width=\"25%\">\r\n			<p align=\"CENTER\"><font face=\"Times New Roman, serif\"><font size=\"3\">cms</font></font></p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Right Ventricle</font></font></p>\r\n			</td>\r\n			<td colspan=\"3\" width=\"57%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Pulmonary Artery</font></font></p>\r\n			</td>\r\n			<td colspan=\"3\" width=\"57%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">I A S</font></font></p>\r\n			</td>\r\n			<td colspan=\"3\" width=\"57%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">I V S</font></font></p>\r\n			</td>\r\n			<td colspan=\"3\" width=\"57%\">\r\n			<p align=\"CENTER\">cms</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Pericardium</font></font></p>\r\n			</td>\r\n			<td colspan=\"3\" width=\"57%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<table border=\"1\" bordercolor=\"#000000\" cellpadding=\"4\" cellspacing=\"0\" width=\"100%\">\r\n	<tbody>\r\n		<tr valign=\"TOP\">\r\n			<td rowspan=\"4\" width=\"20%\">\r\n			<p>&nbsp;</p>\r\n\r\n			<p><font face=\"Times New Roman, serif\"><font size=\"3\"><u><b>Doppler Study:</b></u></font></font></p>\r\n			</td>\r\n			<td colspan=\"4\" width=\"80%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"20%\">\r\n			<p><font face=\"Times New Roman, serif\"><font size=\"3\">PV :</font></font></p>\r\n			</td>\r\n			<td width=\"20%\">\r\n			<p align=\"RIGHT\"><font face=\"Times New Roman, serif\"><font size=\"3\">mt/sec&nbsp;</font></font></p>\r\n			</td>\r\n			<td width=\"20%\">\r\n			<p><font face=\"Times New Roman, serif\"><font size=\"3\">PAT : </font></font></p>\r\n			</td>\r\n			<td width=\"20%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"20%\">\r\n			<p><font face=\"Times New Roman, serif\"><font size=\"3\">AV :</font></font></p>\r\n			</td>\r\n			<td width=\"20%\">\r\n			<p align=\"RIGHT\"><font face=\"Times New Roman, serif\"><font size=\"3\">mt/sec&nbsp;</font></font></p>\r\n			</td>\r\n			<td width=\"20%\">\r\n			<p><font face=\"Times New Roman, serif\"><font size=\"3\">MVF : </font></font></p>\r\n			</td>\r\n			<td width=\"20%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"20%\">\r\n			<p><font face=\"Times New Roman, serif\"><font size=\"3\">EDT:</font></font></p>\r\n			</td>\r\n			<td width=\"20%\">\r\n			<p align=\"RIGHT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Millisec&nbsp;</font></font></p>\r\n			</td>\r\n			<td width=\"20%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n			<td width=\"20%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p align=\"RIGHT\">&nbsp;</p>\r\n\r\n<p align=\"RIGHT\">&nbsp;</p>\r\n\r\n<p align=\"RIGHT\">------------------------------</p>\r\n\r\n<p align=\"RIGHT\">Lab Incharge Signature</p>\r\n', '2023-03-20 01:44:08', '2023-03-20 01:44:08');
INSERT INTO `lab_report_template` (`id`, `name`, `template`, `created_at`, `updated_at`) VALUES (41, '2D ECHOCARDIOGRAM', '<p align=\"CENTER\"><font face=\"Times New Roman, serif\"><font size=\"4\"><u><b>2D ECHO CARDIOGRAM</b></u></font></font></p>\r\n\r\n<p align=\"CENTER\">&nbsp;</p>\r\n\r\n<table border=\"1\" bordercolor=\"#000000\" cellpadding=\"4\" cellspacing=\"0\" width=\"100%\">\r\n	<tbody>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"CENTER\"><font face=\"Times New Roman, serif\"><font size=\"3\"><b>Mitral valve:</b></font></font></p>\r\n			</td>\r\n			<td colspan=\"3\" width=\"57%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Tricuspid Valve:</font></font></p>\r\n			</td>\r\n			<td colspan=\"3\" width=\"57%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Aortic Valve</font></font></p>\r\n			</td>\r\n			<td colspan=\"3\" width=\"57%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Pulmonary Valve </font></font></p>\r\n			</td>\r\n			<td colspan=\"3\" width=\"57%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Left Ventricle</font></font></p>\r\n			</td>\r\n			<td colspan=\"3\" width=\"57%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">LV E D D</font></font></p>\r\n			</td>\r\n			<td width=\"25%\">\r\n			<p align=\"CENTER\"><font face=\"Times New Roman, serif\"><font size=\"3\">cms</font></font></p>\r\n			</td>\r\n			<td width=\"10%\">\r\n			<p><font face=\"Times New Roman, serif\"><font size=\"3\">E F : </font></font></p>\r\n			</td>\r\n			<td width=\"22%\">\r\n			<p align=\"CENTER\"><font face=\"Times New Roman, serif\"><font size=\"3\">%</font></font></p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">LV E S D</font></font></p>\r\n			</td>\r\n			<td width=\"25%\">\r\n			<p align=\"CENTER\"><font face=\"Times New Roman, serif\"><font size=\"3\">cms</font></font></p>\r\n			</td>\r\n			<td width=\"10%\">\r\n			<p><font face=\"Times New Roman, serif\"><font size=\"3\">F S :</font></font></p>\r\n			</td>\r\n			<td width=\"22%\">\r\n			<p align=\"CENTER\"><font face=\"Times New Roman, serif\"><font size=\"3\">%</font></font></p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">LVPW</font></font></p>\r\n			</td>\r\n			<td width=\"25%\">\r\n			<p align=\"CENTER\"><font face=\"Times New Roman, serif\"><font size=\"3\">cms</font></font></p>\r\n			</td>\r\n			<td colspan=\"2\" rowspan=\"4\" width=\"32%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Aorta</font></font></p>\r\n			</td>\r\n			<td width=\"25%\">\r\n			<p align=\"CENTER\"><font face=\"Times New Roman, serif\"><font size=\"3\">cms</font></font></p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Left Atrium</font></font></p>\r\n			</td>\r\n			<td width=\"25%\">\r\n			<p align=\"CENTER\"><font face=\"Times New Roman, serif\"><font size=\"3\">cms</font></font></p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Right Atrium</font></font></p>\r\n			</td>\r\n			<td width=\"25%\">\r\n			<p align=\"CENTER\"><font face=\"Times New Roman, serif\"><font size=\"3\">cms</font></font></p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Right Ventricle</font></font></p>\r\n			</td>\r\n			<td colspan=\"3\" width=\"57%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Pulmonary Artery</font></font></p>\r\n			</td>\r\n			<td colspan=\"3\" width=\"57%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">I A S</font></font></p>\r\n			</td>\r\n			<td colspan=\"3\" width=\"57%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">I V S</font></font></p>\r\n			</td>\r\n			<td colspan=\"3\" width=\"57%\">\r\n			<p align=\"CENTER\">cms</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Pericardium</font></font></p>\r\n			</td>\r\n			<td colspan=\"3\" width=\"57%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<table border=\"1\" bordercolor=\"#000000\" cellpadding=\"4\" cellspacing=\"0\" width=\"100%\">\r\n	<tbody>\r\n		<tr valign=\"TOP\">\r\n			<td rowspan=\"4\" width=\"20%\">\r\n			<p>&nbsp;</p>\r\n\r\n			<p><font face=\"Times New Roman, serif\"><font size=\"3\"><u><b>Doppler Study:</b></u></font></font></p>\r\n			</td>\r\n			<td colspan=\"4\" width=\"80%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"20%\">\r\n			<p><font face=\"Times New Roman, serif\"><font size=\"3\">PV :</font></font></p>\r\n			</td>\r\n			<td width=\"20%\">\r\n			<p align=\"RIGHT\"><font face=\"Times New Roman, serif\"><font size=\"3\">mt/sec </font></font></p>\r\n			</td>\r\n			<td width=\"20%\">\r\n			<p><font face=\"Times New Roman, serif\"><font size=\"3\">PAT : </font></font></p>\r\n			</td>\r\n			<td width=\"20%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"20%\">\r\n			<p><font face=\"Times New Roman, serif\"><font size=\"3\">AV :</font></font></p>\r\n			</td>\r\n			<td width=\"20%\">\r\n			<p align=\"RIGHT\"><font face=\"Times New Roman, serif\"><font size=\"3\">mt/sec </font></font></p>\r\n			</td>\r\n			<td width=\"20%\">\r\n			<p><font face=\"Times New Roman, serif\"><font size=\"3\">MVF : </font></font></p>\r\n			</td>\r\n			<td width=\"20%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"20%\">\r\n			<p><font face=\"Times New Roman, serif\"><font size=\"3\">EDT:</font></font></p>\r\n			</td>\r\n			<td width=\"20%\">\r\n			<p align=\"RIGHT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Millisec </font></font></p>\r\n			</td>\r\n			<td width=\"20%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n			<td width=\"20%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p align=\"RIGHT\">&nbsp;</p>\r\n\r\n<p align=\"RIGHT\">&nbsp;</p>\r\n\r\n<p align=\"RIGHT\">------------------------------</p>\r\n\r\n<p align=\"RIGHT\">Lab Incharge Signature</p>\r\n', '2023-03-20 01:45:08', '2023-03-20 01:45:08');
INSERT INTO `lab_report_template` (`id`, `name`, `template`, `created_at`, `updated_at`) VALUES (42, '2D ECHOCARDIOGRAM', '<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:1275px;\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"text-align: center;\"><strong>Mitral valve:</strong></td>\r\n			<td colspan=\"3\" rowspan=\"1\">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Tricuspid Valve:</td>\r\n			<td colspan=\"3\" rowspan=\"1\">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Aortic Valve</td>\r\n			<td colspan=\"3\" rowspan=\"1\">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Pulmonary Valve</td>\r\n			<td colspan=\"3\" rowspan=\"1\">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Left Ventricle</td>\r\n			<td colspan=\"3\" rowspan=\"1\">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>LVEDD</td>\r\n			<td style=\"text-align: center;\">cms</td>\r\n			<td>EF:&nbsp;</td>\r\n			<td style=\"text-align: right;\">%&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>LVESD</td>\r\n			<td style=\"text-align: center;\">cms</td>\r\n			<td>FS:</td>\r\n			<td style=\"text-align: right;\">%&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>LVPW</td>\r\n			<td style=\"text-align: center;\">cms</td>\r\n			<td colspan=\"2\" rowspan=\"4\">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Aorta</td>\r\n			<td style=\"text-align: center;\">cms</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Left Atrium</td>\r\n			<td style=\"text-align: center;\">cms</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Right Atrium</td>\r\n			<td style=\"text-align: center;\">cms</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Right Ventricle</td>\r\n			<td colspan=\"3\" rowspan=\"1\">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Pulmonary Artery</td>\r\n			<td colspan=\"3\" rowspan=\"1\">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>I A S</td>\r\n			<td colspan=\"3\" rowspan=\"1\">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>I V S</td>\r\n			<td colspan=\"3\" rowspan=\"1\" style=\"text-align: center;\">cms</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Pericardium</td>\r\n			<td colspan=\"3\" rowspan=\"1\">&nbsp;</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p dir=\"rtl\">&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:1275px;\">\r\n	<tbody>\r\n		<tr>\r\n			<td rowspan=\"5\"><span style=\"font-size:16px;\"><strong>&nbsp;Doppler Study:</strong></span></td>\r\n			<td colspan=\"3\" rowspan=\"1\">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>PV :</td>\r\n			<td>\r\n			<p><font face=\"Times New Roman, serif\"><font size=\"3\">PAT : </font></font></p>\r\n			</td>\r\n			<td>%</td>\r\n		</tr>\r\n		<tr>\r\n			<td>AV :</td>\r\n			<td>&nbsp;</td>\r\n			<td>%</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p><font face=\"Times New Roman, serif\"><font size=\"3\">MVF : </font></font></p>\r\n			</td>\r\n			<td>&nbsp;</td>\r\n			<td>%</td>\r\n		</tr>\r\n		<tr>\r\n			<td>EDT:</td>\r\n			<td colspan=\"2\" rowspan=\"1\">&nbsp;</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p align=\"RIGHT\">&nbsp;</p>\r\n\r\n<p align=\"RIGHT\">&nbsp;</p>\r\n\r\n<p align=\"RIGHT\">------------------------------</p>\r\n\r\n<p align=\"RIGHT\">Lab Incharge Signature</p>\r\n', '2023-03-20 02:22:59', '2023-03-20 02:22:59');
INSERT INTO `lab_report_template` (`id`, `name`, `template`, `created_at`, `updated_at`) VALUES (43, 'My Test', '<p align=\"CENTER\"><font face=\"Times New Roman, serif\"><font size=\"4\"><u><b>2D ECHO CARDIOGRAM</b></u></font></font></p>\r\n\r\n<p align=\"CENTER\">&nbsp;</p>\r\n\r\n<table border=\"1\" bordercolor=\"#000000\" cellpadding=\"4\" cellspacing=\"0\" width=\"100%\">\r\n	<tbody>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"CENTER\"><font face=\"Times New Roman, serif\"><font size=\"3\"><b>Mitral valve:</b></font></font></p>\r\n			</td>\r\n			<td colspan=\"3\" width=\"57%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Tricuspid Valve:</font></font></p>\r\n			</td>\r\n			<td colspan=\"3\" width=\"57%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Aortic Valve</font></font></p>\r\n			</td>\r\n			<td colspan=\"3\" width=\"57%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Pulmonary Valve </font></font></p>\r\n			</td>\r\n			<td colspan=\"3\" width=\"57%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Left Ventricle</font></font></p>\r\n			</td>\r\n			<td colspan=\"3\" width=\"57%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">LV E D D</font></font></p>\r\n			</td>\r\n			<td width=\"25%\">\r\n			<p align=\"CENTER\"><font face=\"Times New Roman, serif\"><font size=\"3\">cms</font></font></p>\r\n			</td>\r\n			<td width=\"10%\">\r\n			<p><font face=\"Times New Roman, serif\"><font size=\"3\">E F : </font></font></p>\r\n			</td>\r\n			<td width=\"22%\">\r\n			<p align=\"CENTER\"><font face=\"Times New Roman, serif\"><font size=\"3\">%</font></font></p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">LV E S D</font></font></p>\r\n			</td>\r\n			<td width=\"25%\">\r\n			<p align=\"CENTER\"><font face=\"Times New Roman, serif\"><font size=\"3\">cms</font></font></p>\r\n			</td>\r\n			<td width=\"10%\">\r\n			<p><font face=\"Times New Roman, serif\"><font size=\"3\">F S :</font></font></p>\r\n			</td>\r\n			<td width=\"22%\">\r\n			<p align=\"CENTER\"><font face=\"Times New Roman, serif\"><font size=\"3\">%</font></font></p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">LVPW</font></font></p>\r\n			</td>\r\n			<td width=\"25%\">\r\n			<p align=\"CENTER\"><font face=\"Times New Roman, serif\"><font size=\"3\">cms</font></font></p>\r\n			</td>\r\n			<td colspan=\"2\" rowspan=\"4\" width=\"32%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Aorta</font></font></p>\r\n			</td>\r\n			<td width=\"25%\">\r\n			<p align=\"CENTER\"><font face=\"Times New Roman, serif\"><font size=\"3\">cms</font></font></p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Left Atrium</font></font></p>\r\n			</td>\r\n			<td width=\"25%\">\r\n			<p align=\"CENTER\"><font face=\"Times New Roman, serif\"><font size=\"3\">cms</font></font></p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Right Atrium</font></font></p>\r\n			</td>\r\n			<td width=\"25%\">\r\n			<p align=\"CENTER\"><font face=\"Times New Roman, serif\"><font size=\"3\">cms</font></font></p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Right Ventricle</font></font></p>\r\n			</td>\r\n			<td colspan=\"3\" width=\"57%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Pulmonary Artery</font></font></p>\r\n			</td>\r\n			<td colspan=\"3\" width=\"57%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">I A S</font></font></p>\r\n			</td>\r\n			<td colspan=\"3\" width=\"57%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">I V S</font></font></p>\r\n			</td>\r\n			<td colspan=\"3\" width=\"57%\">\r\n			<p align=\"CENTER\">cms</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Pericardium</font></font></p>\r\n			</td>\r\n			<td colspan=\"3\" width=\"57%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<table border=\"1\" bordercolor=\"#000000\" cellpadding=\"4\" cellspacing=\"0\" width=\"100%\">\r\n	<tbody>\r\n		<tr valign=\"TOP\">\r\n			<td rowspan=\"4\" width=\"20%\">\r\n			<p>&nbsp;</p>\r\n\r\n			<p><font face=\"Times New Roman, serif\"><font size=\"3\"><u><b>Doppler Study:</b></u></font></font></p>\r\n			</td>\r\n			<td colspan=\"4\" width=\"80%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"20%\">\r\n			<p><font face=\"Times New Roman, serif\"><font size=\"3\">PV :</font></font></p>\r\n			</td>\r\n			<td width=\"20%\">\r\n			<p align=\"RIGHT\"><font face=\"Times New Roman, serif\"><font size=\"3\">mt/sec </font></font></p>\r\n			</td>\r\n			<td width=\"20%\">\r\n			<p><font face=\"Times New Roman, serif\"><font size=\"3\">PAT : </font></font></p>\r\n			</td>\r\n			<td width=\"20%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"20%\">\r\n			<p><font face=\"Times New Roman, serif\"><font size=\"3\">AV :</font></font></p>\r\n			</td>\r\n			<td width=\"20%\">\r\n			<p align=\"RIGHT\"><font face=\"Times New Roman, serif\"><font size=\"3\">mt/sec </font></font></p>\r\n			</td>\r\n			<td width=\"20%\">\r\n			<p><font face=\"Times New Roman, serif\"><font size=\"3\">MVF : </font></font></p>\r\n			</td>\r\n			<td width=\"20%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"20%\">\r\n			<p><font face=\"Times New Roman, serif\"><font size=\"3\">EDT:</font></font></p>\r\n			</td>\r\n			<td width=\"20%\">\r\n			<p align=\"RIGHT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Millisec </font></font></p>\r\n			</td>\r\n			<td width=\"20%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n			<td width=\"20%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p align=\"RIGHT\">&nbsp;</p>\r\n\r\n<p align=\"RIGHT\">&nbsp;</p>\r\n\r\n<p align=\"RIGHT\">------------------------------</p>\r\n\r\n<p align=\"RIGHT\">Lab Incharge Signature</p>\r\n', '2023-03-20 02:24:21', '2023-03-20 02:24:21');
INSERT INTO `lab_report_template` (`id`, `name`, `template`, `created_at`, `updated_at`) VALUES (44, '2D ECHOCARDIOGRAM', '<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:500px;\">\r\n	<tbody>\r\n		<tr>\r\n			<td>Test name</td>\r\n			<td>Result</td>\r\n			<td>Normal Value</td>\r\n		</tr>\r\n		<tr>\r\n			<td>HB</td>\r\n			<td>12g</td>\r\n			<td>12g -16g</td>\r\n		</tr>\r\n		<tr>\r\n			<td>RBC</td>\r\n			<td>4.2lac</td>\r\n			<td>4 lac to 6lac</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n', '2023-04-19 16:04:50', '2023-04-19 16:04:50');


#
# TABLE STRUCTURE FOR: lab_test
#

DROP TABLE IF EXISTS `lab_test`;

CREATE TABLE `lab_test` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(155) NOT NULL,
  `patient_price` decimal(18,2) NOT NULL DEFAULT 0.00,
  `production_cost` decimal(18,2) NOT NULL DEFAULT 0.00,
  `test_code` varchar(20) NOT NULL,
  `date` date NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=201 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (45, 22, '2D ECHOCARDIOGRAM', '300.00', '250.00', '101', '2023-03-18', 1, '2023-03-17 14:44:33', '2023-03-17 14:44:33');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (46, 23, 'Consultation', '470.00', '340.00', '102', '2023-03-18', 1, '2023-03-17 14:45:06', '2023-03-17 14:45:06');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (47, 24, 'Doppler Abdomen', '250.00', '120.00', '103', '2023-03-18', 1, '2023-03-17 14:45:46', '2023-03-17 14:45:46');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (48, 24, 'Doppler Carotid', '700.00', '567.00', '104', '2023-03-18', 1, '2023-03-17 14:46:43', '2023-03-17 14:46:43');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (49, 24, 'Doppler Lower Limb (Both) Arterial', '490.00', '120.00', '105', '2023-03-18', 1, '2023-03-17 14:47:16', '2023-03-17 14:47:16');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (50, 24, 'Doppler Lower Limb (Both) Arterial &Venous', '450.00', '230.00', '106', '2023-03-18', 1, '2023-03-17 14:47:45', '2023-03-17 14:47:45');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (51, 24, 'Doppler Lower Limb (Both) Venous', '275.00', '250.00', '107', '2023-03-18', 1, '2023-03-17 14:48:09', '2023-03-17 14:48:09');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (52, 24, 'Doppler Lower Limb (Single ) Venous', '450.00', '120.00', '107', '2023-03-18', 1, '2023-03-17 14:48:37', '2023-03-17 14:48:37');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (53, 24, 'Doppler Lower Limb (Single) Arterial', '290.00', '250.00', '106', '2023-03-18', 1, '2023-03-17 14:49:10', '2023-03-17 14:49:10');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (54, 24, 'Doppler Lower Limb (Single) Arterial & Venous', '275.00', '180.00', '108', '2023-03-18', 1, '2023-03-17 14:49:39', '2023-03-17 14:49:39');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (55, 24, 'Doppler Placental ( Fetal )', '450.00', '234.00', '108', '2023-03-18', 1, '2023-03-17 14:50:17', '2023-03-17 14:50:17');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (56, 24, 'Doppler Portal', '200.00', '75.00', '109', '2023-03-18', 1, '2023-03-17 14:52:18', '2023-03-17 14:52:18');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (57, 24, 'Doppler Pregnancy', '450.00', '275.00', '109', '2023-03-18', 1, '2023-03-17 14:52:47', '2023-03-17 14:52:47');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (58, 24, 'Doppler Renal', '320.00', '125.00', '110', '2023-03-18', 1, '2023-03-17 14:53:46', '2023-03-17 14:53:46');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (59, 24, 'Doppler Scrotal', '650.00', '450.00', '111', '2023-03-18', 1, '2023-03-17 14:55:45', '2023-03-17 14:55:45');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (60, 24, 'Doppler Upper Limb (Both) Arterial', '890.00', '560.00', '112', '2023-03-18', 1, '2023-03-17 14:56:14', '2023-03-17 14:56:14');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (61, 24, 'Doppler Upper Limb (Both) Arterial & Venous', '540.00', '235.00', '113', '2023-03-18', 1, '2023-03-17 14:57:03', '2023-03-17 14:57:03');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (62, 24, 'Doppler Upper Limb (Both) Venous', '430.00', '239.00', '113', '2023-03-18', 1, '2023-03-17 14:57:39', '2023-03-17 14:57:39');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (63, 24, 'Doppler Upper Limb (Single) Arterial', '290.00', '238.00', '114', '2023-03-18', 1, '2023-03-17 14:58:14', '2023-03-17 14:58:14');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (64, 24, 'Doppler Upper Limb (Single) Venous', '340.00', '127.00', '115', '2023-03-18', 1, '2023-03-17 14:58:43', '2023-03-17 14:58:43');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (65, 24, 'Doppler Upper Limb (Single)Arterial & Venous', '300.00', '180.00', '118', '2023-03-18', 1, '2023-03-17 14:59:17', '2023-03-17 14:59:17');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (66, 25, 'ECG', '560.00', '340.00', '119', '2023-03-18', 1, '2023-03-17 14:59:46', '2023-03-17 14:59:46');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (67, 26, 'Colonoscopy Report', '258.00', '142.00', '121', '2023-03-18', 1, '2023-03-17 15:00:26', '2023-03-17 15:00:26');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (68, 26, 'Endoscopy Report', '349.00', '245.00', '122', '2023-03-18', 1, '2023-03-17 15:00:49', '2023-03-17 15:00:49');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (69, 27, '17-Ketosteroids Urine (24 hrs)', '350.00', '124.00', '124', '2023-03-18', 1, '2023-03-17 15:02:12', '2023-03-17 15:02:12');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (70, 27, '17-OH PROGESTERONE', '340.00', '127.00', '125', '2023-03-18', 1, '2023-03-17 15:02:41', '2023-03-17 15:02:41');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (71, 30, '24 HRS Urinary Copper', '475.00', '346.00', '324', '2023-03-18', 1, '2023-03-17 15:03:22', '2023-03-17 15:03:22');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (72, 27, '24 HRS Urinary V M A', '570.00', '235.00', '126', '2023-03-18', 1, '2023-03-17 15:03:55', '2023-03-17 15:03:55');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (73, 27, '24 HRS Urine For Albumin', '430.00', '234.00', '129', '2023-03-18', 1, '2023-03-17 15:04:21', '2023-03-17 15:04:21');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (74, 27, '24 HRS Urine For Cortisol', '345.00', '221.00', '129', '2023-03-18', 1, '2023-03-17 15:05:05', '2023-03-17 15:05:05');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (75, 27, '24 HRS Urine For Creatinine Clearance Test', '432.00', '324.00', '129', '2023-03-18', 1, '2023-03-17 15:05:32', '2023-03-17 15:05:32');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (76, 27, '24HRS Urinary Proteins', '324.00', '124.00', '129', '2023-03-18', 1, '2023-03-17 15:05:57', '2023-03-17 15:05:57');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (77, 27, '24HRS Urine Calcium', '541.00', '235.00', '129', '2023-03-18', 1, '2023-03-17 15:06:25', '2023-03-17 15:06:25');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (78, 27, '24HRS Urine Creatinine', '457.00', '214.00', '129', '2023-03-18', 1, '2023-03-17 15:06:53', '2023-03-17 15:06:53');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (79, 27, '24HRS Urine For Uric Acid', '431.00', '321.00', '129', '2023-03-18', 1, '2023-03-17 15:07:27', '2023-03-17 15:07:27');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (80, 27, 'A C T H (PLASMA ONLY IN ICE)', '678.00', '421.00', '129', '2023-03-18', 1, '2023-03-17 15:07:49', '2023-03-17 15:07:49');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (81, 27, 'ANTI SCL - 70', '345.00', '231.00', '129', '2023-03-18', 1, '2023-03-17 15:08:25', '2023-03-17 15:08:25');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (82, 27, 'ANTI THROMBUS-III', '657.00', '356.00', '129', '2023-03-18', 1, '2023-03-17 15:08:54', '2023-03-17 15:08:54');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (83, 27, 'Any Fluid For Biochemistry', '321.00', '124.00', '129', '2023-03-18', 1, '2023-03-17 15:09:23', '2023-03-17 15:09:23');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (84, 27, 'APO PROTEIN - B', '430.00', '120.00', '129', '2023-03-18', 1, '2023-03-17 15:09:43', '2023-03-17 15:09:43');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (85, 27, 'APO PROTIEN - A', '275.00', '235.00', '129', '2023-03-18', 1, '2023-03-17 15:10:11', '2023-03-17 15:10:11');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (86, 27, 'Blood Ada Levels', '290.00', '250.00', '129', '2023-03-18', 1, '2023-03-17 15:10:37', '2023-03-17 15:10:37');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (87, 27, 'Blood For Filaria AB', '450.00', '340.00', '129', '2023-03-18', 1, '2023-03-17 15:11:07', '2023-03-17 15:11:07');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (88, 27, 'Blood Urea', '340.00', '124.00', '129', '2023-03-18', 1, '2023-03-17 15:11:27', '2023-03-17 15:11:27');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (89, 27, 'Blood Urea Nitrogen', '300.00', '235.00', '129', '2023-03-18', 1, '2023-03-17 15:11:46', '2023-03-17 15:11:46');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (90, 27, 'BNP', '290.00', '124.00', '129', '2023-03-18', 1, '2023-03-17 15:12:10', '2023-03-17 15:12:10');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (91, 27, 'CA-19.9', '275.00', '250.00', '129', '2023-03-18', 1, '2023-03-17 15:12:31', '2023-03-17 15:12:31');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (92, 27, 'Calcitonin', '340.00', '120.00', '129', '2023-03-18', 1, '2023-03-17 15:12:53', '2023-03-17 15:12:53');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (93, 27, 'CARBAMEZAPINE / TEGRETOL', '430.00', '340.00', '129', '2023-03-18', 1, '2023-03-17 15:13:17', '2023-03-17 15:13:17');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (94, 27, 'Catecholamines', '300.00', '250.00', '129', '2023-03-18', 1, '2023-03-17 15:13:50', '2023-03-17 15:13:50');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (95, 27, 'Cholinesterose', '340.00', '124.00', '129', '2023-03-18', 1, '2023-03-17 15:14:14', '2023-03-17 15:14:14');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (96, 27, 'Cortisol (Single 8.00 AM OR 4.00 PM)', '290.00', '120.00', '129', '2023-03-18', 1, '2023-03-17 15:14:48', '2023-03-17 15:14:48');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (97, 27, 'Creatinine Clearance Test', '430.00', '235.00', '129', '2023-03-18', 1, '2023-03-17 15:15:05', '2023-03-17 15:15:05');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (98, 27, 'Fasting Blood Sugar', '275.00', '124.00', '129', '2023-03-18', 1, '2023-03-17 15:15:25', '2023-03-17 15:15:25');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (99, 27, 'FBS & PLBS', '300.00', '235.00', '129', '2023-03-18', 1, '2023-03-17 15:15:44', '2023-03-17 15:15:44');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (100, 27, 'Fibrinogen', '340.00', '250.00', '129', '2023-03-18', 1, '2023-03-17 15:16:02', '2023-03-17 15:16:02');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (101, 27, 'G6PD', '430.00', '124.00', '129', '2023-03-18', 1, '2023-03-17 15:16:21', '2023-03-17 15:16:21');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (102, 27, 'Glucose Tolerence Test ( 6 SAMPLES)', '435.00', '250.00', '129', '2023-03-18', 1, '2023-03-17 15:16:51', '2023-03-17 15:16:51');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (103, 27, 'Growth Hormone', '290.00', '124.00', '129', '2023-03-18', 1, '2023-03-17 15:17:08', '2023-03-17 15:17:08');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (104, 27, 'HBA1C', '275.00', '235.00', '129', '2023-03-18', 1, '2023-03-17 15:17:38', '2023-03-17 15:17:38');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (105, 27, 'Hdl Cholestrol', '450.00', '120.00', '129', '2023-03-18', 1, '2023-03-17 15:17:59', '2023-03-17 15:17:59');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (106, 27, 'HLA B-27', '300.00', '235.00', '129', '2023-03-18', 1, '2023-03-17 15:18:19', '2023-03-17 15:18:19');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (107, 27, 'House Visit', '340.00', '124.00', '129', '2023-03-18', 1, '2023-03-17 15:18:41', '2023-03-17 15:18:41');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (108, 27, 'Insulin', '430.00', '235.00', '129', '2023-03-18', 1, '2023-03-17 15:19:11', '2023-03-17 15:19:11');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (109, 27, 'LDL Cholestrol', '290.00', '124.00', '129', '2023-03-18', 1, '2023-03-17 15:19:25', '2023-03-17 15:19:25');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (110, 27, 'Lipid Profile', '300.00', '250.00', '129', '2023-03-18', 1, '2023-03-17 15:19:44', '2023-03-17 15:19:44');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (111, 27, 'Lipo Protein A', '450.00', '250.00', '129', '2023-03-18', 1, '2023-03-17 15:20:29', '2023-03-17 15:20:29');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (112, 27, 'Liver Function Test', '290.00', '235.00', '129', '2023-03-18', 1, '2023-03-17 15:21:03', '2023-03-17 15:21:03');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (113, 27, 'Lupus Anti Coagulant', '450.00', '340.00', '129', '2023-03-18', 1, '2023-03-17 15:21:23', '2023-03-17 15:21:23');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (114, 27, 'Magnesium', '340.00', '235.00', '129', '2023-03-18', 1, '2023-03-17 15:21:40', '2023-03-17 15:21:40');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (115, 27, 'PHENYTOIN / DILANTIN / EPTOIN', '430.00', '124.00', '129', '2023-03-18', 1, '2023-03-17 15:22:03', '2023-03-17 15:22:03');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (116, 27, 'Post Lunch Blood Sugar', '340.00', '250.00', '129', '2023-03-18', 1, '2023-03-17 15:22:31', '2023-03-17 15:22:31');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (117, 27, 'Protein C', '430.00', '235.00', '129', '2023-03-18', 1, '2023-03-17 15:22:50', '2023-03-17 15:22:50');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (118, 27, 'Protein Electrophoresis', '340.00', '250.00', '129', '2023-03-18', 1, '2023-03-17 15:23:15', '2023-03-17 15:23:15');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (119, 27, 'Protein S', '300.00', '124.00', '129', '2023-03-18', 1, '2023-03-17 15:23:35', '2023-03-17 15:23:35');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (120, 27, 'Random Blood Sugar', '450.00', '120.00', '129', '2023-03-18', 1, '2023-03-17 15:23:57', '2023-03-17 15:23:57');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (121, 27, 'SEMAR For AFB(24Hours Urine ) ::', '300.00', '124.00', '129', '2023-03-18', 1, '2023-03-17 15:24:14', '2023-03-17 15:24:14');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (122, 27, 'Serum Ace', '450.00', '250.00', '129', '2023-03-18', 1, '2023-03-17 15:24:33', '2023-03-17 15:24:33');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (123, 27, 'Serum Acid Phosphatase', '340.00', '235.00', '129', '2023-03-18', 1, '2023-03-17 15:24:54', '2023-03-17 15:24:54');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (124, 27, 'Serum Acid Prostatic Fraction', '450.00', '120.00', '129', '2023-03-18', 1, '2023-03-17 15:25:10', '2023-03-17 15:25:10');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (125, 27, 'Serum Albumin', '290.00', '124.00', '129', '2023-03-18', 1, '2023-03-17 15:25:35', '2023-03-17 15:25:35');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (126, 27, 'Serum Alkaline Phosphatase', '340.00', '235.00', '129', '2023-03-18', 1, '2023-03-17 15:25:56', '2023-03-17 15:25:56');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (127, 27, 'Serum Ammonia', '430.00', '124.00', '129', '2023-03-18', 1, '2023-03-17 15:26:25', '2023-03-17 15:26:25');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (128, 27, 'Serum Amylase', '290.00', '124.00', '129', '2023-03-18', 1, '2023-03-17 15:26:42', '2023-03-17 15:26:42');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (129, 27, 'Serum Bicarbonates', '450.00', '235.00', '129', '2023-03-18', 1, '2023-03-17 15:27:08', '2023-03-17 15:27:08');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (130, 27, 'Serum Bilirubin (Total & Direct)', '300.00', '124.00', '129', '2023-03-18', 1, '2023-03-17 15:27:30', '2023-03-17 15:27:30');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (131, 27, 'Serum Calcium', '430.00', '235.00', '129', '2023-03-18', 1, '2023-03-17 15:27:52', '2023-03-17 15:27:52');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (132, 27, 'Serum Chlorides', '300.00', '235.00', '129', '2023-03-18', 1, '2023-03-17 15:28:15', '2023-03-17 15:28:15');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (133, 27, 'Serum Cholestrol', '450.00', '120.00', '129', '2023-03-18', 1, '2023-03-17 15:28:34', '2023-03-17 15:28:34');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (134, 27, 'Serum Copper', '430.00', '235.00', '129', '2023-03-18', 1, '2023-03-17 15:29:04', '2023-03-17 15:29:04');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (135, 27, 'Serum CPK', '340.00', '124.00', '129', '2023-03-18', 1, '2023-03-17 15:29:33', '2023-03-17 15:29:33');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (136, 27, 'Serum CPK (MB)', '450.00', '124.00', '129', '2023-03-18', 1, '2023-03-17 15:29:54', '2023-03-17 15:29:54');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (137, 27, 'Serum Creatinine', '430.00', '235.00', '129', '2023-03-18', 1, '2023-03-17 15:30:26', '2023-03-17 15:30:26');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (138, 27, 'Serum Electrolytes', '450.00', '124.00', '129', '2023-03-18', 1, '2023-03-17 15:30:45', '2023-03-17 15:30:45');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (139, 27, 'Serum Gamma GT', '300.00', '124.00', '129', '2023-03-18', 1, '2023-03-17 15:31:02', '2023-03-17 15:31:02');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (140, 27, 'Serum Iron', '430.00', '124.00', '129', '2023-03-18', 1, '2023-03-17 15:31:29', '2023-03-17 15:31:29');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (141, 27, 'Serum Lactate', '450.00', '235.00', '129', '2023-03-18', 1, '2023-03-17 15:31:51', '2023-03-17 15:31:51');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (142, 27, 'Serum LDH', '450.00', '235.00', '129', '2023-03-18', 1, '2023-03-17 15:32:09', '2023-03-17 15:32:09');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (143, 27, 'Serum Lipase', '450.00', '124.00', '129', '2023-03-18', 1, '2023-03-17 15:32:31', '2023-03-17 15:32:31');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (144, 27, 'Serum Lithium', '450.00', '340.00', '129', '2023-03-18', 1, '2023-03-17 15:32:54', '2023-03-17 15:32:54');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (145, 27, 'Serum Phosphorous', '430.00', '124.00', '129', '2023-03-18', 1, '2023-03-17 15:33:18', '2023-03-17 15:33:18');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (146, 27, 'Serum Potassium', '450.00', '235.00', '129', '2023-03-18', 1, '2023-03-17 15:33:36', '2023-03-17 15:33:36');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (147, 27, 'Serum Proteins (ALB, GLO)', '450.00', '250.00', '129', '2023-03-18', 1, '2023-03-17 15:33:59', '2023-03-17 15:33:59');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (148, 27, 'Serum Sodium', '450.00', '235.00', '129', '2023-03-18', 1, '2023-03-17 15:34:16', '2023-03-17 15:34:16');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (149, 27, 'Serum Triglycerides', '450.00', '235.00', '129', '2023-03-18', 1, '2023-03-17 15:34:35', '2023-03-17 15:34:35');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (150, 27, 'Serum Uric Acid', '450.00', '120.00', '129', '2023-03-18', 1, '2023-03-17 15:34:53', '2023-03-17 15:34:53');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (151, 27, 'Serum Valproic Acid', '300.00', '124.00', '129', '2023-03-18', 1, '2023-03-17 15:35:20', '2023-03-17 15:35:20');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (152, 27, 'Serum Zinc Levels', '430.00', '124.00', '129', '2023-03-18', 1, '2023-03-17 15:35:38', '2023-03-17 15:35:38');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (153, 27, 'SGOT', '290.00', '250.00', '129', '2023-03-18', 1, '2023-03-17 15:35:58', '2023-03-17 15:35:58');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (154, 27, 'SGPT', '430.00', '235.00', '129', '2023-03-18', 1, '2023-03-17 15:36:18', '2023-03-17 15:36:18');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (155, 27, 'SPOT Protein : Creatinine Ration', '430.00', '124.00', '129', '2023-03-18', 1, '2023-03-17 15:36:38', '2023-03-17 15:36:38');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (156, 27, 'Spot Urine For Protein', '300.00', '124.00', '129', '2023-03-18', 1, '2023-03-17 15:36:58', '2023-03-17 15:36:58');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (157, 27, 'Stone Analysis', '430.00', '124.00', '129', '2023-03-18', 1, '2023-03-17 15:38:47', '2023-03-17 15:38:47');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (158, 27, 'Triglycerides', '450.00', '235.00', '129', '2023-03-18', 1, '2023-03-17 15:39:08', '2023-03-17 15:39:08');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (159, 27, 'TROP-T', '430.00', '124.00', '129', '2023-03-18', 1, '2023-03-17 15:39:25', '2023-03-17 15:39:25');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (160, 27, 'Urine For Micro Albumin', '430.00', '124.00', '129', '2023-03-18', 1, '2023-03-17 15:39:49', '2023-03-17 15:39:49');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (161, 27, 'Urine For V.M.A Spot', '290.00', '124.00', '129', '2023-03-18', 1, '2023-03-17 15:40:19', '2023-03-17 15:40:19');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (162, 27, 'Weil Felix', '450.00', '235.00', '129', '2023-03-18', 1, '2023-03-17 15:40:43', '2023-03-17 15:40:43');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (163, 28, 'Complete Stool Examination', '340.00', '124.00', '130', '2023-03-18', 1, '2023-03-17 15:42:25', '2023-03-17 15:42:25');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (164, 28, 'Complete Urine Exam', '450.00', '235.00', '130', '2023-03-18', 1, '2023-03-17 15:42:46', '2023-03-17 15:42:46');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (165, 28, 'Stool For Fatglobulin', '300.00', '235.00', '130', '2023-03-18', 1, '2023-03-17 15:43:08', '2023-03-17 15:43:08');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (166, 28, 'Stool For Occult Blood', '300.00', '124.00', '130', '2023-03-18', 1, '2023-03-17 15:43:32', '2023-03-17 15:43:32');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (167, 28, 'Stool For OVA & CYSTS', '900.00', '452.00', '130', '2023-03-18', 1, '2023-03-17 15:43:52', '2023-03-17 15:43:52');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (168, 28, 'Stool For Ph', '450.00', '124.00', '130', '2023-03-18', 1, '2023-03-17 15:44:15', '2023-03-17 15:44:15');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (169, 28, 'Stool For Reducing Substances', '300.00', '124.00', '130', '2023-03-18', 1, '2023-03-17 15:44:36', '2023-03-17 15:44:36');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (170, 28, 'Urine For Albumin', '300.00', '124.00', '130', '2023-03-18', 1, '2023-03-17 15:45:00', '2023-03-17 15:45:00');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (171, 28, 'Urine For Bence Jones Proteins', '430.00', '235.00', '130', '2023-03-18', 1, '2023-03-17 15:45:25', '2023-03-17 15:45:25');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (172, 28, 'Urine For Bile Salts & Bile Pigments', '450.00', '235.00', '130', '2023-03-18', 1, '2023-03-17 15:45:51', '2023-03-17 15:45:51');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (173, 28, 'Urine For CHYLE / CHYLURIA', '340.00', '124.00', '130', '2023-03-18', 1, '2023-03-17 15:46:50', '2023-03-17 15:46:50');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (174, 28, 'Urine For KETONE & ACETONE', '430.00', '124.00', '130', '2023-03-18', 1, '2023-03-17 15:47:13', '2023-03-17 15:47:13');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (175, 28, 'Urine For Ph', '300.00', '124.00', '130', '2023-03-18', 1, '2023-03-17 15:47:34', '2023-03-17 15:47:34');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (176, 28, 'Urine For Pregnancy', '450.00', '235.00', '130', '2023-03-18', 1, '2023-03-17 15:47:53', '2023-03-17 15:47:53');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (177, 28, 'Urine For Proteins', '340.00', '124.00', '130', '2023-03-18', 1, '2023-03-17 15:48:11', '2023-03-17 15:48:11');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (178, 28, 'Urine For Reducing Substances', '430.00', '124.00', '130', '2023-03-18', 1, '2023-03-17 15:48:35', '2023-03-17 15:48:35');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (179, 28, 'Urine For Specific Gravity', '450.00', '235.00', '130', '2023-03-18', 1, '2023-03-17 15:49:02', '2023-03-17 15:49:02');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (180, 28, 'Urine For Sugar', '450.00', '124.00', '130', '2023-03-18', 1, '2023-03-17 15:49:21', '2023-03-17 15:49:21');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (181, 28, 'Urine For Urobilinogen', '430.00', '235.00', '130', '2023-03-18', 1, '2023-03-17 15:49:48', '2023-03-17 15:49:48');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (182, 29, 'Any Fluid For Cell Count', '430.00', '124.00', '131', '2023-03-18', 1, '2023-03-17 15:50:41', '2023-03-17 15:50:41');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (183, 29, 'ANY FLUID For CELL COUNT + BIOCHEMICAL', '430.00', '124.00', '131', '2023-03-18', 1, '2023-03-17 15:51:03', '2023-03-17 15:51:03');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (184, 29, 'Any Fluid For Cytology', '300.00', '124.00', '131', '2023-03-18', 1, '2023-03-17 15:51:31', '2023-03-17 15:51:31');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (185, 29, 'BONCHIAL WASH / BRUSHING For CYTOLOGY', '300.00', '124.00', '131', '2023-03-18', 1, '2023-03-17 15:51:53', '2023-03-17 15:51:53');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (186, 29, 'Bone Marrow Aspiration (PROG + CYTOLOGY)', '430.00', '124.00', '131', '2023-03-18', 1, '2023-03-17 15:52:13', '2023-03-17 15:52:13');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (187, 29, 'CYTOLOGY SLIDE For 2ND OPINION', '290.00', '124.00', '131', '2023-03-18', 1, '2023-03-17 15:52:32', '2023-03-17 15:52:32');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (188, 29, 'Fine Needle Aspiration (FNAC)', '430.00', '124.00', '131', '2023-03-18', 1, '2023-03-17 15:52:49', '2023-03-17 15:52:49');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (189, 29, 'Smear For Cytology', '340.00', '124.00', '131', '2023-03-18', 1, '2023-03-17 15:53:58', '2023-03-17 15:53:58');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (190, 29, 'Smear For Malignant Cells', '450.00', '235.00', '131', '2023-03-18', 1, '2023-03-17 15:54:14', '2023-03-17 15:54:14');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (191, 29, 'Sputum For Cytology', '300.00', '235.00', '131', '2023-03-18', 1, '2023-03-17 15:54:42', '2023-03-17 15:54:42');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (192, 29, 'Ascitic Fluid - Cell Count', '290.00', '124.00', '131', '2023-03-18', 1, '2023-03-17 15:55:11', '2023-03-17 15:55:11');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (193, 29, 'CYTOPATHOLOGY dept name in header/fot For Cytology', '430.00', '235.00', '131', '2023-03-18', 1, '2023-03-17 15:55:30', '2023-03-17 15:55:30');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (194, 30, 'A F P', '340.00', '235.00', '132', '2023-03-18', 1, '2023-03-17 15:56:17', '2023-03-17 15:56:17');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (195, 30, 'Androsteindione', '450.00', '235.00', '132', '2023-03-18', 1, '2023-03-17 15:56:49', '2023-03-17 15:56:49');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (196, 30, 'Anti Phospholipid Igg', '340.00', '124.00', '132', '2023-03-18', 1, '2023-03-17 15:57:14', '2023-03-17 15:57:14');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (197, 30, 'Anti Phospholipid Igm', '430.00', '235.00', '132', '2023-03-18', 1, '2023-03-17 15:57:51', '2023-03-17 15:57:51');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (198, 30, 'Beta H C G', '450.00', '235.00', '132', '2023-03-18', 1, '2023-03-17 15:58:20', '2023-03-17 15:58:20');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (199, 30, 'C E A', '430.00', '235.00', '133', '2023-03-18', 1, '2023-03-17 15:58:51', '2023-03-17 15:58:51');
INSERT INTO `lab_test` (`id`, `category_id`, `name`, `patient_price`, `production_cost`, `test_code`, `date`, `created_by`, `created_at`, `updated_at`) VALUES (200, 30, 'CA-15.3', '430.00', '235.00', '133', '2023-03-18', 1, '2023-03-17 15:59:15', '2023-03-17 15:59:15');


#
# TABLE STRUCTURE FOR: lab_test_category
#

DROP TABLE IF EXISTS `lab_test_category`;

CREATE TABLE `lab_test_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `lab_test_category` (`id`, `name`, `created_at`, `updated_at`) VALUES (22, '2D Echo', '2023-03-17 14:29:03', '2023-03-17 14:29:03');
INSERT INTO `lab_test_category` (`id`, `name`, `created_at`, `updated_at`) VALUES (23, 'Consultation', '2023-03-17 14:29:25', '2023-03-17 14:29:25');
INSERT INTO `lab_test_category` (`id`, `name`, `created_at`, `updated_at`) VALUES (24, 'Dopplers', '2023-03-17 14:30:16', '2023-03-17 14:30:16');
INSERT INTO `lab_test_category` (`id`, `name`, `created_at`, `updated_at`) VALUES (25, 'ECG', '2023-03-17 14:30:49', '2023-03-17 14:30:49');
INSERT INTO `lab_test_category` (`id`, `name`, `created_at`, `updated_at`) VALUES (26, 'EDOSCOPY', '2023-03-17 14:31:20', '2023-03-17 14:31:20');
INSERT INTO `lab_test_category` (`id`, `name`, `created_at`, `updated_at`) VALUES (27, 'Biochemistry', '2023-03-17 14:37:18', '2023-03-17 14:37:18');
INSERT INTO `lab_test_category` (`id`, `name`, `created_at`, `updated_at`) VALUES (28, 'Clinical Pathology', '2023-03-17 14:37:38', '2023-03-17 14:37:38');
INSERT INTO `lab_test_category` (`id`, `name`, `created_at`, `updated_at`) VALUES (29, 'Cytology', '2023-03-17 14:37:50', '2023-03-17 14:37:50');
INSERT INTO `lab_test_category` (`id`, `name`, `created_at`, `updated_at`) VALUES (30, 'Endorcrinology', '2023-03-17 14:38:04', '2023-03-17 14:38:04');
INSERT INTO `lab_test_category` (`id`, `name`, `created_at`, `updated_at`) VALUES (31, 'Haematology', '2023-03-17 14:38:21', '2023-03-17 14:38:21');
INSERT INTO `lab_test_category` (`id`, `name`, `created_at`, `updated_at`) VALUES (32, 'Histopathology', '2023-03-17 14:38:31', '2023-03-17 14:38:31');
INSERT INTO `lab_test_category` (`id`, `name`, `created_at`, `updated_at`) VALUES (33, 'Microbiology', '2023-03-17 14:39:11', '2023-03-17 14:39:11');
INSERT INTO `lab_test_category` (`id`, `name`, `created_at`, `updated_at`) VALUES (34, 'Serology', '2023-03-17 14:39:17', '2023-03-17 14:39:17');
INSERT INTO `lab_test_category` (`id`, `name`, `created_at`, `updated_at`) VALUES (35, 'CT Scan', '2023-03-17 14:40:54', '2023-03-17 14:40:54');
INSERT INTO `lab_test_category` (`id`, `name`, `created_at`, `updated_at`) VALUES (36, 'MRI', '2023-03-17 14:42:57', '2023-03-17 14:42:57');
INSERT INTO `lab_test_category` (`id`, `name`, `created_at`, `updated_at`) VALUES (37, 'TMT', '2023-03-17 14:43:08', '2023-03-17 14:43:08');
INSERT INTO `lab_test_category` (`id`, `name`, `created_at`, `updated_at`) VALUES (38, 'Ultra Sound', '2023-03-17 14:43:16', '2023-03-17 14:43:16');
INSERT INTO `lab_test_category` (`id`, `name`, `created_at`, `updated_at`) VALUES (39, 'Contrast Examinations', '2023-03-17 14:43:24', '2023-03-17 14:43:24');
INSERT INTO `lab_test_category` (`id`, `name`, `created_at`, `updated_at`) VALUES (40, 'Dental', '2023-03-17 14:43:31', '2023-03-17 14:43:31');
INSERT INTO `lab_test_category` (`id`, `name`, `created_at`, `updated_at`) VALUES (41, 'Xray', '2023-03-17 14:43:38', '2023-03-17 14:43:38');


#
# TABLE STRUCTURE FOR: labtest_bill
#

DROP TABLE IF EXISTS `labtest_bill`;

CREATE TABLE `labtest_bill` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bill_no` varchar(10) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `referral_id` int(11) NOT NULL,
  `total` decimal(18,2) NOT NULL DEFAULT 0.00,
  `discount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `tax_amount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `commission` decimal(18,2) DEFAULT 0.00,
  `paid` decimal(18,2) NOT NULL DEFAULT 0.00,
  `due` decimal(18,2) NOT NULL DEFAULT 0.00,
  `status` tinyint(1) NOT NULL,
  `date` date DEFAULT NULL,
  `hash` varchar(50) NOT NULL,
  `prepared_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `labtest_bill` (`id`, `bill_no`, `patient_id`, `referral_id`, `total`, `discount`, `tax_amount`, `commission`, `paid`, `due`, `status`, `date`, `hash`, `prepared_by`, `created_at`, `updated_at`) VALUES (1, '0001', 1, 5, '420.00', '29.40', '0.00', '0.00', '390.60', '0.00', 3, '2023-03-15', '43bdf2a7cbfc81ca262b0f362bc2aa91', 2, '2023-03-15 03:32:04', '2023-03-15 04:06:07');
INSERT INTO `labtest_bill` (`id`, `bill_no`, `patient_id`, `referral_id`, `total`, `discount`, `tax_amount`, `commission`, `paid`, `due`, `status`, `date`, `hash`, `prepared_by`, `created_at`, `updated_at`) VALUES (2, '0002', 2, 4, '140.00', '7.00', '0.00', '0.00', '133.00', '0.00', 3, '2023-03-15', 'f91c7baa03f51e322938f232b03e0635', 2, '2023-03-15 03:36:16', '2023-03-15 04:06:51');
INSERT INTO `labtest_bill` (`id`, `bill_no`, `patient_id`, `referral_id`, `total`, `discount`, `tax_amount`, `commission`, `paid`, `due`, `status`, `date`, `hash`, `prepared_by`, `created_at`, `updated_at`) VALUES (3, '0003', 3, 3, '420.00', '8.40', '0.00', '0.00', '411.60', '0.00', 3, '2023-03-15', 'd666c8fbe552aeae0312cd5cc13c8cd7', 2, '2023-03-15 03:39:22', '2023-03-16 08:45:54');
INSERT INTO `labtest_bill` (`id`, `bill_no`, `patient_id`, `referral_id`, `total`, `discount`, `tax_amount`, `commission`, `paid`, `due`, `status`, `date`, `hash`, `prepared_by`, `created_at`, `updated_at`) VALUES (4, '0004', 1, 2, '300.00', '0.00', '0.00', '0.00', '190.00', '110.00', 2, '2023-03-18', '0a45bc15e8fe20aeab30353203a3379d', 1, '2023-03-17 16:21:38', '2023-03-17 16:44:15');
INSERT INTO `labtest_bill` (`id`, `bill_no`, `patient_id`, `referral_id`, `total`, `discount`, `tax_amount`, `commission`, `paid`, `due`, `status`, `date`, `hash`, `prepared_by`, `created_at`, `updated_at`) VALUES (5, '0005', 4, 5, '300.00', '6.00', '0.00', '0.00', '294.00', '0.00', 3, '2023-03-18', '2ac5f2597c2da12068deb820d23e8843', 2, '2023-03-17 16:40:00', '2023-03-17 16:40:00');
INSERT INTO `labtest_bill` (`id`, `bill_no`, `patient_id`, `referral_id`, `total`, `discount`, `tax_amount`, `commission`, `paid`, `due`, `status`, `date`, `hash`, `prepared_by`, `created_at`, `updated_at`) VALUES (6, '0006', 1, 2, '1260.00', '0.00', '0.00', '0.00', '1260.00', '0.00', 3, '2023-03-18', '47575117a6aaffa600a1c3c96b6fe928', 1, '2023-03-18 06:08:13', '2023-03-18 06:08:40');
INSERT INTO `labtest_bill` (`id`, `bill_no`, `patient_id`, `referral_id`, `total`, `discount`, `tax_amount`, `commission`, `paid`, `due`, `status`, `date`, `hash`, `prepared_by`, `created_at`, `updated_at`) VALUES (7, '0007', 5, 5, '1470.00', '0.00', '0.00', '0.00', '1470.00', '0.00', 3, '2023-03-19', '59c1d41fdf062334d47711bddff04236', 2, '2023-03-19 02:36:27', '2023-03-20 05:35:35');
INSERT INTO `labtest_bill` (`id`, `bill_no`, `patient_id`, `referral_id`, `total`, `discount`, `tax_amount`, `commission`, `paid`, `due`, `status`, `date`, `hash`, `prepared_by`, `created_at`, `updated_at`) VALUES (8, '0008', 5, 4, '770.00', '3.00', '0.00', '0.00', '100.00', '667.00', 2, '2023-03-19', '0f4de085f95b67289b22243e19e05ef4', 2, '2023-03-19 02:49:02', '2023-03-19 02:49:02');
INSERT INTO `labtest_bill` (`id`, `bill_no`, `patient_id`, `referral_id`, `total`, `discount`, `tax_amount`, `commission`, `paid`, `due`, `status`, `date`, `hash`, `prepared_by`, `created_at`, `updated_at`) VALUES (9, '0009', 1, 3, '470.00', '9.40', '0.00', '0.00', '0.00', '460.60', 1, '2023-03-20', 'af96543777a91dd5dacd52b768dc1e3f', 1, '2023-03-20 05:33:16', '2023-03-20 05:33:16');
INSERT INTO `labtest_bill` (`id`, `bill_no`, `patient_id`, `referral_id`, `total`, `discount`, `tax_amount`, `commission`, `paid`, `due`, `status`, `date`, `hash`, `prepared_by`, `created_at`, `updated_at`) VALUES (10, '0010', 1, 2, '860.00', '0.00', '0.00', '0.00', '500.00', '360.00', 2, '2023-03-26', 'f11ab518ec3b454956000277273f8eaa', 1, '2023-03-26 03:18:26', '2023-03-26 03:18:26');
INSERT INTO `labtest_bill` (`id`, `bill_no`, `patient_id`, `referral_id`, `total`, `discount`, `tax_amount`, `commission`, `paid`, `due`, `status`, `date`, `hash`, `prepared_by`, `created_at`, `updated_at`) VALUES (11, '0011', 2, 2, '300.00', '0.00', '0.00', '0.00', '0.00', '300.00', 1, '2023-04-20', '4183d6d02f8cc8e2cc97a556403a6f17', 1, '2023-04-19 16:10:09', '2023-04-19 16:10:09');


#
# TABLE STRUCTURE FOR: labtest_bill_details
#

DROP TABLE IF EXISTS `labtest_bill_details`;

CREATE TABLE `labtest_bill_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `labtest_bill_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `test_id` int(11) NOT NULL,
  `price` decimal(18,2) NOT NULL DEFAULT 0.00,
  `discount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `commission_amount` decimal(18,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `labtest_bill_details` (`id`, `labtest_bill_id`, `category_id`, `test_id`, `price`, `discount`, `commission_amount`) VALUES (1, 1, 11, 27, '420.00', '29.40', '0.00');
INSERT INTO `labtest_bill_details` (`id`, `labtest_bill_id`, `category_id`, `test_id`, `price`, `discount`, `commission_amount`) VALUES (2, 2, 11, 29, '140.00', '7.00', '0.00');
INSERT INTO `labtest_bill_details` (`id`, `labtest_bill_id`, `category_id`, `test_id`, `price`, `discount`, `commission_amount`) VALUES (3, 3, 11, 27, '420.00', '8.40', '0.00');
INSERT INTO `labtest_bill_details` (`id`, `labtest_bill_id`, `category_id`, `test_id`, `price`, `discount`, `commission_amount`) VALUES (4, 4, 22, 45, '300.00', '0.00', '0.00');
INSERT INTO `labtest_bill_details` (`id`, `labtest_bill_id`, `category_id`, `test_id`, `price`, `discount`, `commission_amount`) VALUES (5, 5, 22, 45, '300.00', '6.00', '0.00');
INSERT INTO `labtest_bill_details` (`id`, `labtest_bill_id`, `category_id`, `test_id`, `price`, `discount`, `commission_amount`) VALUES (6, 6, 25, 66, '560.00', '0.00', '0.00');
INSERT INTO `labtest_bill_details` (`id`, `labtest_bill_id`, `category_id`, `test_id`, `price`, `discount`, `commission_amount`) VALUES (7, 6, 24, 48, '700.00', '0.00', '0.00');
INSERT INTO `labtest_bill_details` (`id`, `labtest_bill_id`, `category_id`, `test_id`, `price`, `discount`, `commission_amount`) VALUES (8, 7, 22, 45, '300.00', '0.00', '0.00');
INSERT INTO `labtest_bill_details` (`id`, `labtest_bill_id`, `category_id`, `test_id`, `price`, `discount`, `commission_amount`) VALUES (9, 7, 23, 46, '470.00', '0.00', '0.00');
INSERT INTO `labtest_bill_details` (`id`, `labtest_bill_id`, `category_id`, `test_id`, `price`, `discount`, `commission_amount`) VALUES (10, 7, 24, 48, '700.00', '0.00', '0.00');
INSERT INTO `labtest_bill_details` (`id`, `labtest_bill_id`, `category_id`, `test_id`, `price`, `discount`, `commission_amount`) VALUES (11, 8, 22, 45, '300.00', '3.00', '0.00');
INSERT INTO `labtest_bill_details` (`id`, `labtest_bill_id`, `category_id`, `test_id`, `price`, `discount`, `commission_amount`) VALUES (12, 8, 23, 46, '470.00', '0.00', '0.00');
INSERT INTO `labtest_bill_details` (`id`, `labtest_bill_id`, `category_id`, `test_id`, `price`, `discount`, `commission_amount`) VALUES (13, 9, 23, 46, '470.00', '9.40', '0.00');
INSERT INTO `labtest_bill_details` (`id`, `labtest_bill_id`, `category_id`, `test_id`, `price`, `discount`, `commission_amount`) VALUES (14, 10, 22, 45, '300.00', '0.00', '0.00');
INSERT INTO `labtest_bill_details` (`id`, `labtest_bill_id`, `category_id`, `test_id`, `price`, `discount`, `commission_amount`) VALUES (15, 10, 25, 66, '560.00', '0.00', '0.00');
INSERT INTO `labtest_bill_details` (`id`, `labtest_bill_id`, `category_id`, `test_id`, `price`, `discount`, `commission_amount`) VALUES (16, 11, 22, 45, '300.00', '0.00', '0.00');


#
# TABLE STRUCTURE FOR: labtest_payment_history
#

DROP TABLE IF EXISTS `labtest_payment_history`;

CREATE TABLE `labtest_payment_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `labtest_bill_id` int(11) NOT NULL,
  `collect_by` int(11) DEFAULT NULL,
  `amount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `method_id` int(11) NOT NULL,
  `remarks` text NOT NULL,
  `paid_on` date NOT NULL,
  `coll_type` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `labtest_payment_history` (`id`, `labtest_bill_id`, `collect_by`, `amount`, `method_id`, `remarks`, `paid_on`, `coll_type`) VALUES (1, 1, 2, '300.00', 0, '', '2023-03-15', 0);
INSERT INTO `labtest_payment_history` (`id`, `labtest_bill_id`, `collect_by`, `amount`, `method_id`, `remarks`, `paid_on`, `coll_type`) VALUES (2, 2, 2, '50.00', 0, '', '2023-03-15', 0);
INSERT INTO `labtest_payment_history` (`id`, `labtest_bill_id`, `collect_by`, `amount`, `method_id`, `remarks`, `paid_on`, `coll_type`) VALUES (3, 3, 2, '150.00', 0, '', '2023-03-15', 0);
INSERT INTO `labtest_payment_history` (`id`, `labtest_bill_id`, `collect_by`, `amount`, `method_id`, `remarks`, `paid_on`, `coll_type`) VALUES (4, 1, 2, '90.60', 1, 'Paid', '2023-03-15', 1);
INSERT INTO `labtest_payment_history` (`id`, `labtest_bill_id`, `collect_by`, `amount`, `method_id`, `remarks`, `paid_on`, `coll_type`) VALUES (5, 2, 2, '83.00', 2, '', '2023-03-15', 1);
INSERT INTO `labtest_payment_history` (`id`, `labtest_bill_id`, `collect_by`, `amount`, `method_id`, `remarks`, `paid_on`, `coll_type`) VALUES (6, 3, 2, '261.60', 1, '', '2023-03-16', 1);
INSERT INTO `labtest_payment_history` (`id`, `labtest_bill_id`, `collect_by`, `amount`, `method_id`, `remarks`, `paid_on`, `coll_type`) VALUES (7, 4, 1, '100.00', 0, '', '2023-03-18', 0);
INSERT INTO `labtest_payment_history` (`id`, `labtest_bill_id`, `collect_by`, `amount`, `method_id`, `remarks`, `paid_on`, `coll_type`) VALUES (8, 5, 2, '294.00', 1, '', '2023-03-18', 0);
INSERT INTO `labtest_payment_history` (`id`, `labtest_bill_id`, `collect_by`, `amount`, `method_id`, `remarks`, `paid_on`, `coll_type`) VALUES (9, 4, 2, '90.00', 2, '', '2023-03-18', 1);
INSERT INTO `labtest_payment_history` (`id`, `labtest_bill_id`, `collect_by`, `amount`, `method_id`, `remarks`, `paid_on`, `coll_type`) VALUES (10, 6, 1, '1200.00', 1, '', '2023-03-18', 0);
INSERT INTO `labtest_payment_history` (`id`, `labtest_bill_id`, `collect_by`, `amount`, `method_id`, `remarks`, `paid_on`, `coll_type`) VALUES (11, 6, 1, '60.00', 2, '', '2023-03-18', 1);
INSERT INTO `labtest_payment_history` (`id`, `labtest_bill_id`, `collect_by`, `amount`, `method_id`, `remarks`, `paid_on`, `coll_type`) VALUES (12, 7, 2, '780.00', 1, '', '2023-03-19', 0);
INSERT INTO `labtest_payment_history` (`id`, `labtest_bill_id`, `collect_by`, `amount`, `method_id`, `remarks`, `paid_on`, `coll_type`) VALUES (13, 8, 2, '100.00', 0, '', '2023-03-19', 0);
INSERT INTO `labtest_payment_history` (`id`, `labtest_bill_id`, `collect_by`, `amount`, `method_id`, `remarks`, `paid_on`, `coll_type`) VALUES (14, 7, 2, '690.00', 1, '', '2023-03-20', 1);
INSERT INTO `labtest_payment_history` (`id`, `labtest_bill_id`, `collect_by`, `amount`, `method_id`, `remarks`, `paid_on`, `coll_type`) VALUES (15, 10, 1, '500.00', 1, 'Payment Received By Mimi', '2023-03-26', 0);


#
# TABLE STRUCTURE FOR: labtest_report
#

DROP TABLE IF EXISTS `labtest_report`;

CREATE TABLE `labtest_report` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `labtest_bill_id` int(11) NOT NULL,
  `reporting_date` date DEFAULT NULL,
  `delivery_date` date DEFAULT NULL,
  `delivery_time` time DEFAULT NULL,
  `report_description` longtext DEFAULT NULL,
  `report_remarks` text DEFAULT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `labtest_report` (`id`, `labtest_bill_id`, `reporting_date`, `delivery_date`, `delivery_time`, `report_description`, `report_remarks`, `status`) VALUES (1, 1, '2023-03-15', '2023-03-16', '13:30:00', '<table align=\"center\" border=\"1\" bordercolor=\"#ccc\" cellpadding=\"5\" cellspacing=\"0\" style=\"border-collapse:collapse;width:500px;\">\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n			<div><span style=\"font-size:16px;\"><strong><code>Patient Name</code></strong></span></div>\r\n			</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td><span style=\"font-size:16px;\"><strong><code>Patient ID</code></strong></span></td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td><span style=\"font-size:14px;\"><strong>Category</strong></span></td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<table border=\"1\" bordercolor=\"#ccc\" cellpadding=\"5\" cellspacing=\"0\" style=\"border-collapse:collapse;width:100%;\">\r\n	<thead>\r\n		<tr>\r\n			<th scope=\"col\">Name</th>\r\n			<th scope=\"col\">Details</th>\r\n		</tr>\r\n	</thead>\r\n	<tbody>\r\n		<tr>\r\n			<td>H1</td>\r\n			<td>82%</td>\r\n		</tr>\r\n		<tr>\r\n			<td>H2</td>\r\n			<td>32%</td>\r\n		</tr>\r\n		<tr>\r\n			<td>H3</td>\r\n			<td>100</td>\r\n		</tr>\r\n		<tr>\r\n			<td>H4</td>\r\n			<td>1520</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p dir=\"rtl\">-------------------------------<br />\r\nLab Incharge Signature</p>\r\n\r\n<p>&nbsp;</p>\r\n', '', 2);
INSERT INTO `labtest_report` (`id`, `labtest_bill_id`, `reporting_date`, `delivery_date`, `delivery_time`, `report_description`, `report_remarks`, `status`) VALUES (2, 2, '2023-03-15', '2023-03-15', '13:45:00', '<table border=\"1\" bordercolor=\"#ccc\" cellpadding=\"5\" cellspacing=\"0\" style=\"border-collapse:collapse;width:100%;\">\r\n	<thead>\r\n		<tr>\r\n			<th scope=\"col\">Name</th>\r\n			<th scope=\"col\">Details</th>\r\n		</tr>\r\n	</thead>\r\n	<tbody>\r\n		<tr>\r\n			<td>H1</td>\r\n			<td>520</td>\r\n		</tr>\r\n		<tr>\r\n			<td>H2</td>\r\n			<td>120</td>\r\n		</tr>\r\n		<tr>\r\n			<td>H3</td>\r\n			<td>156</td>\r\n		</tr>\r\n		<tr>\r\n			<td>H4</td>\r\n			<td>10</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p dir=\"rtl\">-------------------------------<br />\r\nLab Incharge Signature</p>\r\n\r\n<p>&nbsp;</p>\r\n', 'Nothing to Say', 2);
INSERT INTO `labtest_report` (`id`, `labtest_bill_id`, `reporting_date`, `delivery_date`, `delivery_time`, `report_description`, `report_remarks`, `status`) VALUES (3, 3, '2023-03-15', '2023-03-17', '18:45:00', '<p>&nbsp;</p>\r\n\r\n<table border=\"1\" bordercolor=\"#ccc\" cellpadding=\"5\" cellspacing=\"0\" style=\"border-collapse:collapse;width:100%;\">\r\n	<thead>\r\n		<tr>\r\n			<th scope=\"col\">Name</th>\r\n			<th scope=\"col\">Details</th>\r\n		</tr>\r\n	</thead>\r\n	<tbody>\r\n		<tr>\r\n			<td>H1</td>\r\n			<td>ttt</td>\r\n		</tr>\r\n		<tr>\r\n			<td>H2</td>\r\n			<td>ttt</td>\r\n		</tr>\r\n		<tr>\r\n			<td>H3</td>\r\n			<td>ttt</td>\r\n		</tr>\r\n		<tr>\r\n			<td>H4</td>\r\n			<td>ttt</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p dir=\"rtl\">-------------------------------<br />\r\nLab Incharge Signature</p>\r\n\r\n<p>&nbsp;</p>\r\n', '', 2);
INSERT INTO `labtest_report` (`id`, `labtest_bill_id`, `reporting_date`, `delivery_date`, `delivery_time`, `report_description`, `report_remarks`, `status`) VALUES (4, 4, '2023-03-20', '2023-03-18', '02:30:00', '<p align=\"CENTER\"><font face=\"Times New Roman, serif\"><font size=\"4\"><u><b>2D ECHO CARDIOGRAM</b></u></font></font></p>\r\n\r\n<p align=\"CENTER\">&nbsp;</p>\r\n\r\n<table border=\"1\" bordercolor=\"#000000\" cellpadding=\"4\" cellspacing=\"0\" width=\"100%\">\r\n	<tbody>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"CENTER\"><font face=\"Times New Roman, serif\"><font size=\"3\"><b>Mitral valve:</b></font></font></p>\r\n			</td>\r\n			<td colspan=\"3\" width=\"57%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Tricuspid Valve:</font></font></p>\r\n			</td>\r\n			<td colspan=\"3\" width=\"57%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Aortic Valve</font></font></p>\r\n			</td>\r\n			<td colspan=\"3\" width=\"57%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Pulmonary Valve </font></font></p>\r\n			</td>\r\n			<td colspan=\"3\" width=\"57%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Left Ventricle</font></font></p>\r\n			</td>\r\n			<td colspan=\"3\" width=\"57%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">LV E D D</font></font></p>\r\n			</td>\r\n			<td width=\"25%\">\r\n			<p align=\"CENTER\"><font face=\"Times New Roman, serif\"><font size=\"3\">cms</font></font></p>\r\n			</td>\r\n			<td width=\"10%\">\r\n			<p><font face=\"Times New Roman, serif\"><font size=\"3\">E F : </font></font></p>\r\n			</td>\r\n			<td width=\"22%\">\r\n			<p align=\"CENTER\"><font face=\"Times New Roman, serif\"><font size=\"3\">100%</font></font></p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">LV E S D</font></font></p>\r\n			</td>\r\n			<td width=\"25%\">\r\n			<p align=\"CENTER\"><font face=\"Times New Roman, serif\"><font size=\"3\">cms</font></font></p>\r\n			</td>\r\n			<td width=\"10%\">\r\n			<p><font face=\"Times New Roman, serif\"><font size=\"3\">F S :</font></font></p>\r\n			</td>\r\n			<td width=\"22%\">\r\n			<p align=\"CENTER\"><font face=\"Times New Roman, serif\"><font size=\"3\">100%</font></font></p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">LVPW</font></font></p>\r\n			</td>\r\n			<td width=\"25%\">\r\n			<p align=\"CENTER\"><font face=\"Times New Roman, serif\"><font size=\"3\">cms</font></font></p>\r\n			</td>\r\n			<td colspan=\"2\" rowspan=\"4\" width=\"32%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Aorta</font></font></p>\r\n			</td>\r\n			<td width=\"25%\">\r\n			<p align=\"CENTER\"><font face=\"Times New Roman, serif\"><font size=\"3\">cms</font></font></p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Left Atrium</font></font></p>\r\n			</td>\r\n			<td width=\"25%\">\r\n			<p align=\"CENTER\"><font face=\"Times New Roman, serif\"><font size=\"3\">cms</font></font></p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Right Atrium</font></font></p>\r\n			</td>\r\n			<td width=\"25%\">\r\n			<p align=\"CENTER\"><font face=\"Times New Roman, serif\"><font size=\"3\">cms</font></font></p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Right Ventricle</font></font></p>\r\n			</td>\r\n			<td colspan=\"3\" width=\"57%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Pulmonary Artery</font></font></p>\r\n			</td>\r\n			<td colspan=\"3\" width=\"57%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">I A S</font></font></p>\r\n			</td>\r\n			<td colspan=\"3\" width=\"57%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">I V S</font></font></p>\r\n			</td>\r\n			<td colspan=\"3\" width=\"57%\">\r\n			<p align=\"CENTER\">cms</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"43%\">\r\n			<p align=\"LEFT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Pericardium</font></font></p>\r\n			</td>\r\n			<td colspan=\"3\" width=\"57%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<table border=\"1\" bordercolor=\"#000000\" cellpadding=\"4\" cellspacing=\"0\" width=\"100%\">\r\n	<tbody>\r\n		<tr valign=\"TOP\">\r\n			<td rowspan=\"4\" width=\"20%\">\r\n			<p>&nbsp;</p>\r\n\r\n			<p><font face=\"Times New Roman, serif\"><font size=\"3\"><u><b>Doppler Study:</b></u></font></font></p>\r\n			</td>\r\n			<td colspan=\"4\" width=\"80%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"20%\">\r\n			<p><font face=\"Times New Roman, serif\"><font size=\"3\">PV :</font></font></p>\r\n			</td>\r\n			<td width=\"20%\">\r\n			<p align=\"RIGHT\"><font face=\"Times New Roman, serif\"><font size=\"3\">mt/sec </font></font></p>\r\n			</td>\r\n			<td width=\"20%\">\r\n			<p><font face=\"Times New Roman, serif\"><font size=\"3\">PAT : </font></font></p>\r\n			</td>\r\n			<td width=\"20%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"20%\">\r\n			<p><font face=\"Times New Roman, serif\"><font size=\"3\">AV :</font></font></p>\r\n			</td>\r\n			<td width=\"20%\">\r\n			<p align=\"RIGHT\"><font face=\"Times New Roman, serif\"><font size=\"3\">mt/sec </font></font></p>\r\n			</td>\r\n			<td width=\"20%\">\r\n			<p><font face=\"Times New Roman, serif\"><font size=\"3\">MVF : </font></font></p>\r\n			</td>\r\n			<td width=\"20%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr valign=\"TOP\">\r\n			<td width=\"20%\">\r\n			<p><font face=\"Times New Roman, serif\"><font size=\"3\">EDT:</font></font></p>\r\n			</td>\r\n			<td width=\"20%\">\r\n			<p align=\"RIGHT\"><font face=\"Times New Roman, serif\"><font size=\"3\">Millisec </font></font></p>\r\n			</td>\r\n			<td width=\"20%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n			<td width=\"20%\">\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p align=\"RIGHT\">&nbsp;</p>\r\n\r\n<p align=\"RIGHT\">&nbsp;</p>\r\n\r\n<p align=\"RIGHT\">------------------------------</p>\r\n\r\n<p align=\"RIGHT\">Lab Incharge Signature</p>\r\n', '', 2);
INSERT INTO `labtest_report` (`id`, `labtest_bill_id`, `reporting_date`, `delivery_date`, `delivery_time`, `report_description`, `report_remarks`, `status`) VALUES (5, 5, '2023-03-18', '2023-03-18', '02:45:00', '<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:500px;\">\r\n	<tbody>\r\n		<tr>\r\n			<td>Test name</td>\r\n			<td>Result</td>\r\n			<td>Normal Value</td>\r\n		</tr>\r\n		<tr>\r\n			<td>HB</td>\r\n			<td>76bf</td>\r\n			<td>12g -16g</td>\r\n		</tr>\r\n		<tr>\r\n			<td>RBC</td>\r\n			<td>4.2lac</td>\r\n			<td>4 lac to 6lac</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n', '', 2);
INSERT INTO `labtest_report` (`id`, `labtest_bill_id`, `reporting_date`, `delivery_date`, `delivery_time`, `report_description`, `report_remarks`, `status`) VALUES (6, 6, '2023-03-20', '2023-03-18', '16:15:00', '<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:500px;\">\r\n	<tbody>\r\n		<tr>\r\n			<td>Test name</td>\r\n			<td>Result</td>\r\n			<td>Normal Value</td>\r\n		</tr>\r\n		<tr>\r\n			<td>HB</td>\r\n			<td>12g</td>\r\n			<td>12nnbbbvg -16g</td>\r\n		</tr>\r\n		<tr>\r\n			<td>RBC</td>\r\n			<td>4.2lac</td>\r\n			<td>4 bbvac to 6lac</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n', '', 2);
INSERT INTO `labtest_report` (`id`, `labtest_bill_id`, `reporting_date`, `delivery_date`, `delivery_time`, `report_description`, `report_remarks`, `status`) VALUES (7, 7, '2023-03-19', '2023-03-20', '12:45:00', '<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:500px;\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"text-align: center;\">Test name</td>\r\n			<td style=\"text-align: center;\">Result</td>\r\n			<td style=\"text-align: center;\">Normal Value</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align: center;\">HB</td>\r\n			<td style=\"text-align: center;\">120g</td>\r\n			<td style=\"text-align: center;\">12g -16g</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align: center;\">RBC</td>\r\n			<td style=\"text-align: center;\">4.2lac</td>\r\n			<td style=\"text-align: center;\">4 lac to 6lac</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n', 'n/a', 2);
INSERT INTO `labtest_report` (`id`, `labtest_bill_id`, `reporting_date`, `delivery_date`, `delivery_time`, `report_description`, `report_remarks`, `status`) VALUES (8, 8, '2023-03-26', '2023-03-19', '12:45:00', '<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:500px;\">\r\n	<tbody>\r\n		<tr>\r\n			<td>Test name</td>\r\n			<td>Result</td>\r\n			<td>Normal Value</td>\r\n		</tr>\r\n		<tr>\r\n			<td>HB</td>\r\n			<td>12g</td>\r\n			<td>12g -16g</td>\r\n		</tr>\r\n		<tr>\r\n			<td>RBC</td>\r\n			<td>4.2lac</td>\r\n			<td>4 lac to 6lac</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n', 'n/a', 2);
INSERT INTO `labtest_report` (`id`, `labtest_bill_id`, `reporting_date`, `delivery_date`, `delivery_time`, `report_description`, `report_remarks`, `status`) VALUES (9, 9, '2023-04-05', '2023-03-20', '15:45:00', '<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:500px;\">\r\n	<tbody>\r\n		<tr>\r\n			<td>Test name</td>\r\n			<td>Result</td>\r\n			<td>Normal Value</td>\r\n		</tr>\r\n		<tr>\r\n			<td>HB</td>\r\n			<td>12g</td>\r\n			<td>12g -16g</td>\r\n		</tr>\r\n		<tr>\r\n			<td>RBC</td>\r\n			<td>4.2lac</td>\r\n			<td>4 lac to 6lac</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n', '', 2);
INSERT INTO `labtest_report` (`id`, `labtest_bill_id`, `reporting_date`, `delivery_date`, `delivery_time`, `report_description`, `report_remarks`, `status`) VALUES (10, 10, NULL, '2023-03-26', '15:30:00', NULL, 'bv', 1);
INSERT INTO `labtest_report` (`id`, `labtest_bill_id`, `reporting_date`, `delivery_date`, `delivery_time`, `report_description`, `report_remarks`, `status`) VALUES (11, 11, NULL, '2023-04-20', '02:15:00', NULL, 'er', 1);


#
# TABLE STRUCTURE FOR: language_list
#

DROP TABLE IF EXISTS `language_list`;

CREATE TABLE `language_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `lang_field` varchar(100) NOT NULL,
  `status` varchar(11) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `language_list` (`id`, `name`, `lang_field`, `status`, `created_at`, `updated_at`) VALUES (1, 'বাংলা', 'english', '0', '2018-11-15 17:36:31', '2023-03-23 01:16:44');
INSERT INTO `language_list` (`id`, `name`, `lang_field`, `status`, `created_at`, `updated_at`) VALUES (2, 'English', 'bengali', '1', '2018-11-15 17:36:31', '2023-03-15 01:14:34');


#
# TABLE STRUCTURE FOR: languages
#

DROP TABLE IF EXISTS `languages`;

CREATE TABLE `languages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `word` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `english` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `bengali` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=461 DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1, 'dashboard', 'ড্যাশবোর্ড', 'Dashboard ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (2, 'create', 'ক্রিয়েট', 'Create');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (3, 'patient', 'রোগী', 'Patient ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (4, 'test', 'টেস্ট', 'Test');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (5, 'bill', 'বিল', 'Bill');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (6, 'commission', 'কমিশন', 'Commission ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (7, 'withdrawal', 'উত্তোলন', 'Withdrawal ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (8, 'appointment', 'এপয়েনমেন্ট', 'Appointment ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (9, 'voucher', 'ভাউচার', 'Voucher ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (10, 'income_vs_expense', 'ইনকাম VS খরচ', 'Income Vs Expense ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (11, 'search', 'সার্চ করুন', 'Search ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (12, 'visit_home_page', 'হোম পেইজ ভিজিট করুন', 'Visit Home Page ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (13, 'language', 'ভাষা', 'Language ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (14, 'logout', 'লগআউট করুন', 'Logout');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (15, 'profile', 'প্রোফাইল ', 'Profile ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (16, 'reset_password', 'পাসওয়ার্ড রিসেট করুন', 'Reset Password ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (17, 'global', 'গ্লোবাল', 'Global ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (18, 'settings', 'সেটিংস', 'Settings');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (19, 'frontend', 'ফ্রন্টইন্ড', 'Frontend ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (20, 'setting', 'সেটিং', 'Setting ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (21, 'menu', 'মেন্যু', 'Menu');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (22, 'page', 'পেইজ', 'Page');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (23, 'section', 'সেকশন', 'Section ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (24, 'manage', 'ম্যানেজ ', 'Manage ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (25, 'slider', 'স্লাইডার', 'Slider');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (26, 'features', 'ফিচারস', 'Features');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (27, 'testimonial', 'টেস্টিমোনিয়াল', 'Testimonial ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (28, 'service', 'সার্ভিস', 'Service');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (29, 'faq', 'এফএকিউ', 'Faq');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (30, 'details', 'বিস্তারিত', 'Details');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (31, 'list', 'লিস্ট', 'List');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (32, 'category', 'ক্যাটাগরি', 'Category');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (33, 'login_deactivate', 'লগইন নিষ্ক্রিয় করুন', 'Login Deactivate ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (34, 'inventory', 'ইনভেন্টরি', 'Inventory ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (35, 'chemical', 'কেমিক্যাল', 'Chemical ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (36, 'supplier', 'সাপ্লাইয়ার', 'Supplier');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (37, 'unit', 'ইউনিট', 'Unit');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (38, 'purchase', 'পারচেছ', 'Purchase');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (39, 'stock', 'স্টক', 'Stock');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (40, 'reagent', 'রিএজেন্ট', 'AssignedReagent');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (41, 'assigned', 'বরাদ্দ করা হয়েছে', 'Assigned ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (42, 'reports', 'রিপোর্টস', 'Reports');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (43, 'report', 'রিপোর্ট', 'Report ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (44, 'payment', 'পেমেন্ট', 'Payment');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (45, 'schedule', 'সিডিউল', 'Schedule');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (46, 'add', 'এড করুন', 'Add');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (47, 'requested_list', 'রিকুয়েস্টেড লিস্ট', 'Requested List ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (48, 'employee', 'কর্মচারী', 'Employee ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (49, 'department', 'ডিপার্টমেন্ট', 'Department');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (50, 'designation', 'ডেজিনেশন', 'Designation ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (51, 'hrm', 'এইচআরএম', 'Hrm');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (52, 'payroll', 'পেরোল', 'Payroll');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (53, 'salary', 'সেলারি', 'Salary ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (54, 'template', 'টেমপ্লেট', 'Template ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (55, 'assign', 'এসাইন', 'Assign');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (56, 'summary', 'সামারি', 'Summary');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (57, 'leaves', 'লিভস', 'Leaves');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (58, 'my_leave', 'আমার লিভ ', 'My Leave ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (59, 'leave_manage', 'লিভ ম্যানেজ', 'Leave Manage ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (60, 'attendance', 'উপস্থিতি', 'Attendance ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (61, 'set', 'সেট', 'Set ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (62, 'pathology', 'প্যাথলজি', 'Pathology');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (63, 'lab', 'ল্যাব', 'Lab');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (64, 'refer_manager', 'রেফার ম্যানেজার', 'Refer Manager ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (65, 'referral', 'রেফারেল', 'Referral ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (66, 'my_commission', 'মাই কমিশন', 'My Commission ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (67, 'statement', 'স্টেটমেন্ট', 'Statement ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (68, 'payout', 'পে-আউট', 'Payout');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (69, 'office_accounting', 'অফিস একাউন্টিং', 'Office Accounting ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (70, 'account', 'একাউন্ট', 'Account');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (71, 'head', 'হেড', 'Head');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (72, 'income', 'ইনকাম', 'Income');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (73, 'repots', 'রিপটস', 'Repots');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (74, 'expense', 'খরচ', 'Expense');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (75, 'transitions', 'রূপান্তর', 'Transitions');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (76, 'balance', 'ব্যাল্যান্স', 'Balance');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (77, 'sheet', 'সিট', 'Sheet ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (78, 'billing', 'বিলিং', 'Billing');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (79, 'due', 'বকেয়া', 'Due ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (80, 'paid', 'পেইড', 'Paid');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (81, 'collect', 'কালেক্ট', 'Collect');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (82, 'investigation', 'ইনভেস্টিকেশন', 'Investigation ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (83, 'sms', 'এসএমএস', 'Sms');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (84, 'email', 'ইমেইল', 'Email');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (85, 'role', 'পদবি', 'Role');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (86, 'permission', 'পারমিশন', 'Permission ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (87, 'database', 'ডাটাবেইস', 'Database');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (88, 'backup', 'ব্যাকআপ', 'Backup');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (89, 'invoice', 'ইনভয়েছ', 'Invoice');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (90, 'today_total', 'আজকের টোটাল', 'Today Total ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (91, 'annual', 'বাৎসরিক', 'Annual');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (92, 'total_strength', 'মোট শক্তি', 'Total Strength ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (93, 'doctor', 'ডাক্তার', 'Doctor ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (94, 'pending', 'পেন্ডিং', 'Pending');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (95, 'request', 'রিকুয়েস্ট', 'Request');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (96, 'fees', 'ফিস', 'Fees');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (97, 'net', 'নেট', 'Net');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (98, 'payable', 'পেএবল', 'Payable ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (99, 'total', 'টোটাল', 'Total');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (100, 'this_value_is_required', 'এটা অবশ্যই প্রয়োজন', 'This Value Is Required ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (101, 'enter_valid_email', 'সঠিক ইমেইল এড্রেস প্রদান করুন', 'Enter Valid Email ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (102, 'are_you_sure', 'আপনি কি নিশ্চিত', 'Are You Sure ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (103, 'delete_this_information', 'এই তথ্য মুছুন', 'Delete This Information ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (104, 'yes_continue', 'হ্যাঁ চালিয়ে যান', 'Yes Continue ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (105, 'cancel', 'বাতিল করুন', 'Cancel');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (106, 'deleted_note', 'মুছে ফেলা নোট', 'Deleted Note ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (107, 'deleted', 'মুছে ফেলা হয়েছে', 'Deleted');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (108, 'information_deleted', 'তথ্য মুছে ফেলা হয়েছে', 'Information Deleted ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (109, 'website', 'ওয়েবসাইট', 'Website');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (110, 'application', 'এপ্লিকেশন', 'Application ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (111, 'name', 'নাম', 'Name');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (112, 'receive_email_to', 'ইমেইল পাবে', 'Receive Email To ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (113, 'captcha_status', 'ক্যাপচা স্ট্যাটাস', 'Captcha Status ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (114, 'select', 'সিলেক্ট', 'Select ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (115, 'disable', 'ডিজেবল', 'Disable ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (116, 'enable', 'এনএবল', 'Enable');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (117, 'recaptcha_site_key', 'রিক্যাপচা সাইট কী', 'Recaptcha Site Key ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (118, 'recaptcha_secret_key', 'রিক্যাপচা সিক্রেট কী', 'Recaptcha Secret Key ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (119, 'working_hours', 'কর্মঘন্টা', 'Working Hours ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (120, 'logo', 'লোগো', 'Logo');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (121, 'fav_icon', 'ফেভআইকন', 'Fav Icon ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (122, 'address', 'ঠিকানা', 'Address ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (123, 'mobile_no', 'মোবাইল নাম্বার', 'Mobile No ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (124, 'fax', 'ফ্যাক্স', 'Fax');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (125, 'footer_text', 'ফুটার টেক্সট', 'Footer Text ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (126, 'facebook_url', 'ফেসবুক ইউআরএল', 'Facebook Url ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (127, 'twitter_url', 'টুইটার ইউআরএল', 'Twitter Url ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (128, 'youtube_url', 'ইউটিউব ইউআরএল', 'Youtube Url ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (129, 'google_plus', 'গুগল প্লাস', 'Google Plus ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (130, 'linkedin_url', 'লিঙ্কডইন ইউআরএল', 'Linkedin Url ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (131, 'pinterest_url', 'পিন্টারেস্ট ইউআরএল', 'Pinterest Url ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (132, 'instagram_url', 'ইনস্টাগ্রাম ইউআরএল', 'Instagram Url ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (133, 'save', 'সেভ', 'Save ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (134, 'website_page', 'ওয়েবসাইট পৃষ্ঠা', 'Website Page ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (135, 'welcome', 'স্বাগতম', 'Welcome ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (136, 'message', 'বার্তা', 'Message ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (137, 'doctors', 'ডাক্তাররা', 'Doctors ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (138, 'services', 'সেবা সমূহ', 'Services');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (139, 'call_to_action_section', 'কল টু অ্যাকশন সেকশন', 'Call To Action Section ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (140, 'options', 'অপশন', 'Options ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (141, 'title', 'শিরোনাম', 'Title');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (142, 'subtitle', 'সাবটাইটেল', 'Subtitle');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (143, 'description', 'বর্ণনা', 'Description ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (144, 'photo', 'ছবি', 'Photo');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (145, 'cta', 'সিটিএ', 'Cta');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (146, 'button_text', 'বাটন টেক্সট', 'Button Text ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (147, 'button_url', 'বাটন ইউআরএল', 'Button Url ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (148, '_title', 'টাইটেল', 'Title');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (149, 'meta', 'ম্যাটা ', 'Meta');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (150, 'keyword', 'কীওয়ার্ড', 'Keyword ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (151, 'banner_photo', 'ব্যানার ছবি', 'Banner Photo ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (152, 'about', 'এবাউট', 'About');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (153, 'content', 'কনটেন্ট', 'Content');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (154, 'about_photo', 'এবাউট ফটো', 'About Photo ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (155, 'parallax_photo', 'প্যারালাক্স ফটো', 'Parallax Photo ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (156, 'sl', 'সিরিয়াল', 'Sl');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (157, 'url', 'ইউআরএল ', 'Url');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (158, 'action', 'একশন', 'Action ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (159, 'my_appointment', 'আমার অ্যাপয়েন্টমেন্ট', 'My Appointment ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (160, 'appointment_status', 'অ্যাপয়েন্টমেন্ট এর স্ট্যাটাস', 'Appointment Status ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (161, 'date', 'তারিখ', 'Date');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (162, 'time_slot', 'টাইম স্লট', 'Time Slot ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (163, 'consultation_fees', 'পরামর্শ ফি', 'Consultation Fees ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (164, 'discount', 'ছাড়', 'Discount ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (165, 'remarks', 'মন্তব্য', 'Remarks');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (166, 'exploring', 'এক্সপ্লরিং', 'Exploring');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (167, 'no_schedule_found', 'কোন সময়সূচী পাওয়া যায়নি', 'No Schedule Found ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (168, 'information_has_been_saved_successfully', 'তথ্য সফলভাবে সংরক্ষণ করা হয়েছে', 'Information Has Been Saved Successfully ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (169, 'id', 'আইডি', 'Information Has Been Saved Successfully ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (170, 'consultation', 'পরামর্শ', 'Consultation ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (171, 'serial', 'সিরিয়াল', 'Serial');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (172, 'status', 'স্ট্যাটাস', 'Status');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (173, 'confirmed', 'নিশ্চিত করা হয়েছে', 'Confirmed ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (174, 'available', 'এভিলেবল', 'Available');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (175, 'staff_id', 'এভিলেবল', 'Staff Id ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (176, 'general', 'জেনারেল', 'General ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (177, 'theme', 'থিম', 'Theme ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (178, 'institute_name', 'প্রতিষ্ঠানের নাম', 'Institute Name ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (179, 'currency', 'মুদ্রা', 'Currency');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (180, 'currency_symbol', 'মুদ্রার প্রতীক', 'Currency Symbol ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (181, 'timezone', 'সময় অঞ্চল', 'Timezone ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (182, 'date_format', 'তারিখ বিন্যাস', 'Date Format ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (183, 'system_logo', 'সিস্টেম লোগো', 'System Logo');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (184, 'text_logo', 'টেক্সট লোগো', 'Text Logo ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (185, 'upload', 'আপলোড করুন', 'Upload ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (186, 'select_ground', 'গ্রাউন্ড নির্বাচন করুন', 'Select Ground ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (187, 'filter', 'ফিল্টার', 'Filter ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (188, 'bill_no', 'বিল নং', 'Bill No ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (189, 'delivery', 'ডেলিভারি', 'Delivery');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (190, 'lab_test', 'ল্যাব টেস্ট', 'Lab Test ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (191, 'edit', 'সম্পাদনা করুন', 'Edit ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (192, 'code', 'কোড', 'Code ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (193, 'purchase_unit', 'ক্রয় ইউনিট', 'Purchase Unit ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (194, 'sale_unit', 'বিক্রয় ইউনিট', 'Sale Unit ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (195, 'unit_ratio', 'একক অনুপাত', 'Unit Ratio ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (196, 'purchase_price', 'ক্রয় মূল্য', 'Purchase Price ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (197, 'sales_price', 'বিক্রয় মূল্য', 'Sales Price ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (198, 'all_select', 'সব নির্বাচন করুন', 'All Select ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (199, 'unpaid', 'আনপেইড', 'Unpaid');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (200, 'partly_paid', 'আংশিক অর্থপ্রদান', 'Partly Paid ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (201, 'total_paid', 'পুরাপুরি পরিশোধিত', 'Total Paid ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (202, 'type', 'টাইপ', 'Type ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (203, 'ref_no', 'রেফ নং', 'Ref No ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (204, 'pay_via', 'এর মাধ্যমে অর্থ প্রদান করুন', 'Pay Via ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (205, 'amount', 'এমাউন্ট', 'Amount ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (206, 'dr', 'Dr', 'Dr ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (207, 'cr', 'Cr', 'Cr');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (208, 'ref', 'রেফ', 'Ref ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (209, 'attachment', 'এটাচমেন্ট', 'Attachment ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (210, 'login', 'লগ-ইন', 'Login');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (211, 'welcome_to', 'স্বাগতম', 'Welcome To ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (212, 'username', 'ইউজারনেম', 'Username ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (213, 'password', 'পাস-ওয়ার্ড', 'Password ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (214, 'remember', 'মনে রাখুন', 'Remember ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (215, 'lose_your_password', 'পাসওয়ার্ড ভুলে গেছি', 'Lose Your Password ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (216, 'position', 'পজিশন', 'Position');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (217, 'publish', 'পাবলিশ', 'Publish');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (218, 'target_new_window', 'টার্গেট নিউ উইন্ডো', 'Target New Window ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (219, 'external_url', 'এক্সটারনাল ইউআরএল', 'External Url ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (220, 'external_link', 'এক্সটারনাল লিঙ্ক', 'External Link ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (221, 'successfully', 'সফলভাবে', 'Successfully');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (222, 'access_denied', 'অ্যাক্সেস অস্বীকার করা হয়েছে৷', 'Access Denied ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (223, 'username_has_already_been_used', 'ব্যবহারকারীর নাম ইতিমধ্যে ব্যবহার করা হয়েছে', 'Username Has Already Been Used ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (224, 'week_day', 'বন্ধের দিন', 'Week Day ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (225, 'time_start', 'সময় শুরু', 'Time Start ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (226, 'time_end', 'সময় শেষ', 'Time End ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (227, 'per_patient_duration', 'প্রতি রোগীর সময়কাল', 'Per Patient Duration ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (228, 'make_closed', 'বন্ধ করুন', 'Make Closed ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (229, 'the_consultation_completed', 'পরামর্শ সমাপ্ত', 'The Consultation Completed ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (230, 'done', 'সম্পন্ন', 'Done ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (231, 'the_consultation_has_been_closed', 'পরামর্শ বন্ধ করা হয়েছে', 'The Consultation Has Been Closed ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (232, 'requested', 'অনুরোধ', 'Requested ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (233, 'create_at', 'এ তৈরি করুন', 'Create At ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (234, 'canceled', 'বাতিল', 'Canceled ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (235, 'apply', 'আবেদন করুন', 'Apply ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (236, 'close', 'বন্ধ', 'Close');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (237, 'information_has_been_updated_successfully', 'তথ্য সফলভাবে আপডেট করা হয়েছে', 'Information Has Been Updated Successfully ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (238, 'birthday', 'জন্মদিন', 'Birthday');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (239, 'joining_date', 'যোগদানের তারিখ', 'Joining Date ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (240, 'basic_details', 'মৌলিক বিবরণ', 'Basic Details ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (241, 'gender', 'লিঙ্গ', 'Gender ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (242, 'male', 'পুরুষ', 'Male');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (243, 'female', 'মহিলা', 'Female ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (244, 'religion', 'ধর্ম', 'Religion');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (245, 'blood_group', 'রক্তের গ্রুপ', 'Blood Group ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (246, 'marital_status', 'বৈবাহিক অবস্থাStatus', 'Marital Status ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (247, 'single', 'সিঙ্গেল', 'Single');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (248, 'married', 'বিবাহিত', 'Married ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (249, 'profile_picture', 'প্রোফাইল ছবি', 'Profile Picture ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (250, 'login_details', 'লগ ইন তথ্য', 'Login Details ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (251, 'office_details', 'অফিসের বিবরণ', 'Office Details ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (252, 'qualification', 'যোগ্যতা', 'Qualification ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (253, 'social_links', 'সামাজিক বন্ধন ', 'Social Links ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (254, 'update', 'আপডেট', 'Update');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (255, 'patient_id', 'রোগীর আইডি', 'Patient Id ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (256, 'guardian', 'অভিভাবক', 'Guardian ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (257, 'authentication', 'অথিন্টিকেশন', 'Authentication ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (258, 'basic', 'বেসিক', 'Basic');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (259, 'age', 'বয়স', 'Age');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (260, 'blood_pressure', 'রক্তচাপ', 'Blood Pressure ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (261, 'height', 'উচ্চতা', 'Height');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (262, 'weight', 'ওজন', 'Weight');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (263, 'emergency_contact', 'জরুরী যোগাযোগ', 'Emergency Contact ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (264, 'relationship', 'সম্পর্ক', 'Relationship ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (265, 'history', 'হিস্টরি', 'History');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (266, 'completed', 'সম্পন্ন', 'Completed');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (267, 'undelivered', 'ডেলিভারি করা হয়নি', 'Undelivered ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (268, 'login_authentication_deactivate', 'লগইন প্রমাণীকরণ নিষ্ক্রিয় করুন', 'Login Authentication Deactivate ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (269, 'deactivate_account', 'অ্যাকাউন্ট নিষ্ক্রিয়', 'Deactivate Account ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (270, 'authentication_activate', 'প্রমাণীকরণ সক্রিয় করুন', 'Authentication Activate ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (271, 'referred_by', 'Referred By', 'Referred By ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (272, 'time', 'সময়', 'Time ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (273, 'price', 'মূল্য', 'Price ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (274, 'add_rows', 'সারি যোগ করুন', 'Add Rows ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (275, 'sub_total', 'সাব-টোটাল', 'Sub Total ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (276, 'tax', 'ট্যাক্স', 'Tax ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (277, 'received', 'রিসিভড', 'Received');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (278, 'enter_payment_amount', 'এখানে টাকার পরিমাণ লিখুন', 'Enter Payment Amount ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (279, 'write_your_remarks', 'আপনার মন্তব্য লিখুন', 'Write Your Remarks ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (280, 'roles', 'পদবি সমূহ', 'Roles');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (281, 'system_role', 'সিস্টেম পদবি', 'System Role ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (282, 'yes', 'হ্যাঁ ', 'Yes');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (283, 'role_permission_for', 'পদবির জন্য অনুমতি প্রাপ্ত', 'Role Permission For ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (284, 'feature', 'ফিচার', 'Feature');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (285, 'view', 'দেখুন', 'View');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (286, 'delete', 'ডিলিট', 'Delete');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (287, 'ordered', 'অডারেড', 'Ordered ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (288, 'quantity', 'কোয়ান্টিটি ', 'Quantity');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (289, 'net_total', 'নেট টোটাল', 'Net Total ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (290, 'bill_view', 'বিল দেখুন', 'Bill View ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (291, 'add_payment', 'এড পেমেন্ট', 'Add Payment ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (292, 'to', 'প্রতি', 'To');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (293, 'company', 'কোম্পানি ', 'Company');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (294, 'sub', 'সাব', 'Sub');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (295, 'paid_amount', 'পেইড এমাউন্ট', 'Paid Amount ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (296, 'prepared_by', 'প্রস্তুতকারক', 'Prepared By ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (297, 'authorised_by', 'অনুমোদিত', 'Authorised By ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (298, 'print', 'প্রিন্ট', 'Print');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (299, 'paid_on', 'পেইড অন', 'Paid On ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (300, 'attach_document', 'ডকুমেন্ট সংযুক্ত করুন', 'Attach Document ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (301, 'the_configuration_has_been_updated', 'কনফিগারেশন আপডেট করা হয়েছে', 'The Configuration Has Been Updated ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (302, 'retype_password', 'পাসওয়ার্ড পুনরায় টাইপ করুন', 'Retype Password ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (303, 'contact_number', 'যোগাযোগের নম্বর', 'Contact Number ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (304, 'company_name', 'কোম্পানির নাম', 'Company Name ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (305, 'product', 'প্রোডাক্ট', 'Product ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (306, 'stock_by', 'স্টক বাই', 'Stock By ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (307, 'inovice_no', 'ইনভয়েছ নং', 'Inovice No ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (308, 'sales_unit', 'সেলস ইউনিট', 'Sales Unit ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (309, 'for', 'জন্য', 'For');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (310, 'select_multiple_chemical', 'একাধিক কেমিক্যাল নির্বাচন করুন', 'Select Multiple Chemical ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (311, 'payment_history', 'পেমেন্ট হিস্টরি ', 'Payment History ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (312, 'sex', 'সেক্স', 'Sex');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (313, 'from', 'থেকে', 'From ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (314, 'net_payable', 'নেট পে-এবল', 'Net Payable ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (315, 'collect_by', 'দ্বারা সংগ্রহ', 'Collect By ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (316, 'unpublished_on_website', 'ওয়েবসাইটে অপ্রকাশিত', 'Unpublished On Website ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (317, 'published_on_website', 'ওয়েবসাইটে প্রকাশিত', 'Published On Website ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (318, 'grade', 'শ্রেণী', 'Grade ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (319, 'overtime', 'ওভারটাইম', 'Overtime ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (320, 'allowances', 'ভাতা', 'Allowances ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (321, 'name_of_allowance', 'ভাতার নাম', 'Name Of Allowance ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (322, 'deductions', 'কর্তন', 'Deductions ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (323, 'name_of_deductions', 'ডেডুকেশনের নাম', 'Name Of Deductions ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (324, 'allowance', 'ভাতা', 'Allowance ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (325, 'deduction', 'ডেডুকেশন', 'Deduction ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (326, 'salary_details', 'বেতন বিবরণ', 'Salary Details ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (327, 'no_information_available', 'কোন তথ্য নেই', 'No Information Available ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (328, 'transactions', 'লেনদেন', 'Transactions ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (329, 'sms_config', 'এসএমএস কনফিগারেশন', 'Sms Config ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (330, 'sms_template', 'এসএমএস টেমপ্লেট', 'Sms Template ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (331, 'select_a_sms_service', 'একটি এসএমএস পরিষেবা নির্বাচন করুন', 'Select A Sms Service ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (332, 'disabled', 'ডিজএবল', 'Disabled ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (333, 'clickatell_username', 'Clickatell ব্যবহারকারীর নাম', 'Clickatell Username ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (334, 'clickatell_password', 'Clickatell পাসওয়ার্ড', 'Clickatell Password ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (335, 'clickatell_api_key', 'Clickatell Api কী', 'Clickatell Api Key ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (336, 'registered_number', 'নিবন্ধিত নম্বর', 'Registered Number ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (337, 'account_sid', 'একাউন্ট  Sid', 'Account Sid ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (338, 'auth_token', 'Auth টোকেন', 'Auth Token ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (339, 'account_registered', 'অ্যাকাউন্ট নিবন্ধিত', 'Account Registered ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (340, 'notify_enable', 'সক্রিয় বিজ্ঞপ্তি', 'Notify Enable ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (341, 'body', 'বডি', 'Body ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (342, 'appointment_confirmation', 'অ্যাপয়েন্টমেন্ট কনফিগারেশন', 'Appointment Confirmation ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (343, 'appointment_canceled', 'অ্যাপয়েন্টমেন্ট বাতিল করা হয়েছে', 'Appointment Canceled ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (344, 'appointment_request', 'অ্যাপয়েন্টমেন্ট  অনুরোধ', 'Appointment Request ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (345, 'reporting', 'রিপোর্টিং', 'Reporting');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (346, 'button_text_1', 'বোতাম টেক্সট  ১', 'Button Text 1 ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (347, 'button_url_1', 'বোতাম ইউআরএল ১', 'Button Url 1 ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (348, 'button_text_2', 'বোতাম টেক্সট  ২', 'Button Text 2 ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (349, 'button_url_2', 'বোতাম ইউআরএল ২', 'Button Url 2 ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (350, 'left', 'বাম', 'Left ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (351, 'center', 'সেন্টার ', 'Center');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (352, 'right', 'ডান', 'Right');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (353, 'icon', 'আইকন', 'Icon ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (354, 'surname', 'সারনেম', 'Surname ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (355, 'rank', 'রেঙ্ক', 'Rank');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (356, 'staff', 'স্টাফ', 'Staff ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (357, 'paid_by', 'পেইড বাই', 'Paid By ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (358, 'user', 'ইউজার', 'User ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (359, 'payslip', 'পেস্লিপ', 'Payslip ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (360, 'add_employee', 'কর্মচারী যোগ করুন', 'Add Employee ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (361, 'bank_details', 'ব্যাংক বিবরণ', 'Bank Details ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (362, 'skipped_bank_details', 'এড়িয়ে যাওয়া ব্যাঙ্কের বিবরণ', 'Skipped Bank Details ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (363, 'bank_name', 'ব্যাংকের নাম', 'Bank Name ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (364, 'holder_name', 'হোল্ডার এর নাম', 'Holder Name ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (365, 'bank', 'ব্যাংক', 'Bank');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (366, 'branch', 'ব্রাঞ্চ', 'Branch ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (367, 'ifsc_code', 'আইএফছি কোড', 'Ifsc Code ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (368, 'account_no', 'হিসাব নাম্বার', 'Account No ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (369, 'restore', 'পুনরুদ্ধার করুন', 'Restore ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (370, 'create_backup', 'ব্যাকআপ তৈরি', 'Create Backup ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (371, 'file', 'ফাইল', 'File ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (372, 'backup_size', 'ব্যাকআপ সাইজ', 'Backup Size ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (373, 'file_upload', 'ফাইল আপলোড', 'File Upload ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (374, 'flag', 'পতাকা', 'Flag ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (375, 'stats', 'পরিসংখ্যান', 'Stats');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (376, 'created_at', 'ক্রিয়েট এট', 'Created At ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (377, 'updated_at', 'আপডেট এট', 'Updated At ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (378, 'edit_word', 'এডিট ওয়ার্ড', 'Edit Word ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (379, 'flag_icon', ' ফ্লাগ আইকন', 'Flag Icon ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (380, 'language_unpublished', 'ভাষা আনপাবলিশ ', 'Language Unpublished ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (381, 'language_published', 'ভাষা পাবলিশ', 'Language Published ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (382, 'transaction', 'ট্রানজেকশন', 'Transaction ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (383, 'month_of_salary', 'বেতনের মাস', 'Month Of Salary ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (384, 'basic_salary', 'মূল বেতন', 'Basic Salary ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (385, 'payment_type', 'পেমেন্ট টাইপ', 'Payment Type ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (386, 'bank_account', 'ব্যাংক একাউন্ট', 'Bank Account ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (387, 'actions', 'একশন ', 'Actions ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (388, 'document', 'ডকুমেন্ট', 'Document ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (389, 'download', 'ডাউনলোড ', 'Download ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (390, 'opening_balance', 'অপেনিং ব্যাল্যান্স', 'Opening Balance ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (391, 'total_dr', 'টোটাল Dr', 'Total Dr ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (392, 'total_cr', 'টোটাল Cr', 'Total Cr ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (393, 'contact', 'যোগাযোগ', 'Contact');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (394, 'box_title', 'বক্স শিরোনাম', 'Box Title ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (395, 'box_description', 'বক্সের বর্ণনা', 'Box Description ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (396, 'box_photo', 'বক্স ছবি', 'Box Photo ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (397, 'form_title', 'ফর্ম শিরোনাম', 'Form Title ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (398, 'phone', 'ফোন', 'Phone ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (399, 'submit_button_text', 'সাবমিট বাটন টেক্সট', 'Submit Button Text ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (400, 'map_iframe', 'ম্যাপ আইফ্রেম', 'Map Iframe ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (401, 'system_name', 'সিস্টেম এর নাম', 'System Name ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (402, 'month', 'মাস', 'Month');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (403, 'patient_price', 'রোগীর দাম', 'Patient Price ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (404, 'production_cost', 'উৎপাদন খরচ', 'Production Cost ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (405, 'created_by', 'ক্রিয়েটেড বাই', 'Created By ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (406, 'test_category', 'টেস্ট ক্যাটাগরি', 'Test Category ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (407, 'test_name', 'টেস্ট এর নাম', 'Test Name ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (408, 'test_code', 'টেস্ট কোড', 'Test Code ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (409, 'staff_name', 'স্টাফ এর নাম', 'Staff Name ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (410, 'percentage', 'পারছেন্টেজ', 'Percentage ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (411, 'salary_assign', 'বেতন বরাদ্দ', 'Salary Assign ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (412, 'pay_now', 'এখনি পরিশোধ করুন', 'Pay Now ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (413, 'overtime_total_hour', 'ওভারটাইম মোট ঘন্টা', 'Overtime Total Hour ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (414, 'overtime_amount', 'ওভারটাইম পরিমাণ', 'Overtime Amount ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (415, 'leave_category', 'ক্যাটাগরি ছেড়ে দিন', 'Leave Category ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (416, 'days', 'দিন সমূহ', 'Days');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (417, 'leave', 'ছেড়ে দিন', 'Leave');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (418, 'date_of_start', 'শুরুর তারিখ', 'Date Of Start ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (419, 'date_of_end', 'শেষের তারিখ', 'Date Of End ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (420, 'leave_type', 'ছুটির ধরন', 'Leave Type ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (421, 'reason', 'কারন', 'Reason ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (422, 'comments', 'কমেন্টস', 'Comments');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (423, 'accepted', 'এক্সেপ্টেড', 'Accepted ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (424, 'start_date', 'শুরুর তারিখ', 'Start Date ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (425, 'end_date', 'ইন্ড ডেট', 'End Date ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (426, 'approved', 'এপ্রুভ', 'Approved');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (427, 'reject', 'রিজেক্ট', 'Reject');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (428, 'select_all', 'সব নির্বাচন করুন', 'Select All ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (429, 'not_selected', 'অনির্বাচিত', 'Not Selected ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (430, 'present', 'উপস্থিত', 'Present');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (431, 'absent', 'অনুপস্থিত', 'Absent ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (432, 'holiday', 'ছুটির দিন', 'Holiday ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (433, 'late', 'লেট', 'Current Balance ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (434, 'current_balance', 'বর্তমান হিসাব', 'Current Balance ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (435, 'no', 'নং', 'No ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (436, 'current', 'কারেন্ট', 'Current ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (437, 'qty', 'কোয়ান্টিটি ', 'Qty');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (438, 'payment_successfull', 'পেমেন্ট সফল', 'Payment Successfull ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (439, 'payment_by', 'দ্বারা পেমেন্ট', 'Payment By ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (440, 'chemical_wise_stock', 'কেমিক্যাল ওয়াইজ স্টক', 'Chemical Wise Stock ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (441, 'sale', 'সেল', 'Sale');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (442, 'in_qty', 'ইন কোয়ান্টিটি', 'In Qty ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (443, 'out_qty', 'আউট কোয়ান্টিটি ', 'Out Qty ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (444, 'sale_profit', 'বিক্রয় প্রফিট', 'Sale Profit ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (445, 'paid_via', 'পেইড ভায়া', 'Paid Via ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (446, 'collected_by', 'কালেক্টেড বাই', 'Collected By ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (447, 'all', 'সকল', 'All');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (448, 'add_short_bio', 'সংক্ষিপ্ত বায়ো যোগ করুন', 'Add Short Bio ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (449, 'email_config', 'ইমেল কনফিগারেশন', 'Email Config ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (450, 'email_triggers', 'ইমেল ট্রিগার', 'Email Triggers ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (451, 'system_email', 'সিস্টেম ইমেল', 'System Email ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (452, 'subject', 'বিষয়', 'Subject');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (453, 'forgot_password', 'পাসওয়ার্ড ভুলে গেছেন', 'Forgot Password ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (454, 'payslip_generated', 'পেস্লিপ জেনারেট হয়েছে', 'Payslip Generated ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (455, 'leave_approve', 'লিভ এপ্রুভ', 'Leave Approve ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (456, 'leave_reject', 'লিভ রিজেক্ট', 'Leave Reject ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (457, 'rename', 'রিনেম করুন', 'Rename ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (458, 'word', 'শব্দ', 'Word');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (459, 'translations', 'ট্রান্সলেশন', 'Translations ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (460, 'username_password_incorrect', 'Username Password Incorrect', '');


#
# TABLE STRUCTURE FOR: leave_application
#

DROP TABLE IF EXISTS `leave_application`;

CREATE TABLE `leave_application` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `category_id` varchar(20) NOT NULL,
  `reason` text CHARACTER SET utf32 COLLATE utf32_unicode_ci NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `leave_days` varchar(20) NOT NULL DEFAULT '0',
  `status` varchar(10) NOT NULL DEFAULT '1',
  `apply_date` datetime NOT NULL,
  `orig_file_name` varchar(255) NOT NULL,
  `enc_file_name` varchar(255) NOT NULL,
  `approved_by` longtext NOT NULL,
  `comments` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: leave_category
#

DROP TABLE IF EXISTS `leave_category`;

CREATE TABLE `leave_category` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf32 COLLATE utf32_unicode_ci NOT NULL,
  `days` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: login_credential
#

DROP TABLE IF EXISTS `login_credential`;

CREATE TABLE `login_credential` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(250) NOT NULL,
  `role` int(11) NOT NULL,
  `active` int(11) NOT NULL COMMENT '1(active) 0(deactivate)',
  `last_login` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (1, 1, 'info@elitedesign.com.bd', '$2y$10$/KeWDEBe7K4ONl9De8G/d.1U79a8i32g9vkxU8unnHS9JPlVKZqt6', 1, 1, '2023-04-21 03:07:46', '2023-03-14 17:19:37', '2023-04-20 17:07:46');
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (2, 1, 'admin', '$2y$10$rQlDsVs.qa80QpNCELxnb.sljkTNQqodP25X5eZWLDseOVOHn6H6u', 1, 1, '2023-03-18 12:53:51', '2023-03-14 17:19:39', '2023-03-18 02:53:51');
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (3, 2, 'receptionist@elitedesign.com.bd', '$2y$10$GPtzkiAdMP28olkgXKDB6.WLrMp.c0zsEa9Rbix0vHlAIUJrcSqx6', 6, 1, '2023-03-22 22:44:31', '2023-03-15 03:19:01', '2023-03-22 12:44:31');
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (4, 3, 'lab@elitedesign.com.bd', '$2y$10$9/N00h7FK/ru7i25KyTqXuWEzor02YvOD7lh.TOuQz0FdUpQEKQBK', 5, 1, '2023-04-04 19:45:35', '2023-03-15 03:21:23', '2023-04-04 09:45:35');
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (5, 4, 'accounts@elitedesign.com.bd', '$2y$10$PcxuRV0/hIV4xCR7AUV8M.fVRKfxTfI8JO75/pjqwviOAJOVDRfjq', 4, 1, NULL, '2023-03-15 03:23:26', '2023-03-15 03:23:26');
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (6, 5, 'doctor@elitedesign.com.bd', '$2y$10$vsA4hCjk5SBJeH/qZFj8TenXTYu6vL.ZJvDWMyFnYWBuNXCmkvF.i', 3, 1, NULL, '2023-03-15 03:26:12', '2023-03-15 03:26:12');
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (7, 1, 'shahin@elitedesign.com.bd', '$2y$10$tF/bJVC3Gs8UM.doGNTPPuTfFnMF0jmua22nFt2dk0J339G3aEA/a', 7, 1, NULL, '2023-03-15 03:29:33', '2023-03-15 03:29:33');
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (8, 2, 'nazrul@gmail.com', '$2y$10$L9LxmNgk0k05eUtTWCZXS.oVEsQQU/KVAUHeqosrGmOmUHBdZ4RNa', 7, 1, NULL, '2023-03-15 03:34:50', '2023-03-15 03:34:50');
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (9, 3, 'jahanarakhanom@elitedesign.com.bd', '$2y$10$4EsdLjQCeFZWJgaojxqapOtZSWD2NV2QMMCs0l88PpkCQPDGoVIXq', 7, 1, NULL, '2023-03-15 03:38:10', '2023-03-15 03:38:10');
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (10, 4, 'muttakinasa256@gmail.com', '$2y$10$BeRTxq8WtnizzZruTM4YhOEsMRkkcb/xq6izp6RWaJOaLI6jgkUKi', 7, 1, NULL, '2023-03-17 16:38:19', '2023-03-17 16:38:19');
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (11, 5, 'muttakinasa452@gmail.com', '$2y$10$uKsgHJXrU6dnI7VQO1nnouf1zUi3xAqoPZAvZMUu30.xtCqsOFK/G', 7, 1, NULL, '2023-03-19 02:32:28', '2023-03-19 02:32:28');


#
# TABLE STRUCTURE FOR: patient
#

DROP TABLE IF EXISTS `patient`;

CREATE TABLE `patient` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `patient_id` varchar(10) NOT NULL,
  `category_id` int(11) NOT NULL,
  `birthday` date NOT NULL,
  `sex` varchar(10) NOT NULL,
  `blood_group` varchar(10) NOT NULL,
  `blood_pressure` varchar(100) NOT NULL,
  `height` varchar(10) NOT NULL,
  `weight` varchar(10) NOT NULL,
  `marital_status` varchar(10) NOT NULL,
  `age` varchar(10) DEFAULT NULL,
  `address` text NOT NULL,
  `mobileno` varchar(30) NOT NULL,
  `email` varchar(200) NOT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `guardian` varchar(200) NOT NULL,
  `relationship` varchar(200) NOT NULL,
  `gua_mobileno` varchar(30) NOT NULL,
  `source` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `patient` (`id`, `name`, `patient_id`, `category_id`, `birthday`, `sex`, `blood_group`, `blood_pressure`, `height`, `weight`, `marital_status`, `age`, `address`, `mobileno`, `email`, `photo`, `guardian`, `relationship`, `gua_mobileno`, `source`, `created_at`, `updated_at`) VALUES (1, 'md Shahin Ali', 'b629e5c', 2, '1995-05-09', 'male', 'O+', '120', '6 Feet', '64 KG', '1', '27', '35/3/1-B,section-13,Dhaka', '01775457008', 'shahin@elitedesign.com.bd', '55859617f3ee09006561b1dc2c3db861.png', '', '', '', 1, '2023-03-15 03:29:33', '2023-03-15 03:29:33');
INSERT INTO `patient` (`id`, `name`, `patient_id`, `category_id`, `birthday`, `sex`, `blood_group`, `blood_pressure`, `height`, `weight`, `marital_status`, `age`, `address`, `mobileno`, `email`, `photo`, `guardian`, `relationship`, `gua_mobileno`, `source`, `created_at`, `updated_at`) VALUES (2, 'Md Nazrul islam', 'c03bc4d', 1, '1995-05-15', 'male', 'O+', '120', '6 Feet', '64 KG', '2', '27', '35/3/1-B', '01775457008', 'nazrul@gmail.com', 'de5438f139f9308271c002cb45fd4b63.png', '', '', '', 1, '2023-03-15 03:34:50', '2023-03-15 03:35:07');
INSERT INTO `patient` (`id`, `name`, `patient_id`, `category_id`, `birthday`, `sex`, `blood_group`, `blood_pressure`, `height`, `weight`, `marital_status`, `age`, `address`, `mobileno`, `email`, `photo`, `guardian`, `relationship`, `gua_mobileno`, `source`, `created_at`, `updated_at`) VALUES (3, 'jahana khanom', 'e4ef6c3', 1, '2002-06-04', 'female', 'O+', '120', '5 Feet', '65 KG', '2', '20', 'Dhaka', '01775457008', 'jahanarakhanom@elitedesign.com.bd', '07ce732f3c6f4d44683fe8cd6b2f1a5e.jpg', '', '', '', 1, '2023-03-15 03:38:10', '2023-03-15 03:38:10');
INSERT INTO `patient` (`id`, `name`, `patient_id`, `category_id`, `birthday`, `sex`, `blood_group`, `blood_pressure`, `height`, `weight`, `marital_status`, `age`, `address`, `mobileno`, `email`, `photo`, `guardian`, `relationship`, `gua_mobileno`, `source`, `created_at`, `updated_at`) VALUES (4, 'SM Muttakin', '10817ad', 1, '2004-06-13', '', 'O+', '52', '5', '30', '1', '18', '35/3', '01778208785', 'muttakinasa256@gmail.com', 'defualt.png', '', '', '', 1, '2023-03-17 16:38:19', '2023-03-17 16:38:19');
INSERT INTO `patient` (`id`, `name`, `patient_id`, `category_id`, `birthday`, `sex`, `blood_group`, `blood_pressure`, `height`, `weight`, `marital_status`, `age`, `address`, `mobileno`, `email`, `photo`, `guardian`, `relationship`, `gua_mobileno`, `source`, `created_at`, `updated_at`) VALUES (5, 'Md abu sayed', 'f4c15a2', 1, '1995-07-13', 'male', 'O+', '52', '5', '60', '2', '27', '35/3b anhjvjhhv ', '01778208786', 'muttakinasa452@gmail.com', 'defualt.png', '', '', '', 1, '2023-03-19 02:32:27', '2023-03-19 02:32:27');


#
# TABLE STRUCTURE FOR: patient_category
#

DROP TABLE IF EXISTS `patient_category`;

CREATE TABLE `patient_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `patient_category` (`id`, `name`) VALUES (1, 'Lab Test');
INSERT INTO `patient_category` (`id`, `name`) VALUES (2, 'Medical Patient');


#
# TABLE STRUCTURE FOR: patient_documents
#

DROP TABLE IF EXISTS `patient_documents`;

CREATE TABLE `patient_documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `type` varchar(100) NOT NULL,
  `remarks` text NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `enc_name` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: payment_type
#

DROP TABLE IF EXISTS `payment_type`;

CREATE TABLE `payment_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `payment_type` (`id`, `name`) VALUES (1, 'Cash');
INSERT INTO `payment_type` (`id`, `name`) VALUES (2, 'Bkash');
INSERT INTO `payment_type` (`id`, `name`) VALUES (3, 'Rocket');
INSERT INTO `payment_type` (`id`, `name`) VALUES (4, 'Nagod');
INSERT INTO `payment_type` (`id`, `name`) VALUES (5, 'Upay');
INSERT INTO `payment_type` (`id`, `name`) VALUES (6, 'Cheque');
INSERT INTO `payment_type` (`id`, `name`) VALUES (7, 'Bank Transfer');


#
# TABLE STRUCTURE FOR: payout_commission
#

DROP TABLE IF EXISTS `payout_commission`;

CREATE TABLE `payout_commission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `bill_no` varchar(11) NOT NULL,
  `before_payout` decimal(18,2) NOT NULL DEFAULT 0.00,
  `amount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `pay_via` int(11) NOT NULL,
  `remarks` text DEFAULT NULL,
  `paid_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: payslip
#

DROP TABLE IF EXISTS `payslip`;

CREATE TABLE `payslip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `month` varchar(20) DEFAULT NULL,
  `year` varchar(20) NOT NULL,
  `basic_salary` decimal(18,2) NOT NULL DEFAULT 0.00,
  `total_allowance` decimal(18,2) NOT NULL DEFAULT 0.00,
  `total_deduction` decimal(18,2) NOT NULL DEFAULT 0.00,
  `net_salary` decimal(18,2) NOT NULL DEFAULT 0.00,
  `bill_no` varchar(25) NOT NULL,
  `remarks` text NOT NULL,
  `pay_via` tinyint(1) NOT NULL,
  `hash` varchar(255) DEFAULT NULL,
  `paid_by` int(11) NOT NULL,
  `payment_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: payslip_details
#

DROP TABLE IF EXISTS `payslip_details`;

CREATE TABLE `payslip_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `payslip_id` varchar(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `amount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `type` tinyint(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: permission
#

DROP TABLE IF EXISTS `permission`;

CREATE TABLE `permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `prefix` varchar(100) NOT NULL,
  `show_view` tinyint(2) DEFAULT 1,
  `show_add` tinyint(2) DEFAULT 1,
  `show_edit` tinyint(2) DEFAULT 1,
  `show_delete` tinyint(2) DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (1, 2, 'Patient', 'patient', 1, 1, 1, 1, '2019-05-27 16:28:52');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (2, 2, 'Patient Category', 'patient_category', 1, 1, 1, 1, '2019-05-27 16:28:52');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (3, 6, 'Employee', 'employee', 1, 1, 1, 1, '2019-05-27 16:28:52');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (4, 6, 'Department', 'department', 1, 1, 1, 1, '2019-05-27 16:28:52');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (5, 6, 'Designation', 'designation', 1, 1, 1, 1, '2019-05-27 16:28:52');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (6, 6, 'Login Deactivate', 'employee_disable_authentication', 1, 0, 1, 0, '2019-05-27 23:56:59');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (7, 7, 'Salary Template', 'salary_template', 1, 1, 1, 1, '2019-05-27 17:09:28');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (8, 7, 'Salary Assign', 'salary_assign', 1, 1, 0, 0, '2019-05-27 17:09:34');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (9, 8, 'Lab Test', 'lab_test', 1, 1, 1, 1, '2019-05-27 16:28:52');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (10, 8, 'Test Category', 'test_category', 1, 1, 1, 1, '2019-05-27 16:28:53');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (11, 12, 'Test Report', 'test_report', 1, 1, 1, 0, '2019-05-27 16:28:53');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (12, 12, 'Test Report Template', 'test_report_template', 1, 1, 1, 1, '2019-05-27 16:28:53');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (13, 11, 'Lab Test Bill', 'lab_test_bill', 1, 1, 0, 1, '2019-05-27 23:12:14');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (14, 11, 'Test Bill Report', 'test_bill_report', 1, 0, 0, 0, '2019-05-27 23:12:28');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (15, 11, 'Test Bill Payment', 'test_bill_payment', 1, 1, 0, 0, '2019-05-27 23:12:28');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (16, 9, 'Referral Assign', 'referral_assign', 1, 1, 1, 1, '2019-05-27 23:34:50');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (17, 9, 'Commission Withdrawal', 'commission_withdrawal', 1, 1, 0, 1, '2019-05-27 23:34:59');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (18, 9, 'Referral Reports', 'referral_reports', 1, 0, 0, 0, '2019-05-27 23:35:02');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (19, 2, 'Login Deactivate', 'patient_disable_authentication', 1, 0, 1, 0, '2019-05-27 16:28:52');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (20, 3, 'Purchase Payment', 'purchase_payment', 1, 1, 0, 0, '2019-05-28 01:02:18');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (21, 13, 'Global Setting', 'global_setting', 1, 1, 0, 0, '2019-05-28 02:28:04');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (22, 13, 'Email Setting', 'email_setting', 1, 1, 0, 0, '2019-05-29 12:42:40');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (23, 13, 'Language', 'language', 1, 1, 1, 1, '2019-05-29 01:10:08');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (24, 13, 'Database Backup', 'database_backup', 1, 1, 0, 1, '2019-05-28 12:54:40');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (25, 13, 'Database Restore', 'database_restore', 0, 1, 0, 0, '2019-05-28 13:07:49');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (26, 7, 'Salary Payment', 'salary_payment', 1, 1, 0, 0, '2019-05-30 14:27:03');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (27, 7, 'Salary Summary Report', 'salary_summary_report', 1, 0, 0, 0, '2019-05-31 19:46:17');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (28, 7, 'Leave Category', 'leave_category', 1, 1, 1, 1, '2019-06-02 01:12:59');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (29, 7, 'My Leave', 'my_leave', 1, 1, 0, 1, '2019-06-03 21:01:42');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (30, 7, 'Leave Manage', 'leave_manage', 1, 1, 0, 1, '2019-06-04 14:40:20');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (31, 7, 'Staff Attendance', 'staff_attendance', 1, 1, 0, 0, '2019-06-05 01:53:37');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (32, 10, 'Account', 'account', 1, 1, 1, 1, '2019-06-07 16:58:38');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (33, 10, 'Voucher', 'voucher', 1, 1, 1, 1, '2019-06-09 01:17:14');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (34, 10, 'Voucher Head', 'voucher_head', 1, 1, 1, 1, '2019-06-08 19:00:33');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (35, 10, 'Accounting Reports', 'accounting_reports', 1, 0, 0, 0, '2019-06-09 20:56:59');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (36, 4, 'Schedule', 'schedule', 1, 1, 1, 1, '2019-06-13 05:47:17');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (37, 5, 'Appointment', 'appointment', 1, 1, 1, 1, '2019-06-13 05:56:41');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (38, 5, 'Appointment Request', 'appointment_request', 1, 0, 1, 1, '2019-06-14 16:21:02');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (39, 1, 'Today Invoice Widget', 'today_invoice_widget', 1, 0, 0, 0, '2019-06-17 00:02:40');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (40, 1, 'Today Commission Widget', 'today_commission_widget', 1, 0, 0, 0, '2019-06-17 00:02:40');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (41, 1, 'Today Income Widget', 'today_income_widget', 1, 0, 0, 0, '2019-06-17 00:02:40');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (42, 1, 'Today Expense Widget', 'today_expense_widget', 1, 0, 0, 0, '2019-06-17 00:02:40');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (43, 1, 'Annual Income Vs Expense Chart', 'annual_income_vs_expense_chart', 1, 0, 0, 0, '2019-06-17 00:27:47');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (44, 1, 'Patient Count Widget', 'patient_count_widget', 1, 0, 0, 0, '2019-06-17 00:38:33');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (45, 1, 'Doctor Count Widget', 'doctor_count_widget', 1, 0, 0, 0, '2019-06-17 00:38:33');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (46, 1, 'Employee Count Widget', 'employee_count_widget', 1, 0, 0, 0, '2019-06-17 00:38:33');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (47, 1, 'Appointment Count Widget', 'appointment_count_widget', 1, 0, 0, 0, '2019-06-17 00:38:33');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (48, 1, 'Pathology Fees Summary Chart', 'pathology_fees_summary_chart', 1, 0, 0, 0, '2019-06-17 00:48:28');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (49, 14, 'Frontend Setting', 'frontend_setting', 1, 1, 0, 0, '2019-09-11 03:24:07');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (50, 14, 'Frontend Menu', 'frontend_menu', 1, 1, 1, 1, '2019-09-11 04:03:39');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (51, 14, 'Frontend Section', 'frontend_section', 1, 1, 0, 0, '2019-09-11 04:26:11');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (52, 14, 'Manage Page', 'manage_page', 1, 1, 1, 1, '2019-09-11 05:54:08');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (53, 14, 'Frontend Slider', 'frontend_slider', 1, 1, 1, 1, '2019-09-11 06:12:31');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (54, 14, 'Frontend Features', 'frontend_features', 1, 1, 1, 1, '2019-09-11 06:47:51');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (55, 14, 'Frontend Testimonial', 'frontend_testimonial', 1, 1, 1, 1, '2019-09-11 06:54:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (56, 14, 'Frontend Services', 'frontend_services', 1, 1, 1, 1, '2019-09-11 07:01:44');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (57, 14, 'Frontend Faq', 'frontend_faq', 1, 1, 1, 1, '2019-09-11 07:06:16');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (58, 13, 'Sms Setting', 'sms_setting', 1, 1, 0, 0, '2019-09-13 11:41:37');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (59, 14, 'Doctor Short Bio', 'doctor_short_bio', 0, 1, 0, 0, '2019-09-17 20:13:12');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (60, 1, 'Appointment Status Chart', 'appointment_status_chart', 1, 0, 0, 0, '2019-06-17 00:48:28');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (61, 9, 'My Commission', 'my_commission', 1, 0, 0, 0, '2019-06-17 00:48:28');


#
# TABLE STRUCTURE FOR: permission_modules
#

DROP TABLE IF EXISTS `permission_modules`;

CREATE TABLE `permission_modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `prefix` varchar(50) NOT NULL,
  `system` tinyint(1) NOT NULL,
  `sorted` tinyint(10) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (1, 'Dashboard', 'dashboard', 1, 1, '2019-05-27 04:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (2, 'Patient Details', 'patient_details', 1, 3, '2019-05-27 04:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (4, 'Schedule', 'schedule', 1, 5, '2019-05-27 04:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (5, 'Appointment', 'appointment', 1, 6, '2019-05-27 04:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (6, 'Employee', 'employee', 1, 7, '2019-05-27 04:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (7, 'Human Resources', 'human_resources', 1, 8, '2019-05-27 04:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (8, 'Pathology', 'test_manager', 1, 9, '2019-05-27 04:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (9, 'Refer Manager', 'refer_manager', 1, 10, '2019-05-27 04:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (10, 'Office Accounting', 'office_accounting', 1, 11, '2019-05-27 04:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (11, 'Pathology Billing', 'billing', 1, 12, '2019-05-27 04:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (12, 'Investigation Report', 'investigation_report', 1, 13, '2019-05-27 04:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (13, 'Settings', 'settings', 1, 14, '2019-05-27 04:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (14, 'Website', 'website', 1, 2, '2019-05-27 04:23:00');


#
# TABLE STRUCTURE FOR: purchase_bill
#

DROP TABLE IF EXISTS `purchase_bill`;

CREATE TABLE `purchase_bill` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bill_no` varchar(200) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `remarks` text NOT NULL,
  `total` decimal(18,2) NOT NULL DEFAULT 0.00,
  `discount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `paid` decimal(18,2) NOT NULL DEFAULT 0.00,
  `due` decimal(18,2) NOT NULL DEFAULT 0.00,
  `payment_status` int(11) NOT NULL,
  `purchase_status` int(11) NOT NULL,
  `hash` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `prepared_by` int(11) DEFAULT NULL,
  `modifier_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: purchase_bill_details
#

DROP TABLE IF EXISTS `purchase_bill_details`;

CREATE TABLE `purchase_bill_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_bill_id` int(11) NOT NULL,
  `chemical_id` varchar(20) NOT NULL,
  `unit_price` decimal(18,2) NOT NULL DEFAULT 0.00,
  `quantity` varchar(20) NOT NULL,
  `discount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `sub_total` decimal(18,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: purchase_payment_history
#

DROP TABLE IF EXISTS `purchase_payment_history`;

CREATE TABLE `purchase_payment_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_bill_id` varchar(11) NOT NULL,
  `payment_by` int(11) DEFAULT NULL,
  `amount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `pay_via` varchar(25) NOT NULL,
  `remarks` text NOT NULL,
  `attach_orig_name` varchar(255) DEFAULT NULL,
  `attach_file_name` varchar(255) DEFAULT NULL,
  `paid_on` date DEFAULT NULL,
  `coll_type` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: referral_commission
#

DROP TABLE IF EXISTS `referral_commission`;

CREATE TABLE `referral_commission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `test_id` int(11) NOT NULL,
  `percentage` varchar(10) NOT NULL,
  `assign_by` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `referral_commission` (`id`, `staff_id`, `test_id`, `percentage`, `assign_by`, `date`) VALUES (1, 2, 48, '10', 1, '2023-04-20');
INSERT INTO `referral_commission` (`id`, `staff_id`, `test_id`, `percentage`, `assign_by`, `date`) VALUES (2, 5, 47, '10', 1, '2023-04-20');


#
# TABLE STRUCTURE FOR: reset_password
#

DROP TABLE IF EXISTS `reset_password`;

CREATE TABLE `reset_password` (
  `key` longtext NOT NULL,
  `username` varchar(100) NOT NULL,
  `login_credential_id` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: roles
#

DROP TABLE IF EXISTS `roles`;

CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `is_system` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `roles` (`id`, `name`, `prefix`, `is_system`) VALUES (1, 'Super Admin', 'superadmin', '1');
INSERT INTO `roles` (`id`, `name`, `prefix`, `is_system`) VALUES (2, 'Admin', 'admin', '1');
INSERT INTO `roles` (`id`, `name`, `prefix`, `is_system`) VALUES (3, 'Doctor', 'doctor', '1');
INSERT INTO `roles` (`id`, `name`, `prefix`, `is_system`) VALUES (4, 'Accountant', 'accountant', '1');
INSERT INTO `roles` (`id`, `name`, `prefix`, `is_system`) VALUES (5, 'Laboratorist', 'laboratorist', '1');
INSERT INTO `roles` (`id`, `name`, `prefix`, `is_system`) VALUES (6, 'Receptionist', 'receptionist', '1');
INSERT INTO `roles` (`id`, `name`, `prefix`, `is_system`) VALUES (7, 'Patient', 'patient', '1');


#
# TABLE STRUCTURE FOR: salary_template
#

DROP TABLE IF EXISTS `salary_template`;

CREATE TABLE `salary_template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `basic_salary` decimal(18,2) NOT NULL DEFAULT 0.00,
  `overtime_salary` varchar(100) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: salary_template_details
#

DROP TABLE IF EXISTS `salary_template_details`;

CREATE TABLE `salary_template_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `salary_template_id` varchar(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `amount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `type` tinyint(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: schedule
#

DROP TABLE IF EXISTS `schedule`;

CREATE TABLE `schedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `day` varchar(100) NOT NULL,
  `doctor_id` varchar(11) NOT NULL,
  `time_start` time NOT NULL,
  `time_end` time NOT NULL,
  `per_patient_time` varchar(50) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `consultation_fees` decimal(18,2) DEFAULT 0.00,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `schedule` (`id`, `day`, `doctor_id`, `time_start`, `time_end`, `per_patient_time`, `active`, `consultation_fees`, `created_at`, `updated_at`) VALUES (1, 'Saturday', '5', '00:15:00', '00:15:00', '5', 1, '500.00', '2023-04-03 14:12:30', '2023-04-03 14:12:30');


#
# TABLE STRUCTURE FOR: sms_config
#

DROP TABLE IF EXISTS `sms_config`;

CREATE TABLE `sms_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clickatell_username` varchar(255) NOT NULL,
  `clickatell_password` varchar(255) NOT NULL,
  `clickatell_api_key` varchar(255) NOT NULL,
  `clickatell_number` varchar(255) NOT NULL,
  `twilio_account_sid` varchar(255) NOT NULL,
  `twilio_auth_token` varchar(255) NOT NULL,
  `twilio_number` varchar(255) NOT NULL,
  `active_gateway` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `sms_config` (`id`, `clickatell_username`, `clickatell_password`, `clickatell_api_key`, `clickatell_number`, `twilio_account_sid`, `twilio_auth_token`, `twilio_number`, `active_gateway`) VALUES (1, '', '', '', '', '', '', '', 'disabled');


#
# TABLE STRUCTURE FOR: sms_templates
#

DROP TABLE IF EXISTS `sms_templates`;

CREATE TABLE `sms_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sms_type` varchar(200) NOT NULL,
  `subject` varchar(250) NOT NULL,
  `template_body` longtext NOT NULL,
  `tags` longtext NOT NULL,
  `notified` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `sms_templates` (`id`, `sms_type`, `subject`, `template_body`, `tags`, `notified`) VALUES (1, 'account_registered', '', '', '{institute_name}, {name}, {username}, {password}, {user_role}, {login_url}', 0);
INSERT INTO `sms_templates` (`id`, `sms_type`, `subject`, `template_body`, `tags`, `notified`) VALUES (2, 'appointment_confirmation', '', '', '{institute_name}, {patient_name}, {doctor_name}, {appointment_id}, {schedule_time}, {appointment_date}', 0);
INSERT INTO `sms_templates` (`id`, `sms_type`, `subject`, `template_body`, `tags`, `notified`) VALUES (3, 'appointment_canceled', '', '', '{institute_name}, {patient_name}, {doctor_name}, {appointment_id}, {schedule_time}, {appointment_date}', 0);
INSERT INTO `sms_templates` (`id`, `sms_type`, `subject`, `template_body`, `tags`, `notified`) VALUES (4, 'appointment_request', '', '', '{institute_name}, {patient_name}, {doctor_name}, {appointment_id}, {schedule_time}, {appointment_date}', 0);


#
# TABLE STRUCTURE FOR: staff
#

DROP TABLE IF EXISTS `staff`;

CREATE TABLE `staff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` varchar(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `department` int(11) NOT NULL,
  `qualification` varchar(200) NOT NULL,
  `designation` int(11) NOT NULL,
  `joining_date` date NOT NULL,
  `birthday` date NOT NULL,
  `gender` varchar(12) NOT NULL,
  `religion` varchar(200) NOT NULL,
  `blood_group` varchar(11) NOT NULL,
  `marital_status` varchar(10) NOT NULL,
  `address` mediumtext NOT NULL,
  `state` varchar(255) NOT NULL,
  `city` varchar(200) NOT NULL,
  `mobileno` varchar(30) NOT NULL,
  `email` varchar(255) NOT NULL,
  `salary_template_id` int(11) DEFAULT 0,
  `photo` varchar(255) DEFAULT NULL,
  `nid` varchar(200) NOT NULL,
  `facebook_url` varchar(255) NOT NULL,
  `linkedin_url` varchar(255) NOT NULL,
  `twitter_url` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `staff` (`id`, `staff_id`, `name`, `department`, `qualification`, `designation`, `joining_date`, `birthday`, `gender`, `religion`, `blood_group`, `marital_status`, `address`, `state`, `city`, `mobileno`, `email`, `salary_template_id`, `photo`, `nid`, `facebook_url`, `linkedin_url`, `twitter_url`, `created_at`, `updated_at`) VALUES (1, 'eb449b4', 'Popular Diagnostic Center', 0, '', 0, '2023-03-14', '1997-10-09', 'male', 'Islam', 'O+', '2', 'হাউজঃ মুন্সিবাড়ি, নয়ার হাট স্কুল সংলগ্ন, বড়বাড়ি, লালমনির হাট', '', '', '01775457008', 'info@elitedesign.com.bd', 0, 'c1ce54b0df1adf025ce3f9091ae77df1.png', '', 'https://facebook.com/elitedesignbd', 'https://twitter.com/elitedesignbd', 'https://linkedin.com/elitedesignbd', '2023-03-14 17:19:38', '2023-03-14 15:21:32');
INSERT INTO `staff` (`id`, `staff_id`, `name`, `department`, `qualification`, `designation`, `joining_date`, `birthday`, `gender`, `religion`, `blood_group`, `marital_status`, `address`, `state`, `city`, `mobileno`, `email`, `salary_template_id`, `photo`, `nid`, `facebook_url`, `linkedin_url`, `twitter_url`, `created_at`, `updated_at`) VALUES (2, '77b79d5', 'jahanara Begum', 2, 'BSC', 4, '2023-03-15', '1997-06-11', 'female', 'Islam', 'O+', '2', '35/3/1-B', '', '', '01775457008', 'receptionist@elitedesign.com.bd', 0, '39bf842e7061e59e8d1283e4c1f9330b.jpg', '', 'https://facebook.com/elitedesignbd', 'https://twitter.com/elitedesignbd', 'https://linkedin.com/elitedesignbd', '2023-03-15 03:19:01', '2023-03-15 03:19:01');
INSERT INTO `staff` (`id`, `staff_id`, `name`, `department`, `qualification`, `designation`, `joining_date`, `birthday`, `gender`, `religion`, `blood_group`, `marital_status`, `address`, `state`, `city`, `mobileno`, `email`, `salary_template_id`, `photo`, `nid`, `facebook_url`, `linkedin_url`, `twitter_url`, `created_at`, `updated_at`) VALUES (3, '31b912e', 'Md Abu Sayed', 1, 'BSC', 1, '2023-03-14', '1997-06-04', 'male', 'Islam', 'A-', '2', '35/3/1-B,bangladesh', '', '', '01775457008', 'lab@elitedesign.com.bd', 0, '24b4e97a397240f4842e39aaf2820269.png', '', 'https://facebook.com/elitedesignbd', 'https://twitter.com/elitedesignbd', 'https://linkedin.com/elitedesignbd', '2023-03-15 03:21:23', '2023-03-15 03:21:23');
INSERT INTO `staff` (`id`, `staff_id`, `name`, `department`, `qualification`, `designation`, `joining_date`, `birthday`, `gender`, `religion`, `blood_group`, `marital_status`, `address`, `state`, `city`, `mobileno`, `email`, `salary_template_id`, `photo`, `nid`, `facebook_url`, `linkedin_url`, `twitter_url`, `created_at`, `updated_at`) VALUES (4, '6e2873d', 'Md Nayeem Mia', 2, 'BSC', 5, '2023-03-14', '1998-05-07', 'male', 'Islam', 'B+', '1', '35/3/1, dhaka', '', '', '01775457008', 'accounts@elitedesign.com.bd', 0, 'e03f132627a863b43247d439c66c28ed.png', '', 'https://facebook.com/elitedesignbd', 'https://twitter.com/elitedesignbd', 'https://linkedin.com/elitedesignbd', '2023-03-15 03:23:26', '2023-03-15 03:23:26');
INSERT INTO `staff` (`id`, `staff_id`, `name`, `department`, `qualification`, `designation`, `joining_date`, `birthday`, `gender`, `religion`, `blood_group`, `marital_status`, `address`, `state`, `city`, `mobileno`, `email`, `salary_template_id`, `photo`, `nid`, `facebook_url`, `linkedin_url`, `twitter_url`, `created_at`, `updated_at`) VALUES (5, '6e9db4b', 'Dr. Md Abdul Kalam', 4, 'MBBS', 3, '2023-03-07', '1997-01-28', 'male', 'Islam', 'B+', '1', '35/3/1-B', '', '', '01775457008', 'doctor@elitedesign.com.bd', 0, 'e98c9bc6ea50acebda3e852a28f4b63d.png', '', 'https://facebook.com/elitedesignbd', 'https://twitter.com/elitedesignbd', 'https://linkedin.com/elitedesignbd', '2023-03-15 03:26:12', '2023-03-15 03:26:12');


#
# TABLE STRUCTURE FOR: staff_attendance
#

DROP TABLE IF EXISTS `staff_attendance`;

CREATE TABLE `staff_attendance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` varchar(20) NOT NULL,
  `status` varchar(2) DEFAULT NULL,
  `remark` varchar(255) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `staff_attendance` (`id`, `staff_id`, `status`, `remark`, `date`) VALUES (1, '3', 'P', '', '2023-04-04');
INSERT INTO `staff_attendance` (`id`, `staff_id`, `status`, `remark`, `date`) VALUES (2, '2', 'P', '', '2023-04-08');


#
# TABLE STRUCTURE FOR: staff_balance
#

DROP TABLE IF EXISTS `staff_balance`;

CREATE TABLE `staff_balance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `amount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `staff_balance` (`id`, `staff_id`, `amount`, `created_at`, `updated_at`) VALUES (1, 2, '0.00', '2023-03-15 03:19:01', '2023-03-15 03:19:01');
INSERT INTO `staff_balance` (`id`, `staff_id`, `amount`, `created_at`, `updated_at`) VALUES (2, 3, '0.00', '2023-03-15 03:21:23', '2023-03-15 03:21:23');
INSERT INTO `staff_balance` (`id`, `staff_id`, `amount`, `created_at`, `updated_at`) VALUES (3, 4, '0.00', '2023-03-15 03:23:26', '2023-03-15 03:23:26');
INSERT INTO `staff_balance` (`id`, `staff_id`, `amount`, `created_at`, `updated_at`) VALUES (4, 5, '0.00', '2023-03-15 03:26:12', '2023-03-15 03:26:12');


#
# TABLE STRUCTURE FOR: staff_bank_account
#

DROP TABLE IF EXISTS `staff_bank_account`;

CREATE TABLE `staff_bank_account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `bank_name` varchar(200) NOT NULL,
  `holder_name` varchar(255) NOT NULL,
  `bank_branch` varchar(255) NOT NULL,
  `bank_address` varchar(255) NOT NULL,
  `ifsc_code` varchar(200) NOT NULL,
  `account_no` varchar(200) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `staff_bank_account` (`id`, `staff_id`, `bank_name`, `holder_name`, `bank_branch`, `bank_address`, `ifsc_code`, `account_no`, `created_at`, `updated_at`) VALUES (1, 2, '356645', 'jahanara', 'dhaka', '35/3/1-bangladesh', '1235', '1257455887777', '2023-03-15 03:19:01', '2023-03-15 03:19:01');
INSERT INTO `staff_bank_account` (`id`, `staff_id`, `bank_name`, `holder_name`, `bank_branch`, `bank_address`, `ifsc_code`, `account_no`, `created_at`, `updated_at`) VALUES (2, 3, '356645', 'jahanara', 'dhaka', '3431264', '1235', '1257455887777', '2023-03-15 03:21:23', '2023-03-15 03:21:23');


#
# TABLE STRUCTURE FOR: staff_department
#

DROP TABLE IF EXISTS `staff_department`;

CREATE TABLE `staff_department` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `staff_department` (`id`, `name`, `created_at`, `updated_at`) VALUES (1, 'lab', '2023-03-15 03:06:56', '2023-03-15 03:06:56');
INSERT INTO `staff_department` (`id`, `name`, `created_at`, `updated_at`) VALUES (2, 'Reciption', '2023-03-15 03:07:05', '2023-03-15 03:07:05');
INSERT INTO `staff_department` (`id`, `name`, `created_at`, `updated_at`) VALUES (3, 'Nurse', '2023-03-15 03:07:10', '2023-03-15 03:07:10');
INSERT INTO `staff_department` (`id`, `name`, `created_at`, `updated_at`) VALUES (4, 'Doctor', '2023-03-15 03:07:19', '2023-03-15 03:07:19');


#
# TABLE STRUCTURE FOR: staff_designation
#

DROP TABLE IF EXISTS `staff_designation`;

CREATE TABLE `staff_designation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `staff_designation` (`id`, `name`, `created_at`, `updated_at`) VALUES (1, 'lab incharge', '2023-03-15 03:07:34', '2023-03-15 03:07:34');
INSERT INTO `staff_designation` (`id`, `name`, `created_at`, `updated_at`) VALUES (2, 'Nurse', '2023-03-15 03:07:41', '2023-03-15 03:07:41');
INSERT INTO `staff_designation` (`id`, `name`, `created_at`, `updated_at`) VALUES (3, 'Doctor', '2023-03-15 03:07:47', '2023-03-15 03:07:47');
INSERT INTO `staff_designation` (`id`, `name`, `created_at`, `updated_at`) VALUES (4, 'Reciptionist', '2023-03-15 03:07:57', '2023-03-15 03:07:57');
INSERT INTO `staff_designation` (`id`, `name`, `created_at`, `updated_at`) VALUES (5, 'Accountant', '2023-03-15 03:08:11', '2023-03-15 03:08:11');
INSERT INTO `staff_designation` (`id`, `name`, `created_at`, `updated_at`) VALUES (6, 'Manager', '2023-03-15 03:08:15', '2023-03-15 03:08:15');


#
# TABLE STRUCTURE FOR: staff_documents
#

DROP TABLE IF EXISTS `staff_documents`;

CREATE TABLE `staff_documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `category_id` varchar(20) NOT NULL,
  `remarks` text NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `enc_name` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: staff_privileges
#

DROP TABLE IF EXISTS `staff_privileges`;

CREATE TABLE `staff_privileges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `is_add` tinyint(1) NOT NULL,
  `is_edit` tinyint(1) NOT NULL,
  `is_view` tinyint(1) NOT NULL,
  `is_delete` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=353 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (1, 2, 39, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (2, 2, 40, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (3, 2, 41, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (4, 2, 42, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (5, 2, 43, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (6, 2, 44, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (7, 2, 45, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (8, 2, 46, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (9, 2, 47, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (10, 2, 48, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (11, 2, 49, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (12, 2, 50, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (13, 2, 51, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (14, 2, 52, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (15, 2, 53, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (16, 2, 54, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (17, 2, 55, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (18, 2, 56, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (19, 2, 57, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (20, 2, 59, 1, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (21, 2, 1, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (22, 2, 2, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (23, 2, 19, 0, 1, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (24, 2, 36, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (25, 2, 37, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (26, 2, 38, 0, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (27, 2, 3, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (28, 2, 4, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (29, 2, 5, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (30, 2, 6, 0, 1, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (31, 2, 7, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (32, 2, 8, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (33, 2, 26, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (34, 2, 27, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (35, 2, 28, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (36, 2, 29, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (37, 2, 30, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (38, 2, 31, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (39, 2, 9, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (40, 2, 10, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (41, 2, 16, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (42, 2, 17, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (43, 2, 18, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (44, 2, 32, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (45, 2, 33, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (46, 2, 34, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (47, 2, 35, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (48, 2, 13, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (49, 2, 14, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (50, 2, 15, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (51, 2, 11, 1, 1, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (52, 2, 12, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (53, 2, 21, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (54, 2, 22, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (55, 2, 23, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (56, 2, 24, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (57, 2, 25, 1, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (58, 2, 58, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (59, 3, 39, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (60, 3, 40, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (61, 3, 41, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (62, 3, 42, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (63, 3, 43, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (64, 3, 44, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (65, 3, 45, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (66, 3, 46, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (67, 3, 47, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (68, 3, 48, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (69, 3, 49, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (70, 3, 50, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (71, 3, 51, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (72, 3, 52, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (73, 3, 53, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (74, 3, 54, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (75, 3, 55, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (76, 3, 56, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (77, 3, 57, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (78, 3, 59, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (79, 3, 1, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (80, 3, 2, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (81, 3, 19, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (82, 3, 36, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (83, 3, 37, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (84, 3, 38, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (85, 3, 3, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (86, 3, 4, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (87, 3, 5, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (88, 3, 6, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (89, 3, 7, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (90, 3, 8, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (91, 3, 26, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (92, 3, 27, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (93, 3, 28, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (94, 3, 29, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (95, 3, 30, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (96, 3, 31, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (97, 3, 9, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (98, 3, 10, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (99, 3, 16, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (100, 3, 17, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (101, 3, 18, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (102, 3, 32, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (103, 3, 33, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (104, 3, 34, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (105, 3, 35, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (106, 3, 13, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (107, 3, 14, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (108, 3, 15, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (109, 3, 11, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (110, 3, 12, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (111, 3, 21, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (112, 3, 22, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (113, 3, 23, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (114, 3, 24, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (115, 3, 25, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (116, 3, 58, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (117, 4, 39, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (118, 4, 40, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (119, 4, 41, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (120, 4, 42, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (121, 4, 43, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (122, 4, 44, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (123, 4, 45, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (124, 4, 46, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (125, 4, 47, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (126, 4, 48, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (127, 4, 49, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (128, 4, 50, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (129, 4, 51, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (130, 4, 52, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (131, 4, 53, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (132, 4, 54, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (133, 4, 55, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (134, 4, 56, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (135, 4, 57, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (136, 4, 59, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (137, 4, 1, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (138, 4, 2, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (139, 4, 19, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (140, 4, 36, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (141, 4, 37, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (142, 4, 38, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (143, 4, 3, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (144, 4, 4, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (145, 4, 5, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (146, 4, 6, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (147, 4, 7, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (148, 4, 8, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (149, 4, 26, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (150, 4, 27, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (151, 4, 28, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (152, 4, 29, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (153, 4, 30, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (154, 4, 31, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (155, 4, 9, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (156, 4, 10, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (157, 4, 16, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (158, 4, 17, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (159, 4, 18, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (160, 4, 32, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (161, 4, 33, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (162, 4, 34, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (163, 4, 35, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (164, 4, 13, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (165, 4, 14, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (166, 4, 15, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (167, 4, 11, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (168, 4, 12, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (169, 4, 21, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (170, 4, 22, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (171, 4, 23, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (172, 4, 24, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (173, 4, 25, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (174, 4, 58, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (175, 5, 39, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (176, 5, 40, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (177, 5, 41, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (178, 5, 42, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (179, 5, 43, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (180, 5, 44, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (181, 5, 45, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (182, 5, 46, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (183, 5, 47, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (184, 5, 48, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (185, 5, 49, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (186, 5, 50, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (187, 5, 51, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (188, 5, 52, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (189, 5, 53, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (190, 5, 54, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (191, 5, 55, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (192, 5, 56, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (193, 5, 57, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (194, 5, 59, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (195, 5, 1, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (196, 5, 2, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (197, 5, 19, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (198, 5, 36, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (199, 5, 37, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (200, 5, 38, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (201, 5, 3, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (202, 5, 4, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (203, 5, 5, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (204, 5, 6, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (205, 5, 7, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (206, 5, 8, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (207, 5, 26, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (208, 5, 27, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (209, 5, 28, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (210, 5, 29, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (211, 5, 30, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (212, 5, 31, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (213, 5, 9, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (214, 5, 10, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (215, 5, 16, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (216, 5, 17, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (217, 5, 18, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (218, 5, 32, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (219, 5, 33, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (220, 5, 34, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (221, 5, 35, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (222, 5, 13, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (223, 5, 14, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (224, 5, 15, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (225, 5, 11, 1, 1, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (226, 5, 12, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (227, 5, 21, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (228, 5, 22, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (229, 5, 23, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (230, 5, 24, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (231, 5, 25, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (232, 5, 58, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (233, 6, 39, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (234, 6, 40, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (235, 6, 41, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (236, 6, 42, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (237, 6, 43, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (238, 6, 44, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (239, 6, 45, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (240, 6, 46, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (241, 6, 47, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (242, 6, 48, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (243, 6, 49, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (244, 6, 50, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (245, 6, 51, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (246, 6, 52, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (247, 6, 53, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (248, 6, 54, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (249, 6, 55, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (250, 6, 56, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (251, 6, 57, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (252, 6, 59, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (253, 6, 1, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (254, 6, 2, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (255, 6, 19, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (256, 6, 36, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (257, 6, 37, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (258, 6, 38, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (259, 6, 3, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (260, 6, 4, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (261, 6, 5, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (262, 6, 6, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (263, 6, 7, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (264, 6, 8, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (265, 6, 26, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (266, 6, 27, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (267, 6, 28, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (268, 6, 29, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (269, 6, 30, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (270, 6, 31, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (271, 6, 9, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (272, 6, 10, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (273, 6, 16, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (274, 6, 17, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (275, 6, 18, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (276, 6, 32, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (277, 6, 33, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (278, 6, 34, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (279, 6, 35, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (280, 6, 13, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (281, 6, 14, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (282, 6, 15, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (283, 6, 11, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (284, 6, 12, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (285, 6, 21, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (286, 6, 22, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (287, 6, 23, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (288, 6, 24, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (289, 6, 25, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (290, 6, 58, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (291, 7, 39, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (292, 7, 40, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (293, 7, 41, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (294, 7, 42, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (295, 7, 43, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (296, 7, 44, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (297, 7, 45, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (298, 7, 46, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (299, 7, 47, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (300, 7, 48, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (301, 7, 49, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (302, 7, 50, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (303, 7, 51, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (304, 7, 52, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (305, 7, 53, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (306, 7, 54, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (307, 7, 55, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (308, 7, 56, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (309, 7, 57, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (310, 7, 59, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (311, 7, 1, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (312, 7, 2, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (313, 7, 19, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (314, 7, 36, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (315, 7, 37, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (316, 7, 38, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (317, 7, 3, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (318, 7, 4, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (319, 7, 5, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (320, 7, 6, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (321, 7, 7, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (322, 7, 8, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (323, 7, 26, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (324, 7, 27, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (325, 7, 28, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (326, 7, 29, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (327, 7, 30, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (328, 7, 31, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (329, 7, 9, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (330, 7, 10, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (331, 7, 16, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (332, 7, 17, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (333, 7, 18, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (334, 7, 32, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (335, 7, 33, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (336, 7, 34, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (337, 7, 35, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (338, 7, 13, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (339, 7, 14, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (340, 7, 15, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (341, 7, 11, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (342, 7, 12, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (343, 7, 21, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (344, 7, 22, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (345, 7, 23, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (346, 7, 24, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (347, 7, 25, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (348, 7, 58, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (349, 2, 60, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (350, 7, 60, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (351, 3, 60, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (352, 3, 61, 0, 0, 1, 0);


#
# TABLE STRUCTURE FOR: supplier
#

DROP TABLE IF EXISTS `supplier`;

CREATE TABLE `supplier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `address` text NOT NULL,
  `mobileno` varchar(30) NOT NULL,
  `email` varchar(100) NOT NULL,
  `company_name` varchar(200) NOT NULL,
  `product_list` mediumtext NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: theme_settings
#

DROP TABLE IF EXISTS `theme_settings`;

CREATE TABLE `theme_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `border_mode` varchar(20) NOT NULL,
  `dark_skin` varchar(20) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `theme_settings` (`id`, `border_mode`, `dark_skin`, `created_at`, `updated_at`) VALUES (1, 'true', 'true', '2019-12-23 22:59:38', '2023-04-19 16:06:07');


#
# TABLE STRUCTURE FOR: transactions
#

DROP TABLE IF EXISTS `transactions`;

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` varchar(20) NOT NULL,
  `voucher_head_id` varchar(200) NOT NULL,
  `type` varchar(100) NOT NULL,
  `category` varchar(20) NOT NULL,
  `ref` varchar(255) NOT NULL,
  `amount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `dr` decimal(18,2) NOT NULL DEFAULT 0.00,
  `cr` decimal(18,2) NOT NULL DEFAULT 0.00,
  `bal` decimal(18,2) NOT NULL DEFAULT 0.00,
  `date` date NOT NULL,
  `pay_via` varchar(20) NOT NULL,
  `description` text NOT NULL,
  `attachments` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: voucher_head
#

DROP TABLE IF EXISTS `voucher_head`;

CREATE TABLE `voucher_head` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

